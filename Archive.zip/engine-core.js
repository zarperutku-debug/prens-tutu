// ============================================================================
// PRENS TUTU: GÖLGELERİN TACI - MODÜL 1: ENGINE CORE (engine-core.js) v7.0
// İçerik: Prosedürel Web Audio Ses & Orkestral Film Müziği Sentezleyicisi,
//         18 Eyaletli Büyük Dünya Atlası (Grand World Atlas), İkmal Hatları & Abluka,
//         Kademeli Fetih Kuralı, Kraliyet Divanı & Demirhane, 12 Başarım, Save/Load
// ============================================================================

window.PrinceTutu = window.PrinceTutu || {};

// ----------------------------------------------------------------------------
// 1. PROSEDÜREL WEB AUDIO SES & ORKESTRAL FİLM MÜZİĞİ MOTORU
//    (Harici hiçbir MP3/WAV dosyası gerektirmeden gerçek zamanlı sentez yapar)
// ----------------------------------------------------------------------------
class ProceduralSoundEngine {
  constructor() {
    this.ctx = null;
    this.muted = false;
    this.musicPlaying = false;
    this.musicMood = "court"; // 'court' | 'battle' | 'night' | 'victory'
    this.musicTimer = null;
    this.musicStep = 0;
  }

  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) this.ctx = new AudioCtx();
    }
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume();
    }
  }

  toggleMusic(forceState) {
    const nextState = typeof forceState === "boolean" ? forceState : !this.musicPlaying;
    if (nextState) {
      this.init();
      this.musicPlaying = true;
      if (!this.musicTimer) {
        this.musicStep = 0;
        this.playMusicTick();
        this.musicTimer = setInterval(() => this.playMusicTick(), 650);
      }
    } else {
      this.musicPlaying = false;
      if (this.musicTimer) {
        clearInterval(this.musicTimer);
        this.musicTimer = null;
      }
    }
    return this.musicPlaying;
  }

  setMusicMood(mood) {
    if (this.musicMood !== mood) {
      this.musicMood = mood;
      this.musicStep = 0;
    }
  }

  playMusicTick() {
    if (!this.musicPlaying || this.muted) return;
    try {
      this.init();
      if (!this.ctx) return;
      const now = this.ctx.currentTime;
      const step = this.musicStep++;

      const scales = {
        court: [146.83, 164.81, 174.61, 196.0, 220.0, 246.94, 261.63, 293.66], // D Dorian
        battle: [110.0, 130.81, 146.83, 164.81, 196.0, 220.0, 261.63, 293.66], // A Minor
        night: [130.81, 146.83, 155.56, 196.0, 207.65, 261.63, 293.66, 311.13], // C Minor
        victory: [130.81, 164.81, 196.0, 246.94, 261.63, 329.63, 392.0, 523.25] // C Lydian
      };

      const scale = scales[this.musicMood] || scales.court;

      if (step % 4 === 0) {
        const bassOsc = this.ctx.createOscillator();
        const bassGain = this.ctx.createGain();
        bassOsc.type = this.musicMood === "battle" ? "sawtooth" : "triangle";
        const rootFreq = scale[0] / (this.musicMood === "battle" ? 1 : 2);
        bassOsc.frequency.setValueAtTime(rootFreq, now);
        bassGain.gain.setValueAtTime(0.001, now);
        bassGain.gain.linearRampToValueAtTime(this.musicMood === "battle" ? 0.055 : 0.045, now + 0.25);
        bassGain.gain.exponentialRampToValueAtTime(0.0008, now + 2.4);

        const filter = this.ctx.createBiquadFilter();
        filter.type = "lowpass";
        filter.frequency.setValueAtTime(320, now);

        bassOsc.connect(filter);
        filter.connect(bassGain);
        bassGain.connect(this.ctx.destination);
        bassOsc.start(now);
        bassOsc.stop(now + 2.45);
      }

      const pattern = [0, 2, 4, 3, 5, 4, 2, 1, 0, 4, 6, 5, 7, 4, 3, 2];
      const noteIdx = pattern[step % pattern.length];
      const freq = scale[noteIdx % scale.length] * (step % 8 === 7 ? 2 : 1);

      const arpOsc = this.ctx.createOscillator();
      const arpGain = this.ctx.createGain();
      arpOsc.type = this.musicMood === "night" ? "sine" : "triangle";
      arpOsc.frequency.setValueAtTime(freq, now);
      arpGain.gain.setValueAtTime(0.001, now);
      arpGain.gain.linearRampToValueAtTime(0.035, now + 0.04);
      arpGain.gain.exponentialRampToValueAtTime(0.0008, now + 0.58);

      arpOsc.connect(arpGain);
      arpGain.connect(this.ctx.destination);
      arpOsc.start(now);
      arpOsc.stop(now + 0.6);

      if (this.musicMood === "battle" && step % 2 === 0) {
        const drumOsc = this.ctx.createOscillator();
        const drumGain = this.ctx.createGain();
        drumOsc.type = "sine";
        drumOsc.frequency.setValueAtTime(115, now);
        drumOsc.frequency.exponentialRampToValueAtTime(38, now + 0.18);
        drumGain.gain.setValueAtTime(0.08, now);
        drumGain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
        drumOsc.connect(drumGain);
        drumGain.connect(this.ctx.destination);
        drumOsc.start(now);
        drumOsc.stop(now + 0.21);
      }
    } catch (e) {
      // Ses kartı meşgulse sessizce geç
    }
  }

  play(type) {
    if (this.muted) return;
    try {
      this.init();
      if (!this.ctx) return;
      const now = this.ctx.currentTime;

      if (type === "click") {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(540, now);
        osc.frequency.exponentialRampToValueAtTime(250, now + 0.06);
        gain.gain.setValueAtTime(0.11, now);
        gain.gain.linearRampToValueAtTime(0.01, now + 0.06);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now);
        osc.stop(now + 0.06);
      } else if (type === "coin") {
        [987.77, 1318.51, 1567.98].forEach((freq, idx) => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = "triangle";
          osc.frequency.setValueAtTime(freq, now + idx * 0.06);
          gain.gain.setValueAtTime(0.16, now + idx * 0.06);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.06 + 0.24);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start(now + idx * 0.06);
          osc.stop(now + idx * 0.06 + 0.24);
        });
      } else if (type === "sword") {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(1450, now);
        osc.frequency.exponentialRampToValueAtTime(170, now + 0.18);
        gain.gain.setValueAtTime(0.22, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.18);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now);
        osc.stop(now + 0.18);
      } else if (type === "shield") {
        [180, 320].forEach((freq) => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = "triangle";
          osc.frequency.setValueAtTime(freq, now);
          osc.frequency.exponentialRampToValueAtTime(75, now + 0.22);
          gain.gain.setValueAtTime(0.22, now);
          gain.gain.exponentialRampToValueAtTime(0.005, now + 0.22);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start(now);
          osc.stop(now + 0.22);
        });
      } else if (type === "anvil") {
        [880, 1760, 2640].forEach((freq, idx) => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = "sine";
          osc.frequency.setValueAtTime(freq, now);
          gain.gain.setValueAtTime(0.15 / (idx + 1), now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start(now);
          osc.stop(now + 0.45);
        });
      } else if (type === "cannon") {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(140, now);
        osc.frequency.exponentialRampToValueAtTime(32, now + 0.42);
        gain.gain.setValueAtTime(0.3, now);
        gain.gain.exponentialRampToValueAtTime(0.005, now + 0.42);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now);
        osc.stop(now + 0.43);
      } else if (type === "magic") {
        [523.25, 659.25, 783.99, 1046.5].forEach((freq, idx) => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = "sine";
          osc.frequency.setValueAtTime(freq, now + idx * 0.05);
          gain.gain.setValueAtTime(0.12, now + idx * 0.05);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.05 + 0.55);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start(now + idx * 0.05);
          osc.stop(now + idx * 0.05 + 0.55);
        });
      } else if (type === "dice") {
        [0, 0.05, 0.11, 0.16].forEach((offset) => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = "square";
          osc.frequency.setValueAtTime(300 + Math.random() * 400, now + offset);
          gain.gain.setValueAtTime(0.1, now + offset);
          gain.gain.exponentialRampToValueAtTime(0.01, now + offset + 0.03);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start(now + offset);
          osc.stop(now + offset + 0.03);
        });
      } else if (type === "horn") {
        [220, 277.18, 329.63].forEach((freq) => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = "sawtooth";
          osc.frequency.setValueAtTime(freq, now);
          gain.gain.setValueAtTime(0.01, now);
          gain.gain.linearRampToValueAtTime(0.1, now + 0.15);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.85);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start(now);
          osc.stop(now + 0.85);
        });
      } else if (type === "victory" || type === "fanfare") {
        [261.63, 329.63, 392.0, 523.25, 659.25].forEach((freq, idx) => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = "triangle";
          osc.frequency.setValueAtTime(freq, now + idx * 0.08);
          gain.gain.setValueAtTime(0.16, now + idx * 0.08);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.5);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start(now + idx * 0.08);
          osc.stop(now + idx * 0.08 + 0.5);
        });
      } else if (type === "alert" || type === "defeat") {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(195, now);
        osc.frequency.linearRampToValueAtTime(115, now + 0.35);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.35);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now);
        osc.stop(now + 0.35);
      }
    } catch (e) {
      // Ses kartı meşgulse sessizce geç
    }
  }
}

window.PrinceTutu.Sound = new ProceduralSoundEngine();

// ----------------------------------------------------------------------------
// 2. 18 EYALETLİ BÜYÜK DÜNYA ATLASI (GRAND WORLD ATLAS - 18 BÖLGE)
//    5 Krallık Coğrafyası, İkmal Hatları, Limanlar ve Kademeli Fetih Kuralları
// ----------------------------------------------------------------------------
window.PrinceTutu.INITIAL_PROVINCES = {
  // === 1. LALO İMPARATORLUĞU (MERKEZ & GÜNEY BARONLUKLARI) ===
  capital_lalo: {
    id: "capital_lalo",
    name: "Başkent Lalo",
    realm: "Lalo İmparatorluğu (Merkez)",
    owner: "player",
    terrain: "citadel",
    isCapital: true,
    isBorderFort: false,
    isPort: false,
    resource: "👑 Altın Taht & Büyük Loncalar",
    x: 545,
    y: 295,
    neighbors: ["imperial_riverlands", "eastern_pass", "golden_plains", "dark_forest", "silver_peaks", "furry_coast"],
    garrison: 9,
    taxIncome: 40,
    unrest: 12,
    defenseBonus: 4,
    fortLevel: 3,
    economyLevel: 3,
    isBlockaded: false,
    perk: "Altın Taht Merkezi (+4 Savunma, Tüm İkmal Hatlarının Kalbi)",
    description: "Altın Taht'ın bulunduğu imparatorluk başkenti. Saray entrikalarının, loncaların ve kraliyet akademisinin kalbi."
  },
  eastern_pass: {
    id: "eastern_pass",
    name: "Doğu Kızıl Geçidi",
    realm: "Lalo İmparatorluğu (Merkez)",
    owner: "player",
    terrain: "canyon",
    isCapital: false,
    isBorderFort: true,
    isPort: false,
    resource: "🔥 Kanyon Sınır Tahkimatı",
    x: 745,
    y: 265,
    neighbors: ["capital_lalo", "vampire_citadel", "dark_forest", "silver_peaks"],
    garrison: 8,
    taxIncome: 18,
    unrest: 20,
    defenseBonus: 3,
    fortLevel: 2,
    economyLevel: 1,
    isBlockaded: false,
    perk: "Sınır Kalesi (Düşerse Başkent Lalo doğrudan kuşatma altına girer!)",
    description: "Vampir-Kara Elf İttifakı'nın istilasına karşı imparatorluğu koruyan stratejik kızıl kanyon ve ateş kuleleri."
  },
  imperial_riverlands: {
    id: "imperial_riverlands",
    name: "Mavi Nehir Deltası",
    realm: "Lalo İmparatorluğu (Merkez)",
    owner: "player",
    terrain: "river",
    isCapital: false,
    isBorderFort: false,
    isPort: true,
    resource: "⚓ Lojistik Köprü & Nehir Limanı",
    x: 405,
    y: 255,
    neighbors: ["capital_lalo", "furry_coast", "silver_peaks", "golden_plains"],
    garrison: 6,
    taxIncome: 28,
    unrest: 10,
    defenseBonus: 2,
    fortLevel: 2,
    economyLevel: 2,
    isBlockaded: false,
    perk: "İkmal Limanı (Batı Denizi ile Başkent arasındaki nehir ticaretini bağlar)",
    description: "Başkent Lalo'yu Batı Furry denizlerine bağlayan bereketli nehir deltası, taş köprüler ve iç ticaret limanı."
  },
  golden_plains: {
    id: "golden_plains",
    name: "Güney Bereket Ovaları",
    realm: "Lalo İmparatorluğu (Asi Baronlar)",
    owner: "brothers",
    terrain: "plains",
    isCapital: false,
    isBorderFort: true,
    isPort: false,
    resource: "🌾 Köle Baronları & Tahıl Ambarı",
    x: 495,
    y: 430,
    neighbors: ["capital_lalo", "imperial_riverlands", "furry_coast", "doxe_border", "dark_forest", "baron_ironkeep"],
    garrison: 8,
    taxIncome: 35,
    unrest: 38,
    defenseBonus: 1,
    fortLevel: 1,
    economyLevel: 2,
    isBlockaded: false,
    perk: "Fetih Ödülü: Anzak'ın Geliri Kesilir & +2 Özgür Piyade Taburu",
    description: "Anzak ve Adem'e bağlı köle baronlarının kontrolündeki uçsuz bucaksız altın buğday ovaları ve yel değirmenleri."
  },
  dark_forest: {
    id: "dark_forest",
    name: "Fısıltı Ormanı",
    realm: "Lalo İmparatorluğu (Asi Baronlar)",
    owner: "brothers",
    terrain: "forest",
    isCapital: false,
    isBorderFort: true,
    isPort: false,
    resource: "🕵️ Gölge Suikast & Kaçakçı Karargahı",
    x: 695,
    y: 405,
    neighbors: ["capital_lalo", "eastern_pass", "vampire_citadel", "blood_necropolis", "golden_plains", "baron_ironkeep"],
    garrison: 7,
    taxIncome: 25,
    unrest: 30,
    defenseBonus: 2,
    fortLevel: 1,
    economyLevel: 1,
    isBlockaded: false,
    perk: "Fetih Ödülü: Adem'in Suikast Ağı Çöker (-25% Darbe Hazırlığı)",
    description: "Adem'in paralı suikastçılarının ve karaborsa kaçakçılarının gizlendiği sisli, sık çam ormanı."
  },
  baron_ironkeep: {
    id: "baron_ironkeep",
    name: "Kızıl Sancak Baronluğu",
    realm: "Lalo İmparatorluğu (Asi Baronlar)",
    owner: "brothers",
    terrain: "citadel",
    isCapital: true,
    isBorderFort: false,
    isPort: false,
    requiredBorderProvinces: ["golden_plains", "dark_forest"],
    resource: "⚔️ Anzak'ın Paralı Asker Karargahı",
    x: 625,
    y: 525,
    neighbors: ["golden_plains", "dark_forest", "doxe_border", "doxe_vineyards", "blood_necropolis"],
    garrison: 11,
    taxIncome: 38,
    unrest: 22,
    defenseBonus: 3,
    fortLevel: 3,
    economyLevel: 2,
    isBlockaded: false,
    perk: "Kademeli Fetih Hedefi: Önce Güney Ovaları veya Fısıltı Ormanı fethedilmelidir!",
    description: "Ağabeyin Anzak ve Güney Baronlarının iç savaş hazırlığı yaptığı zırhlı güney hisarı."
  },

  // === 2. FURRY CUMHURİYETİ (BATI KIYILARI & DENİZLER) ===
  furry_coast: {
    id: "furry_coast",
    name: "Gümüş Pençe Limanı",
    realm: "Furry Cumhuriyeti (Batı Denizleri)",
    owner: "furry",
    terrain: "port",
    isCapital: false,
    isBorderFort: true,
    isPort: true,
    resource: "⚓ Dış Ticaret & Kalyon Tersaneleri",
    x: 265,
    y: 315,
    neighbors: ["imperial_riverlands", "capital_lalo", "golden_plains", "furry_senate_capital", "furry_storm_isles", "silver_peaks"],
    garrison: 10,
    taxIncome: 48,
    unrest: 10,
    defenseBonus: 2,
    fortLevel: 2,
    economyLevel: 3,
    isBlockaded: false,
    perk: "Müttefik Liman: Furry Keskin Nişancı & Deniz Ticareti Merkezi",
    description: "Furry Cumhuriyeti'nin imparatorluk sınırına açılan en büyük baharat, kalyon ve ticaret limanı."
  },
  furry_senate_capital: {
    id: "furry_senate_capital",
    name: "Pençetaht Metropolü",
    realm: "Furry Cumhuriyeti (Batı Denizleri)",
    owner: "furry",
    terrain: "port",
    isCapital: true,
    isBorderFort: false,
    isPort: true,
    requiredBorderProvinces: ["furry_coast", "furry_storm_isles"],
    resource: "🏛️ Cumhuriyet Başkenti & Barut Fabrikaları",
    x: 125,
    y: 220,
    neighbors: ["furry_coast", "furry_storm_isles", "northern_high_peaks"],
    garrison: 14,
    taxIncome: 60,
    unrest: 5,
    defenseBonus: 4,
    fortLevel: 3,
    economyLevel: 3,
    isBlockaded: false,
    perk: "Cumhuriyet Başkenti: Yüksek Senato ve Barut Topçu Dökümhaneleri",
    description: "Altın kubbeli borsa sarayları, devasa barut fabrikaları ve Yüksek Senato'nun bulunduğu Batı Metropolü."
  },
  furry_storm_isles: {
    id: "furry_storm_isles",
    name: "Fırtına Resifleri",
    realm: "Furry Cumhuriyeti (Batı Denizleri)",
    owner: "furry",
    terrain: "port",
    isCapital: false,
    isBorderFort: true,
    isPort: true,
    resource: "🚢 Açık Deniz Donanma Üssü & Karaborsa",
    x: 135,
    y: 430,
    neighbors: ["furry_coast", "furry_senate_capital", "doxe_border"],
    garrison: 9,
    taxIncome: 42,
    unrest: 14,
    defenseBonus: 3,
    fortLevel: 2,
    economyLevel: 2,
    isBlockaded: false,
    perk: "Deniz Üssü: Batı Okyanusu ikmal yollarını ve kalyon filolarını kontrol eder",
    description: "Sarp deniz kayalıkları üzerine inşa edilmiş deniz fenerleri, zırhlı kalyon demirleme koyu ve karaborsa limanı."
  },

  // === 3. DOXE KUTSAL KRALLIĞI (GÜNEY MERMER OVALARI) ===
  doxe_border: {
    id: "doxe_border",
    name: "Mermer Manastır",
    realm: "DOXE Kutsal Krallığı (Güney)",
    owner: "doxe",
    terrain: "monastery",
    isCapital: false,
    isBorderFort: true,
    isPort: false,
    resource: "⚖️ Işık Sınır Kapısı & Engizisyon",
    x: 410,
    y: 535,
    neighbors: ["golden_plains", "baron_ironkeep", "furry_storm_isles", "doxe_holy_city", "doxe_vineyards"],
    garrison: 12,
    taxIncome: 34,
    unrest: 5,
    defenseBonus: 3,
    fortLevel: 3,
    economyLevel: 2,
    isBlockaded: false,
    perk: "Kutsal Sınır: Kölelik kaldırılırsa DOXE Paladinleri buradan sefere katılır",
    description: "Kölelik kaldırılmadığı için sınırlarını kapatan DOXE Kutsal Şövalyelerinin mermer sınır manastırı."
  },
  doxe_holy_city: {
    id: "doxe_holy_city",
    name: "Solaris Kutsal Şehri",
    realm: "DOXE Kutsal Krallığı (Güney)",
    owner: "doxe",
    terrain: "monastery",
    isCapital: true,
    isBorderFort: false,
    isPort: false,
    requiredBorderProvinces: ["doxe_border", "doxe_vineyards"],
    resource: "☀️ Teokrasi Başkenti & Güneş Katedrali",
    x: 325,
    y: 625,
    neighbors: ["doxe_border", "doxe_vineyards"],
    garrison: 15,
    taxIncome: 52,
    unrest: 4,
    defenseBonus: 4,
    fortLevel: 3,
    economyLevel: 3,
    isBlockaded: false,
    perk: "Teokrasi Başkenti: Baş Engizisyoncu Solaris ve Kutsal Paladin Ordusu Merkezi",
    description: "Yüzlerce altın kuleli Güneş Katedrali'nin yükseldiği, Kutsal Işık Tarikatı'nın görkemli başkenti."
  },
  doxe_vineyards: {
    id: "doxe_vineyards",
    name: "Işık Vadisi & Şifa Bahçeleri",
    realm: "DOXE Kutsal Krallığı (Güney)",
    owner: "doxe",
    terrain: "plains",
    isCapital: false,
    isBorderFort: true,
    isPort: false,
    resource: "🧪 Kutsal İksir & Şifa Ambarları",
    x: 540,
    y: 620,
    neighbors: ["doxe_border", "doxe_holy_city", "baron_ironkeep"],
    garrison: 8,
    taxIncome: 38,
    unrest: 8,
    defenseBonus: 2,
    fortLevel: 2,
    economyLevel: 3,
    isBlockaded: false,
    perk: "Şifa Bahçeleri: Kervan ve elçi gönderildiğinde ordu moralini ve hazineyi besler",
    description: "Terasta yükselen üzüm bağları, şifalı su kaynakları ve manastır simyacılarının kutsal iksir bahçeleri."
  },

  // === 4. KUZEY DAĞ KLANLARI (KUZEY SARP ZİRVELERİ) ===
  silver_peaks: {
    id: "silver_peaks",
    name: "Gümüş Zirveler Sınır Ocağı",
    realm: "Kuzey Dağ Klanları (Kuzey)",
    owner: "tribes",
    terrain: "mountains",
    isCapital: false,
    isBorderFort: true,
    isPort: false,
    resource: "⚒️ Demir Dövme Merkezleri & Garnizon",
    x: 515,
    y: 145,
    neighbors: ["capital_lalo", "imperial_riverlands", "eastern_pass", "furry_coast", "northern_high_peaks", "northern_mithril_depths"],
    garrison: 10,
    taxIncome: 26,
    unrest: 18,
    defenseBonus: 4,
    fortLevel: 2,
    economyLevel: 2,
    isBlockaded: false,
    perk: "Müttefik Ocakları: Kuzey Çeliği ve Vahşi Dağ Baltacıları Tedarikçisi",
    description: "Usta demircilerin ve vahşi baltacıların yaşadığı karlı sarp zirveler ve kor demir ocakları."
  },
  northern_high_peaks: {
    id: "northern_high_peaks",
    name: "Buzboynuz Hisarı",
    realm: "Kuzey Dağ Klanları (Kuzey)",
    owner: "tribes",
    terrain: "mountains",
    isCapital: true,
    isBorderFort: false,
    isPort: false,
    requiredBorderProvinces: ["silver_peaks", "northern_mithril_depths"],
    resource: "🪓 Klanlar Başkenti & Ulu Şefler Divanı",
    x: 345,
    y: 80,
    neighbors: ["silver_peaks", "northern_mithril_depths", "furry_senate_capital"],
    garrison: 14,
    taxIncome: 34,
    unrest: 10,
    defenseBonus: 5,
    fortLevel: 3,
    economyLevel: 2,
    isBlockaded: false,
    perk: "Klanlar Başkenti: Şef Torvald'ın Ulu Divanı (+5 Dağ Savunması)",
    description: "Donmuş şelalelerin ve dev mamut kemiklerinden yapılmış Ulu Şefler Divanı'nın bulunduğu aşılmaz dağ başkenti."
  },
  northern_mithril_depths: {
    id: "northern_mithril_depths",
    name: "Mitril Yarıkları",
    realm: "Kuzey Dağ Klanları (Kuzey)",
    owner: "tribes",
    terrain: "mountains",
    isCapital: false,
    isBorderFort: true,
    isPort: false,
    resource: "💎 Mitril Madenleri & Efsanevi Zırh Cevheri",
    x: 705,
    y: 95,
    neighbors: ["silver_peaks", "northern_high_peaks", "vampire_citadel"],
    garrison: 9,
    taxIncome: 44,
    unrest: 15,
    defenseBonus: 4,
    fortLevel: 2,
    economyLevel: 3,
    isBlockaded: false,
    perk: "Mitril Ocakları: Ayışığı Kılıcı ve Kraliyet Zırhlarının nadir cevher kaynağı",
    description: "Volkanik lav nehirleriyle ısınan derin yeraltı galerileri; kıtanın en değerli mitril cevheri burada çıkarılır."
  },

  // === 5. VAMPİR - KARA ELF İTTİFAKI (DOĞU KARANLIK TOPRAKLARI) ===
  vampire_citadel: {
    id: "vampire_citadel",
    name: "Gölge Kalesi Burçları",
    realm: "Vampir - Kara Elf İttifakı (Doğu)",
    owner: "vampire",
    terrain: "vampire",
    isCapital: false,
    isBorderFort: true,
    isPort: false,
    resource: "🩸 Malakor'un Kan Lejyonları Sınır Hisarı",
    x: 895,
    y: 235,
    neighbors: ["eastern_pass", "dark_forest", "northern_mithril_depths", "elf_shadow_spire", "blood_necropolis"],
    garrison: 13,
    taxIncome: 45,
    unrest: 10,
    defenseBonus: 4,
    fortLevel: 3,
    economyLevel: 2,
    isBlockaded: false,
    perk: "Fetih Ödülü: Doğu İstilası Tehdidi Biter & +150 Savaş Ganimeti Altını",
    description: "Vampir Lordu Malakor'un Kan Lejyonlarını topladığı, Doğu Kızıl Geçidi'ne bakan devasa obsidyen sınır kalesi."
  },
  elf_shadow_spire: {
    id: "elf_shadow_spire",
    name: "Mor Kuleler Metropolü",
    realm: "Vampir - Kara Elf İttifakı (Doğu)",
    owner: "vampire",
    terrain: "vampire",
    isCapital: true,
    isBorderFort: false,
    isPort: false,
    requiredBorderProvinces: ["vampire_citadel", "blood_necropolis"],
    resource: "🔮 Kara Elf Başkenti & Yasak Büyü Kulesi",
    x: 1045,
    y: 170,
    neighbors: ["vampire_citadel", "blood_necropolis"],
    garrison: 16,
    taxIncome: 58,
    unrest: 6,
    defenseBonus: 5,
    fortLevel: 3,
    economyLevel: 3,
    isBlockaded: false,
    perk: "Kademeli Fetih Hedefi: Önce Gölge Kalesi veya Kemik Vadisi fethedilmelidir!",
    description: "Havada asılı duran mor kristal kuleler ve Kara Elf Başbüyücülerinin yasak gölge büyülerini dokuduğu başkent."
  },
  blood_necropolis: {
    id: "blood_necropolis",
    name: "Kemik Vadisi & Kan Ayini Çölü",
    realm: "Vampir - Kara Elf İttifakı (Doğu)",
    owner: "vampire",
    terrain: "vampire",
    isCapital: false,
    isBorderFort: true,
    isPort: false,
    resource: "💀 Obsidyen Piramitler & Hortlak Mezarları",
    x: 935,
    y: 430,
    neighbors: ["vampire_citadel", "elf_shadow_spire", "dark_forest", "baron_ironkeep"],
    garrison: 11,
    taxIncome: 36,
    unrest: 12,
    defenseBonus: 3,
    fortLevel: 2,
    economyLevel: 2,
    isBlockaded: false,
    perk: "Güney-Doğu İkmal Kilit Noktası: Fethedilirse Gölge Kalesi güneyden kuşatılır",
    description: "Kızıl kum fırtınaları altında yükselen obsidyen piramitler ve Vampir ordusunu besleyen kan kristali madenleri."
  }
};

// ----------------------------------------------------------------------------
// 2B. İKMAL HATLARI (SUPPLY LINES), ABLUKA VE KADEMELİ FETİH MOTORU
// ----------------------------------------------------------------------------
window.PrinceTutu.evaluateSupplyLines = function (state) {
  if (!state || !state.provinces) return;
  const provs = state.provinces;

  // Her fraksiyonun ana ikmal kaynakları (Başkentler veya Limanlar)
  const isAlliedWithPlayer = (owner) => {
    if (owner === "player") return true;
    if (owner === "furry" && (state.relationships?.furries >= 60 || state.decrees?.furryTradePact || state.flags?.furrySenateTreaty)) return true;
    if (owner === "doxe" && (state.worldRelations?.doxe >= 60 || state.decrees?.abolishSlavery || state.flags?.doxeAlliance)) return true;
    if (owner === "tribes" && (state.worldRelations?.mountainTribes >= 60 || state.decrees?.mountainSmithGuild || state.flags?.northernForgePact)) return true;
    return false;
  };

  Object.values(provs).forEach((prov) => {
    // Manuel abluka bayrağı varsa ve düşman eyaletiyse ablukada kalır
    if (prov.manualBlockade && prov.owner !== "player") {
      prov.isBlockaded = true;
      return;
    }

    // Başkentler kendi başına ikmal kaynağıdır (ancak tüm komşuları düşman tarafından ele geçirildiyse kuşatma/abluka altına girer!)
    const hostileNeighbors = (prov.neighbors || []).filter((nId) => {
      const n = provs[nId];
      if (!n) return false;
      if (prov.owner === "player") return n.owner === "vampire" || n.owner === "brothers";
      return n.owner !== prov.owner;
    });

    if (prov.isCapital) {
      prov.isBlockaded = hostileNeighbors.length === (prov.neighbors || []).length && (prov.neighbors || []).length > 0;
      return;
    }

    // BFS ile kendi Başkentine veya dost bir Limana bağlantı kontrolü
    const visited = new Set([prov.id]);
    const queue = [prov.id];
    let connectedToSupply = false;

    while (queue.length > 0) {
      const currId = queue.shift();
      const curr = provs[currId];
      if (!curr) continue;

      if (currId !== prov.id && (curr.isCapital || curr.isPort)) {
        connectedToSupply = true;
        break;
      }

      for (const nId of curr.neighbors || []) {
        if (visited.has(nId)) continue;
        const nProv = provs[nId];
        if (!nProv) continue;

        const canTraverse =
          prov.owner === "player"
            ? isAlliedWithPlayer(nProv.owner)
            : nProv.owner === prov.owner;

        if (canTraverse) {
          visited.add(nId);
          queue.push(nId);
        }
      }
    }

    prov.isBlockaded = !connectedToSupply;
  });
};

// Kademeli Fetih Kuralı Kontrolcüsü (Başkentlere doğrudan sefer düzenlenemez)
window.PrinceTutu.canLaunchCampaign = function (state, targetId) {
  if (!state || !state.provinces || !state.provinces[targetId]) {
    return { ok: false, reason: "Bölge bulunamadı." };
  }
  const provs = state.provinces;
  const target = provs[targetId];

  if (target.owner === "player") {
    return { ok: false, reason: "Bu eyalet zaten senin kontrolünde." };
  }

  // Komşuluk kontrolü (Oyuncu veya askeri ittifak eyaletine komşu olmalı)
  const hasAdjacentLaunchpad = (target.neighbors || []).some((nId) => {
    const n = provs[nId];
    if (!n) return false;
    if (n.owner === "player") return true;
    if (n.owner === "furry" && state.flags?.furrySenateTreaty) return true;
    if (n.owner === "doxe" && state.flags?.doxeAlliance) return true;
    if (n.owner === "tribes" && state.flags?.northernForgePact) return true;
    return false;
  });

  if (!hasAdjacentLaunchpad) {
    return {
      ok: false,
      reason: "Ordunun ulaşabileceği komşu bir sınır cephesi yok! Önce aradaki sınır eyaletini fethet."
    };
  }

  // Kademeli Fetih Kuralı: Hedef bir Başkent ise önce sınır kalelerinden en az biri alınmış olmalı
  if (target.isCapital && Array.isArray(target.requiredBorderProvinces) && target.requiredBorderProvinces.length > 0) {
    const borderTaken = target.requiredBorderProvinces.some(
      (bId) => provs[bId] && provs[bId].owner === "player"
    );
    if (!borderTaken) {
      const borderNames = target.requiredBorderProvinces
        .map((bId) => provs[bId]?.name || bId)
        .join(" veya ");
      return {
        ok: false,
        reason: `Kademeli Fetih Kuralı: Başkente doğrudan sefer düzenlenemez! Önce sınır kalesini (${borderNames}) fethetmelisin.`
      };
    }
  }

  return { ok: true, reason: "Sefer yolu açık!" };
};

// ----------------------------------------------------------------------------
// 3. İMPARATORLUK BAŞARIMLARI (12 ACHIEVEMENTS - LOCALSTORAGE KALICI)
// ----------------------------------------------------------------------------
window.PrinceTutu.ACHIEVEMENTS_DATA = [
  {
    id: "chain_breaker",
    title: "⛓️ Zincir Kıran",
    desc: "İmparatorluk genelinde köleliği yasakla ve DOXE Kutsal İttifakını kur.",
    check: (s) => !!s.decrees.abolishSlavery || !!s.flags.doxeAlliance
  },
  {
    id: "sister_guardian",
    title: "🛡️ Kardeşlerin Koruyucusu",
    desc: "9 ve 13 yaşlarındaki küçük kız kardeşlerinin sevgisini 90+ seviyesine çıkar ve onları koru.",
    check: (s) => s.relationships.sister9 >= 90 && s.relationships.sister13 >= 90
  },
  {
    id: "shadow_spymaster",
    title: "🕵️ Gölge İstihbarat Efendisi",
    desc: "Casus Ağı kur, yolsuzluğu deşifre et ve Zeka istatistiğini 75+ yap.",
    check: (s) => !!s.flags.hasSpyNetwork && s.stats.intelligence >= 75
  },
  {
    id: "duel_champion",
    title: "🗡️ Taht Düellocusu",
    desc: "Ağabeyin Anzak'ı birebir kılıç düellosunda mağlup et.",
    check: (s) => !!s.flags.anzakDefeated
  },
  {
    id: "vampire_slayer",
    title: "🦇 Karanlığı Söndüren",
    desc: "Vampir-Kara Elf İttifakı'nın Gölge Kalesi'ni veya Mor Kuleler Başkentini fethet.",
    check: (s) => !!s.flags.vampireCitadelTaken || s.provinces?.elf_shadow_spire?.owner === "player"
  },
  {
    id: "golden_tycoon",
    title: "💰 Altın Çağ Ekonomisti",
    desc: "Kraliyet Hazinesinde aynı anda 350+ Altın biriktir.",
    check: (s) => s.inventory.gold >= 350
  },
  {
    id: "grand_coalition",
    title: "🌟 Üçlü Koalisyon Mimarı",
    desc: "Furry Cumhuriyeti, DOXE Krallığı ve Kuzey Dağ Klanları ile aynı anda 75+ ilişkiye ulaş.",
    check: (s) =>
      s.relationships.furries >= 75 &&
      s.worldRelations.doxe >= 75 &&
      s.worldRelations.mountainTribes >= 75
  },
  {
    id: "master_forger",
    title: "⚒️ Kraliyet Baş Demircisi",
    desc: "Saray Demirhanesinde Ayışığı Kılıcı, Furry Topçu Bataryası veya DOXE Kalkanı üret.",
    check: (s) =>
      s.inventory.items.some((i) =>
        ["moonlight_sword", "furry_cannons", "doxe_aegis"].includes(i.id)
      )
  },
  {
    id: "imperial_architect",
    title: "🏛️ Kıta Fatihi",
    desc: "18 eyaletli Büyük Dünya Atlası'nda en az 6 eyaleti doğrudan kontrol et.",
    check: (s) =>
      Object.values(s.provinces || {}).filter((p) => p.owner === "player").length >= 6
  },
  {
    id: "grand_marshal",
    title: "⚔️ Yenilmez Başkomutan",
    desc: "Saha ordunu toplam 20 veya daha fazla tabura ulaştır.",
    check: (s) =>
      s.armyComposition.infantry +
        s.armyComposition.furryArchers +
        s.armyComposition.mountainAxemen +
        s.armyComposition.doxePaladins >=
      20
  },
  {
    id: "reformist_emperor",
    title: "📜 Büyük Reformcu",
    desc: "Bir saltanatta en az 5 Kraliyet Fermanı ilan et.",
    check: (s) => Object.values(s.decrees).filter(Boolean).length >= 5
  },
  {
    id: "victorious_sovereign",
    title: "👑 Gölgelerin Tacı",
    desc: "Oyunu zafer finallerinden biriyle tamamla!",
    check: (s) => {
      const sc = window.PrinceTutu.SCENES && window.PrinceTutu.SCENES[s.scene];
      return !!(sc && sc.isEnding && sc.isVictory);
    }
  }
];

// ----------------------------------------------------------------------------
// 4. RASTGELE SARAY VE EYALET KRİZ OLAYLARI (10 ZENGİN KRİZ OLAYI)
// ----------------------------------------------------------------------------
window.PrinceTutu.RANDOM_EVENTS = [
  {
    id: "kitchen_poison",
    title: "🍷 Saray Mutfağında Zehir Şüphesi!",
    description: "9 yaşındaki küçük kız kardeşin nefes nefese yanına koştu: 'Tutu abi! Şarap mahzeninde Adem'in hizmetkarını babamızın akşam kupasına renksiz bir sıvı damlatırken gördüm!'",
    choices: [
      {
        text: "Hizmetkarı suçüstü yakalat ve kupayı Baş Danışman'a analiz ettir",
        effectText: "+8 İmparator, +6 Zeka, Kardeş Darbesi -12%",
        apply: (s) => {
          s.relationships.father = Math.min(100, s.relationships.father + 8);
          s.stats.intelligence = Math.min(100, s.stats.intelligence + 6);
          s.rivalState.brotherPlotProgress = Math.max(0, s.rivalState.brotherPlotProgress - 12);
          s.flags.knowsAboutCorruption = true;
        }
      },
      {
        text: "Şarabı Adem'in kendi ziyafet masasıyla gizlice değiştir!",
        effectText: "Adem kendi tuzağına düştü! Kardeş Darbesi -18%, -5 Ahlak, +7 Politik Güç",
        apply: (s) => {
          s.rivalState.brotherPlotProgress = Math.max(0, s.rivalState.brotherPlotProgress - 18);
          s.stats.moralStanding = Math.max(0, s.stats.moralStanding - 5);
          s.stats.politicalPower = Math.min(100, s.stats.politicalPower + 7);
        }
      }
    ]
  },
  {
    id: "caravan_raid",
    title: "🐾 Furry Barut Kervanına Pusu!",
    description: "Mavi Nehir Deltası yolunda Gümüş Pençe Limanı'ndan başkente gelen barut kervanı, Anzak'ın kışkırttığı paralı haydutlar tarafından kuşatıldı.",
    choices: [
      {
        text: "Kraliyet Muhafızlarını gönderip kervanı kurtar (25 Altın Sefer Masrafı)",
        costGold: 25,
        effectText: "-25 Altın, +12 Furry İlişkisi, +1 Furry Okçu Taburu",
        apply: (s) => {
          s.inventory.gold -= 25;
          s.relationships.furries = Math.min(100, s.relationships.furries + 12);
          s.armyComposition.furryArchers += 1;
        }
      },
      {
        text: "Haydutlara 1 tabur Piyade göndererek gözdağı ver ve malları koru",
        effectText: "+5 Askeri Destek, +5 Furry İlişkisi",
        apply: (s) => {
          s.stats.militarySupport = Math.min(100, s.stats.militarySupport + 5);
          s.relationships.furries = Math.min(100, s.relationships.furries + 5);
        }
      }
    ]
  },
  {
    id: "refugee_wave",
    title: "🦇 Doğu Sınırından Kaçan Göçmen Akını",
    description: "Vampir-Kara Elf öncü birliklerinin yaktığı sınır köylerinden yüzlerce köylü Başkent Lalo kapılarına dayandı. Soylular kapıların kapatılmasını istiyor.",
    choices: [
      {
        text: "Kapıları aç, Kraliyet ambarından 30 Altınlık erzak dağıt ve gençleri orduya al",
        costGold: 30,
        effectText: "-30 Altın, +12 Halk Desteği, +2 Kraliyet Piyade Taburu",
        apply: (s) => {
          s.inventory.gold -= 30;
          s.stats.publicSupport = Math.min(100, s.stats.publicSupport + 12);
          s.armyComposition.infantry += 2;
        }
      },
      {
        text: "Göçmenleri Doğu Kızıl Geçidi istihkam inşaatına yönlendir",
        effectText: "Doğu Kızıl Geçidi +2 Garnizon, -5 Halk Desteği",
        apply: (s) => {
          s.provinces.eastern_pass.garrison += 2;
          s.stats.publicSupport = Math.max(0, s.stats.publicSupport - 5);
        }
      }
    ]
  },
  {
    id: "doxe_preacher",
    title: "⚖️ DOXE Gezgin Rahibinin Vaazı",
    description: "Başkent meydanında Solaris Kutsal Şehri'nden gelen bir DOXE rahibi köleliğe karşı ateşli bir vaaz veriyor. Anzak'ın muhafızları rahibi tutuklamak üzere.",
    choices: [
      {
        text: "Rahibi himayene al ve kölelik karşıtı reform sözünü yinele",
        effectText: "+12 DOXE, +8 Ahlak, -6 Anzak",
        apply: (s) => {
          s.worldRelations.doxe = Math.min(100, s.worldRelations.doxe + 12);
          s.stats.moralStanding = Math.min(100, s.stats.moralStanding + 8);
          s.relationships.anzak = Math.max(0, s.relationships.anzak - 6);
        }
      },
      {
        text: "Sessizce saraya davet edip Mermer Manastır'a diplomatik mektup gönder",
        effectText: "+8 DOXE, +5 Politik Güç",
        apply: (s) => {
          s.worldRelations.doxe = Math.min(100, s.worldRelations.doxe + 8);
          s.stats.politicalPower = Math.min(100, s.stats.politicalPower + 5);
        }
      }
    ]
  },
  {
    id: "sister_cipher",
    title: "🔐 13 Yaşındaki Kız Kardeşinin Şifreli Defteri",
    description: "13 yaşındaki kız kardeşin saray kütüphanesinde Adem'in Kızıl Sancak Baronluğu muhasebecisine ait şifreli bir rüşvet defteri buldu!",
    choices: [
      {
        text: "Defteri deşifre edip rüşvetçi baronların mallarına el koy!",
        effectText: "+55 Altın Hazineye, Kardeş Darbesi -10%, +10 Kız Kardeş",
        apply: (s) => {
          s.inventory.gold += 55;
          s.rivalState.brotherPlotProgress = Math.max(0, s.rivalState.brotherPlotProgress - 10);
          s.relationships.sister13 = Math.min(100, s.relationships.sister13 + 10);
          s.flags.knowsAboutCorruption = true;
        }
      },
      {
        text: "Baronlara şantaj yaparak onları kendi safına çek!",
        effectText: "+12 Politik Güç, Kardeş Darbesi -15%",
        apply: (s) => {
          s.stats.politicalPower = Math.min(100, s.stats.politicalPower + 12);
          s.rivalState.brotherPlotProgress = Math.max(0, s.rivalState.brotherPlotProgress - 15);
          s.flags.knowsAboutCorruption = true;
        }
      }
    ]
  },
  {
    id: "northern_meteor_iron",
    title: "☄️ Mitril Yarıkları'nda Göktaşı Çeliği Bulundu!",
    description: "Kuzey Dağ Klanları madencileri, Mitril Yarıkları'na düşen parlak bir göktaşından eşsiz bir metal cevheri çıkardı. Şef Torvald cevheri kime işleyeceğini soruyor.",
    choices: [
      {
        text: "Maden ocağına 25 Altın prim gönder ve cevheri ordunun silahları için dövdür",
        costGold: 25,
        effectText: "-25 Altın, +1 Dağ Baltacısı Taburu, +8 Askeri Destek, +10 Kuzey Klanları",
        apply: (s) => {
          s.inventory.gold -= 25;
          s.armyComposition.mountainAxemen += 1;
          s.stats.militarySupport = Math.min(100, s.stats.militarySupport + 8);
          s.worldRelations.mountainTribes = Math.min(100, s.worldRelations.mountainTribes + 10);
        }
      },
      {
        text: "Cevheri Pençetaht Metropolü tüccarlarına nadir mücevher olarak sat",
        effectText: "+60 Altın Hazineye, +6 Furry İlişkisi",
        apply: (s) => {
          s.inventory.gold += 60;
          s.relationships.furries = Math.min(100, s.relationships.furries + 6);
        }
      }
    ]
  },
  {
    id: "blood_moon_omen",
    title: "🩸 Gökyüzünde Kanlı Ay Tutulması!",
    description: "Gece yarısı Başkent Lalo üzerinde kızıl bir ay tutulması gerçekleşti. Mor Kuleler Metropolü'nden sızan casuslar halk arasında 'Lalo Hanedanı lanetlendi!' dedikodusu yayıyor.",
    choices: [
      {
        text: "Bilgelik Kitabı ile astronomik tutulmayı halka açıkla ve batıl korkuyu dağıt",
        effectText: "+8 Zeka, +8 Halk Desteği, Başkent İsyan Riski -15%",
        apply: (s) => {
          s.stats.intelligence = Math.min(100, s.stats.intelligence + 8);
          s.stats.publicSupport = Math.min(100, s.stats.publicSupport + 8);
          s.provinces.capital_lalo.unrest = Math.max(0, s.provinces.capital_lalo.unrest - 15);
        }
      },
      {
        text: "DOXE rahipleriyle birlikte şehir surlarında meşaleli kutsal nöbet tuttur",
        effectText: "+10 DOXE, +1 DOXE Paladin Taburu (Eğer DOXE >= 55 ise), +6 Ahlak",
        apply: (s) => {
          s.worldRelations.doxe = Math.min(100, s.worldRelations.doxe + 10);
          s.stats.moralStanding = Math.min(100, s.stats.moralStanding + 6);
          if (s.worldRelations.doxe >= 55) {
            s.armyComposition.doxePaladins += 1;
          }
        }
      }
    ]
  },
  {
    id: "forged_seal_scandal",
    title: "📜 Sahte Kraliyet Mührü Skandalı!",
    description: "Adem'in kâtibi, baban İmparator Lalo'nun imzasını taklit ederek Mavi Nehir Deltası'ndaki 2 taburu Anzak'ın emrine kaydırmaya çalışırken yakalandı!",
    choices: [
      {
        text: "Kâtibi Divan önüne çıkarıp Adem'in sahtekarlığını tüm komutanlara ifşa et!",
        effectText: "Kardeş Darbesi -16%, +10 Politik Güç, -8 Adem",
        apply: (s) => {
          s.rivalState.brotherPlotProgress = Math.max(0, s.rivalState.brotherPlotProgress - 16);
          s.stats.politicalPower = Math.min(100, s.stats.politicalPower + 10);
          s.relationships.adem = Math.max(0, s.relationships.adem - 8);
          s.flags.knowsAboutCorruption = true;
        }
      },
      {
        text: "Sahte emri tersine çevirerek Anzak'ın kendi taburlarını Doğu Kızıl Geçidi'ne sür!",
        effectText: "Doğu Kızıl Geçidi +3 Garnizon, Güney Ovaları -2 Garnizon!",
        apply: (s) => {
          s.provinces.eastern_pass.garrison += 3;
          s.provinces.golden_plains.garrison = Math.max(2, s.provinces.golden_plains.garrison - 2);
        }
      }
    ]
  },
  {
    id: "vampire_secret_envoy",
    title: "🦇 Gece Yarısı Gölge Elçisinin Karanlık Teklifi",
    description: "Vampir Lordu Malakor'un bir Kara Elf elçisi gizlice balkonuna kondu: 'Prens Tutu, bize 40 Altın haraç verin, ordumuz 2 tur boyunca Doğu Geçidi yerine kardeşin Anzak'ın Kızıl Sancak Baronluğu'nu vursun!'",
    choices: [
      {
        text: "Elçinin teklifini reddet ve kellesini Doğu Kızıl Geçidi burçlarına as!",
        effectText: "+10 Ahlak, +10 Askeri Destek, +8 DOXE İlişkisi",
        apply: (s) => {
          s.stats.moralStanding = Math.min(100, s.stats.moralStanding + 10);
          s.stats.militarySupport = Math.min(100, s.stats.militarySupport + 10);
          s.worldRelations.doxe = Math.min(100, s.worldRelations.doxe + 8);
        }
      },
      {
        text: "Makyavelist hamle: 35 Altın verip Vampir akınını geçici olarak Anzak'ın baronlarına yönlendir!",
        costGold: 35,
        effectText: "-35 Altın, Vampir Sayacı +2 Tur, Güney Ovaları Garnizonu -3, -8 Ahlak",
        apply: (s) => {
          s.inventory.gold -= 35;
          s.rivalState.vampireInvasionTimer += 2;
          s.provinces.golden_plains.garrison = Math.max(2, s.provinces.golden_plains.garrison - 3);
          s.stats.moralStanding = Math.max(0, s.stats.moralStanding - 8);
        }
      }
    ]
  },
  {
    id: "sisters_nightmare_guard",
    title: "👧 Küçük Kız Kardeşlerin Kule Nöbeti",
    description: "9 ve 13 yaşlarındaki kız kardeşlerin, dairelerinin penceresinde Fısıltı Ormanı'ndan gelen gözcü kargalar gördüklerini söyleyerek yanına sığındı.",
    choices: [
      {
        text: "En seçkin Kraliyet Muhafızlarını kulelerine dik ve bu akşam onlara masal anlatarak yanlarında kal",
        effectText: "+12 Kız Kardeş (9), +12 Kız Kardeş (13), +6 Karizma, Kardeş Darbesi -8%",
        apply: (s) => {
          s.relationships.sister9 = Math.min(100, s.relationships.sister9 + 12);
          s.relationships.sister13 = Math.min(100, s.relationships.sister13 + 12);
          s.stats.charisma = Math.min(100, s.stats.charisma + 6);
          s.rivalState.brotherPlotProgress = Math.max(0, s.rivalState.brotherPlotProgress - 8);
          s.flags.sistersProtected = true;
        }
      },
      {
        text: "Furry Nişancılarına kargaları vurdurt; ayaklarına bağlı şifreli mesajları ele geçir!",
        effectText: "+8 Zeka, +40 Kaçakçılık Altını Ele Geçirildi, Kardeş Darbesi -12%",
        apply: (s) => {
          s.stats.intelligence = Math.min(100, s.stats.intelligence + 8);
          s.inventory.gold += 40;
          s.rivalState.brotherPlotProgress = Math.max(0, s.rivalState.brotherPlotProgress - 12);
          s.flags.sistersProtected = true;
        }
      }
    ]
  }
];

// ----------------------------------------------------------------------------
// 5. BAŞLANGIÇ OYUN DURUMU (INITIAL GAME STATE - 18 PROVINCES)
// ----------------------------------------------------------------------------
window.PrinceTutu.getInitialState = function () {
  const initialProvs = JSON.parse(JSON.stringify(window.PrinceTutu.INITIAL_PROVINCES));
  const state = {
    turn: 1,
    chapter: 1,
    scene: "throne_room_morning",
    actionPoints: 2,
    maxActionPoints: 2,
    pendingEvent: null,
    triggeredEvents: [],
    unlockedAchievements: window.PrinceTutu.loadGlobalAchievements(),
    relationships: {
      father: 60,      // İmparator Lalo (68)
      adem: 30,        // Kardeş (19)
      anzak: 25,       // Kardeş (27)
      sister9: 80,     // Küçük kız kardeş (9)
      sister13: 75,    // Küçük kız kardeş (13)
      furries: 70,     // Furry Cumhuriyeti
      people: 50,      // Halk
      advisor: 65      // Baş Danışman
    },
    worldRelations: {
      doxe: 45,          // DOXE Kutsal Krallığı
      vampireElves: 10,  // Vampir-Kara Elf İttifakı
      mountainTribes: 50 // Kuzey Dağ Kabileleri
    },
    stats: {
      politicalPower: 42,
      moralStanding: 60,
      militarySupport: 40,
      publicSupport: 50,
      intelligence: 55,
      charisma: 65
    },
    armyComposition: {
      infantry: 6,       // Kraliyet Piyadesi
      furryArchers: 2,   // Furry Keskin Nişancıları
      mountainAxemen: 1, // Dağ Baltacıları
      doxePaladins: 0    // DOXE Şövalyeleri
    },
    rivalState: {
      anzakGold: 180,
      brotherPlotProgress: 20, // 100 olursa kardeşler saray darbesi yapar!
      vampireInvasionTimer: 5, // 0 olursa Vampir-Kara Elf ordusu saldırır!
      lastRivalMove: "Anzak ve Adem, Güney Bereket Ovaları ve Kızıl Sancak Baronluğu'ndan altın topluyor."
    },
    worldState: {
      economicState: "Durgun",
      militaryStrength: "Hazırlıkta",
      slavery: "Yasal (Tartışmalı)",
      diplomaticStanding: "Gergin"
    },
    inventory: {
      gold: 160,
      items: [
        {
          id: "royal_seal",
          name: "Kraliyet Mührü",
          type: "politik",
          description: "Baban İmparator Lalo'nun verdiği resmi mühür (+5 Politik Etki)",
          power: 5
        },
        {
          id: "silver_dagger",
          name: "Gümüş Hançer",
          type: "silah",
          description: "Vampirlere ve suikastçılara karşı etkili hançer (Düelloda +8 Hasar)",
          power: 4
        },
        {
          id: "wisdom_book",
          name: "Bilgelik Kitabı",
          type: "kitap",
          description: "Eski kralların stratejilerini ve DOXE antlaşmalarını içeren kayıt",
          power: 3
        }
      ]
    },
    decrees: {
      abolishSlavery: false,
      furryTradePact: false,
      martialLaw: false,
      mountainSmithGuild: false,
      royalInquisition: false,
      imperialUniversity: false,
      freePeasantLand: false,
      easternFortifications: false,
      dragonfleetNavy: false,
      royalSisterAcademy: false
    },
    flags: {
      slaveryDiscussed: false,
      brothersConfronted: false,
      vampireThreatKnown: true,
      hasSpyNetwork: false,
      knowsAboutCorruption: false,
      easternVictory: false,
      vampireCitadelTaken: false,
      anzakDefeated: false,
      malakorDefeated: false,
      ademNetworkCrushed: false,
      sistersProtected: false,
      doxeAlliance: false,
      furrySenateTreaty: false,
      northernForgePact: false,
      fathersWillSecured: false,
      visitedSistersThisTurn: false
    },
    provinces: initialProvs,
    historyLog: [
      "👑 Tur 1: İmparator Lalo seni sabah divanına çağırdı. 18 Eyaletli Büyük Dünya Atlası ve 2 Stratejik Emir Hakkın (AP) hazır."
    ]
  };
  window.PrinceTutu.evaluateSupplyLines(state);
  return state;
};

// ----------------------------------------------------------------------------
// 6. BAŞARIM, MİRAS PUANI VE ÇOKLU KAYDET / YÜKLE SİSTEMİ
// ----------------------------------------------------------------------------
window.PrinceTutu.SAVE_KEY = "prens_tutu_v4_save_state";
window.PrinceTutu.ACHIEVEMENTS_KEY = "prens_tutu_v6_achievements";

window.PrinceTutu.loadGlobalAchievements = function () {
  try {
    const raw = localStorage.getItem(window.PrinceTutu.ACHIEVEMENTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
};

window.PrinceTutu.evaluateAchievements = function (state) {
  const unlocked = new Set(state.unlockedAchievements || window.PrinceTutu.loadGlobalAchievements());
  const newlyUnlocked = [];

  (window.PrinceTutu.ACHIEVEMENTS_DATA || []).forEach((ach) => {
    if (!unlocked.has(ach.id) && ach.check(state)) {
      unlocked.add(ach.id);
      newlyUnlocked.push(ach);
    }
  });

  const arr = Array.from(unlocked);
  state.unlockedAchievements = arr;
  try {
    localStorage.setItem(window.PrinceTutu.ACHIEVEMENTS_KEY, JSON.stringify(arr));
  } catch (e) {
    // ignore storage errors
  }
  return newlyUnlocked;
};

window.PrinceTutu.calculateLegacyScore = function (state) {
  if (!state) return 0;
  const provCount = Object.values(state.provinces || {}).filter((p) => p.owner === "player").length;
  const totalArmy =
    (state.armyComposition?.infantry || 0) +
    (state.armyComposition?.furryArchers || 0) +
    (state.armyComposition?.mountainAxemen || 0) +
    (state.armyComposition?.doxePaladins || 0);
  const statSum = Object.values(state.stats || {}).reduce((a, b) => a + b, 0);
  const decreeCount = Object.values(state.decrees || {}).filter(Boolean).length;
  const achCount = (state.unlockedAchievements || []).length;

  return Math.round(
    provCount * 130 +
      totalArmy * 30 +
      statSum * 2 +
      decreeCount * 85 +
      achCount * 100 +
      Math.floor((state.inventory?.gold || 0) * 0.8)
  );
};

window.PrinceTutu.saveGame = function (state, slot = 1) {
  try {
    const key = slot === 1 ? window.PrinceTutu.SAVE_KEY : `${window.PrinceTutu.SAVE_KEY}_slot_${slot}`;
    localStorage.setItem(key, JSON.stringify(state));
    return true;
  } catch (e) {
    return false;
  }
};

window.PrinceTutu.loadGame = function (slot = 1) {
  try {
    const key = slot === 1 ? window.PrinceTutu.SAVE_KEY : `${window.PrinceTutu.SAVE_KEY}_slot_${slot}`;
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    const fresh = window.PrinceTutu.getInitialState();

    // 8 eyaletli eski kayıtları 18 eyaletli yeni haritayla sorunsuz birleştir
    const mergedProvinces = { ...fresh.provinces };
    if (parsed.provinces) {
      Object.keys(mergedProvinces).forEach((pid) => {
        if (parsed.provinces[pid]) {
          mergedProvinces[pid] = {
            ...mergedProvinces[pid],
            owner: parsed.provinces[pid].owner || mergedProvinces[pid].owner,
            garrison: parsed.provinces[pid].garrison ?? mergedProvinces[pid].garrison,
            taxIncome: parsed.provinces[pid].taxIncome ?? mergedProvinces[pid].taxIncome,
            unrest: parsed.provinces[pid].unrest ?? mergedProvinces[pid].unrest,
            fortLevel: parsed.provinces[pid].fortLevel ?? mergedProvinces[pid].fortLevel,
            economyLevel: parsed.provinces[pid].economyLevel ?? mergedProvinces[pid].economyLevel,
            manualBlockade: !!parsed.provinces[pid].manualBlockade
          };
        }
      });
    }

    const state = {
      ...fresh,
      ...parsed,
      provinces: mergedProvinces,
      decrees: { ...fresh.decrees, ...(parsed.decrees || {}) },
      flags: { ...fresh.flags, ...(parsed.flags || {}) },
      unlockedAchievements: window.PrinceTutu.loadGlobalAchievements()
    };
    window.PrinceTutu.evaluateSupplyLines(state);
    return state;
  } catch (e) {
    return null;
  }
};

window.PrinceTutu.getSaveSlotsSummary = function () {
  return [1, 2, 3].map((slot) => {
    const data = window.PrinceTutu.loadGame(slot);
    if (!data) return { slot, empty: true };
    const sceneTitle =
      (window.PrinceTutu.SCENES && window.PrinceTutu.SCENES[data.scene]?.title) || data.scene;
    return {
      slot,
      empty: false,
      turn: data.turn,
      chapter: data.chapter,
      gold: data.inventory?.gold || 0,
      sceneTitle,
      score: window.PrinceTutu.calculateLegacyScore(data)
    };
  });
};

// ----------------------------------------------------------------------------
// 7. RAKİP YAPAY ZEKA, İKMAL/ABLUKA SİMÜLASYONU, VERGİ VE YENİLGİ MOTORU
// ----------------------------------------------------------------------------
window.PrinceTutu.processTurnSimulation = function (state) {
  const next = JSON.parse(JSON.stringify(state));
  next.turn += 1;
  next.maxActionPoints = next.decrees.imperialUniversity ? 3 : 2;
  next.actionPoints = next.maxActionPoints;
  next.flags.visitedSistersThisTurn = false;

  // 1. İkmal Hatlarını ve Abluka Durumunu Güncelle
  window.PrinceTutu.evaluateSupplyLines(next);

  // Ablukadaki tüm eyaletler her tur -2 Garnizon kaybeder ve 0 Vergi üretir!
  const blockadedNames = [];
  let turnTax = 0;

  Object.values(next.provinces).forEach((prov) => {
    if (prov.isBlockaded) {
      const oldG = prov.garrison;
      prov.garrison = Math.max(1, prov.garrison - 2);
      if (oldG > prov.garrison) {
        blockadedNames.push(prov.name);
      }
    }
    if (prov.owner === "player") {
      if (!prov.isBlockaded) {
        const effectiveTax = Math.max(5, Math.floor(prov.taxIncome * (1 - prov.unrest / 160)));
        turnTax += effectiveTax;
      }
    }
  });

  if (blockadedNames.length > 0) {
    next.historyLog.unshift(
      `⛓️ Abluka Etkisi: İkmal hattı kesik olan [${blockadedNames.slice(0, 3).join(", ")}] -2 Garnizon kaybetti ve 0 vergi üretti!`
    );
  }

  if (next.decrees.furryTradePact) turnTax += 25;
  if (next.decrees.dragonfleetNavy) turnTax += 35;
  if (next.flags.furrySenateTreaty) turnTax += 15;
  next.inventory.gold += turnTax;

  // 2. Anzak ve Adem'in Yapay Zeka Hamlesi
  if (!next.flags.anzakDefeated) {
    const brothersProvs = Object.values(next.provinces).filter(
      (p) => p.owner === "brothers" && !p.isBlockaded
    ).length;
    const brotherIncome = brothersProvs * 16;
    next.rivalState.anzakGold += brotherIncome;

    const sisterShield = next.decrees.royalSisterAcademy ? 0.7 : 1.0;
    const roll = Math.random();
    if (roll < 0.36 && next.rivalState.anzakGold >= 50) {
      next.rivalState.anzakGold -= 50;
      const plotGain = Math.round((next.flags.ademNetworkCrushed ? 7 : 12) * sisterShield);
      next.rivalState.brotherPlotProgress = Math.min(100, next.rivalState.brotherPlotProgress + plotGain);
      next.stats.politicalPower = Math.max(0, next.stats.politicalPower - 2);
      next.rivalState.lastRivalMove = `⚠️ Anzak saray muhafızlarına rüşvet dağıttı! (Darbe Hazırlığı +${plotGain}%)`;
    } else if (roll < 0.72) {
      next.provinces.capital_lalo.unrest = Math.min(100, next.provinces.capital_lalo.unrest + 7);
      const plotGain = Math.round((next.flags.ademNetworkCrushed ? 5 : 9) * sisterShield);
      next.rivalState.brotherPlotProgress = Math.min(100, next.rivalState.brotherPlotProgress + plotGain);
      next.rivalState.lastRivalMove = `🕵️ Adem başkent loncalarında kışkırtma yaptı! (Darbe Hazırlığı +${plotGain}%)`;
    } else {
      if (next.provinces.golden_plains.owner === "brothers" && !next.provinces.golden_plains.isBlockaded) {
        next.provinces.golden_plains.garrison += 2;
      } else if (next.provinces.baron_ironkeep?.owner === "brothers") {
        next.provinces.baron_ironkeep.garrison += 2;
      }
      const plotGain = Math.round(7 * sisterShield);
      next.rivalState.brotherPlotProgress = Math.min(100, next.rivalState.brotherPlotProgress + plotGain);
      next.rivalState.lastRivalMove = "⚔️ Anzak, Güney Baronluğu garnizonuna +2 paralı asker taburu yığdı.";
    }

    if (next.flags.hasSpyNetwork) {
      next.rivalState.brotherPlotProgress = Math.max(0, next.rivalState.brotherPlotProgress - 6);
    }
  } else {
    next.rivalState.lastRivalMove = "🏳️ Anzak mağlup edildiği için kardeşlerin darbe konseyi dağıldı.";
  }

  // 3. Vampir - Kara Elf İttifakı Sınır Baskısı
  if (!next.flags.vampireCitadelTaken && next.provinces.vampire_citadel.owner === "vampire") {
    next.rivalState.vampireInvasionTimer = Math.max(0, next.rivalState.vampireInvasionTimer - 1);
    if (next.rivalState.vampireInvasionTimer === 0) {
      const east = next.provinces.eastern_pass;
      if (east.owner === "player") {
        const dmg = next.decrees.easternFortifications ? 2 : 3;
        east.garrison = Math.max(0, east.garrison - dmg);
        next.historyLog.unshift(`🦇 Vampir-Kara Elf ordusu Doğu Kızıl Geçidi'ne saldırdı! (-${dmg} Garnizon)`);
        if (east.garrison === 0) {
          east.owner = "vampire";
          east.garrison = 8;
          next.historyLog.unshift("🚨 FELAKET! Doğu Kızıl Geçidi düştü! Vampir ordusu Başkent Lalo kapılarına dayandı!");
        }
      } else {
        next.scene = "ending_vampire_fall";
        next.chapter = 5;
        return next;
      }
      next.rivalState.vampireInvasionTimer = 3;
    }
  }

  // 4. KRİTİK KONTROL: Kardeşlerin Darbe Hazırlığı %100 olduysa Oyun Kaybedilir!
  if (next.rivalState.brotherPlotProgress >= 100 && !next.flags.anzakDefeated) {
    next.scene = "ending_coup_defeat";
    next.chapter = 5;
    next.historyLog.unshift("💀 SARAY DARBESİ! Anzak ve Adem'in komplosu %100'e ulaştı ve tahtı ele geçirdiler!");
    return next;
  }

  // 5. Rastgele Kriz Olayı Tetikleyici
  if (!next.pendingEvent && next.chapter < 5 && Math.random() < 0.42) {
    const available = window.PrinceTutu.RANDOM_EVENTS.filter(
      (ev) => !next.triggeredEvents.includes(ev.id)
    );
    if (available.length > 0) {
      const picked = available[Math.floor(Math.random() * available.length)];
      next.pendingEvent = picked.id;
      next.triggeredEvents.push(picked.id);
    }
  }

  window.PrinceTutu.evaluateSupplyLines(next);
  window.PrinceTutu.evaluateAchievements(next);
  next.historyLog.unshift(`💰 Tur ${next.turn}: İkmal hattı açık eyaletlerden +${turnTax} Altın vergi toplandı (${next.actionPoints} AP hazır).`);
  return next;
};

// ----------------------------------------------------------------------------
// 8. EYALET YÖNETİM AKSİYONLARI (18 Eyaletli Harita Etkileşimleri)
// ----------------------------------------------------------------------------
window.PrinceTutu.executeProvinceAction = function (state, provinceId, actionType) {
  const next = JSON.parse(JSON.stringify(state));
  const prov = next.provinces[provinceId];
  if (!prov) return { state: next, message: "Bölge bulunamadı." };

  if (next.actionPoints <= 0) {
    window.PrinceTutu.Sound.play("alert");
    return {
      state,
      message: "❌ Bu tur için Stratejik Emir Hakkın (AP) bitti! Yeni AP için hikayede ilerle."
    };
  }

  if (actionType === "recruit_garrison") {
    if (next.inventory.gold < 35) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: "❌ Garnizon ve tabur takviyesi için 35 Altın gerekli!" };
    }
    next.inventory.gold -= 35;
    next.actionPoints -= 1;
    prov.garrison += 3;
    prov.isBlockaded = false;
    next.armyComposition.infantry += 2;
    next.stats.militarySupport = Math.min(100, next.stats.militarySupport + 4);
    window.PrinceTutu.Sound.play("horn");
    next.historyLog.unshift(`🛡️ [1 AP] ${prov.name} garnizonuna +3 Tabur, saha orduna +2 Piyade eklendi.`);
    window.PrinceTutu.evaluateAchievements(next);
    return {
      state: next,
      message: `🛡️ ${prov.name} güçlendirildi (+3 Garnizon, +2 Saha Piyadesi | Kalan AP: ${next.actionPoints})`
    };
  }

  if (actionType === "pacify_unrest") {
    if (next.inventory.gold < 25) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: "❌ Halka erzak dağıtmak için 25 Altın gerekli!" };
    }
    next.inventory.gold -= 25;
    next.actionPoints -= 1;
    prov.unrest = Math.max(0, prov.unrest - 25);
    prov.taxIncome += 6;
    next.stats.publicSupport = Math.min(100, next.stats.publicSupport + 5);
    window.PrinceTutu.Sound.play("coin");
    next.historyLog.unshift(`🌾 [1 AP] ${prov.name} halkına erzak dağıtıldı (-25% İsyan, +6 Vergi).`);
    return {
      state: next,
      message: `🌾 ${prov.name} huzura kavuştu (-25% İsyan, +6 Vergi/Tur | Kalan AP: ${next.actionPoints})`
    };
  }

  if (actionType === "upgrade_infrastructure") {
    if (next.inventory.gold < 45) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: "❌ Bölgesel Kale & Lonca Yatırımı için 45 Altın gerekli!" };
    }
    next.inventory.gold -= 45;
    next.actionPoints -= 1;
    prov.economyLevel = Math.min(3, (prov.economyLevel || 1) + 1);
    prov.fortLevel = Math.min(3, (prov.fortLevel || 1) + 1);
    prov.taxIncome += 12;
    prov.defenseBonus += 1;
    prov.garrison += 1;
    prov.unrest = Math.max(0, prov.unrest - 10);
    next.stats.politicalPower = Math.min(100, next.stats.politicalPower + 5);
    window.PrinceTutu.Sound.play("anvil");
    next.historyLog.unshift(
      `🏗️ [1 AP] ${prov.name} altyapısı geliştirildi! (+12 Vergi/Tur, +1 Savunma, +1 Garnizon)`
    );
    return {
      state: next,
      message: `🏗️ ${prov.name} Kale ve Ticaret Loncası büyütüldü (+12💰/Tur, +1🏰 Savunma, +1🛡️ Garnizon)!`
    };
  }

  if (actionType === "counter_espionage") {
    if (next.inventory.gold < 20) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: "❌ Karşı-İstihbarat devriyesi için 20 Altın gerekli!" };
    }
    next.inventory.gold -= 20;
    next.actionPoints -= 1;
    prov.unrest = Math.max(0, prov.unrest - 15);
    next.rivalState.brotherPlotProgress = Math.max(0, next.rivalState.brotherPlotProgress - 12);
    next.stats.intelligence = Math.min(100, next.stats.intelligence + 4);
    window.PrinceTutu.Sound.play("sword");
    next.historyLog.unshift(
      `🕵️ [1 AP] ${prov.name} içinde Adem'in ajanları temizlendi! (Kardeş Darbesi -12%, İsyan -15%)`
    );
    return {
      state: next,
      message: `🕵️ ${prov.name} karşı-istihbarat taraması tamamlandı: Darbe Hazırlığı -12%, +4 Zeka!`
    };
  }

  if (actionType === "spy_sabotage") {
    const cost = next.flags.hasSpyNetwork ? 15 : 40;
    if (next.inventory.gold < cost) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: `❌ Sabotaj operasyonu için ${cost} Altın gerekli!` };
    }
    next.inventory.gold -= cost;
    next.actionPoints -= 1;
    const oldGarrison = prov.garrison;
    prov.garrison = Math.max(2, prov.garrison - 3);
    const reduced = oldGarrison - prov.garrison;
    prov.unrest = Math.min(100, prov.unrest + 20);
    if (prov.owner === "brothers") {
      next.rivalState.brotherPlotProgress = Math.max(0, next.rivalState.brotherPlotProgress - 8);
    }
    window.PrinceTutu.Sound.play("sword");
    next.historyLog.unshift(
      `🕵️ [1 AP] Casusların ${prov.name} ikmal depolarını havaya uçurdu! (Düşman Garnizonu -${reduced} Tabur)`
    );
    return {
      state: next,
      message: `🕵️ ${prov.name} sabote edildi! Savaşta karşısına çıkacak düşman ordusu ${reduced} tabur azaldı!`
    };
  }

  // YENİ v7.0: İkmal Hattını Kes & Ablukaya Al (Her tur -2 Garnizon, 0 Vergi!)
  if (actionType === "blockade_supply") {
    if (next.inventory.gold < 30) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: "❌ İkmal yollarını kesip abluka kurmak için 30 Altın gerekli!" };
    }
    next.inventory.gold -= 30;
    next.actionPoints -= 1;
    prov.manualBlockade = true;
    prov.isBlockaded = true;
    prov.garrison = Math.max(1, prov.garrison - 2);
    window.PrinceTutu.Sound.play("cannon");
    next.historyLog.unshift(
      `⛓️ [1 AP] ${prov.name} ikmal hatları kesildi ve ABLUKAYA alındı! (Anında -2 Garnizon ve her tur -2 Garnizon, 0 Vergi)`
    );
    return {
      state: next,
      message: `⛓️ ${prov.name} Ablukaya Alındı! Başkent bağlantısı kesildi; her tur -2 garnizon eriyecek ve vergi üretemeyecek!`
    };
  }

  if (actionType === "incite_rebellion") {
    if (next.inventory.gold < 35) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: "❌ Direnişçileri silahlandırmak için 35 Altın gerekli!" };
    }
    next.inventory.gold -= 35;
    next.actionPoints -= 1;
    const oldG = prov.garrison;
    prov.garrison = Math.max(2, prov.garrison - 4);
    const diff = oldG - prov.garrison;
    next.armyComposition.infantry += 1;
    if (prov.owner === "brothers") {
      next.rivalState.brotherPlotProgress = Math.max(0, next.rivalState.brotherPlotProgress - 14);
    }
    window.PrinceTutu.Sound.play("horn");
    next.historyLog.unshift(
      `🔥 [1 AP] ${prov.name} bölgesinde halk ayaklanması çıkarıldı! (Düşman -${diff} Garnizon, Orduna +1 Özgür Piyade)`
    );
    return {
      state: next,
      message: `🔥 ${prov.name} direnişçileri ayaklandı! Düşman -${diff} Tabur kaybetti ve +1 Piyade orduna katıldı!`
    };
  }

  if (actionType === "diplomatic_envoy") {
    if (next.inventory.gold < 30) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: "❌ Diplomatik hediye kervanı için 30 Altın gerekli!" };
    }
    next.inventory.gold -= 30;
    next.actionPoints -= 1;
    window.PrinceTutu.Sound.play("coin");

    if (prov.owner === "furry") {
      next.relationships.furries = Math.min(100, next.relationships.furries + 15);
      next.armyComposition.furryArchers += 1;
      next.flags.furrySenateTreaty = true;
      window.PrinceTutu.evaluateSupplyLines(next);
      next.historyLog.unshift(`🐾 [1 AP] ${prov.name} elçiliği başarılı (+15 İlişki, +1 Furry Nişancı Taburu).`);
      window.PrinceTutu.evaluateAchievements(next);
      return { state: next, message: `🐾 ${prov.name} Senatosu memnun oldu! Orduna +1 Furry Okçu Taburu katıldı.` };
    }
    if (prov.owner === "doxe") {
      next.worldRelations.doxe = Math.min(100, next.worldRelations.doxe + 15);
      if (next.worldRelations.doxe >= 60 || next.decrees.abolishSlavery) {
        next.armyComposition.doxePaladins += 1;
        next.flags.doxeAlliance = true;
        window.PrinceTutu.evaluateSupplyLines(next);
        next.historyLog.unshift(`⚖️ [1 AP] ${prov.name} üzerinden +1 Kutsal Paladin Taburu desteğe geldi!`);
        window.PrinceTutu.evaluateAchievements(next);
        return { state: next, message: `⚖️ ${prov.name} Başrahibi orduna +1 Kutsal Paladin Taburu gönderdi!` };
      }
      return { state: next, message: "⚖️ DOXE ile ilişkiler +15 arttı (60+ ilişkide Paladin gönderirler)." };
    }
    if (prov.owner === "tribes") {
      next.worldRelations.mountainTribes = Math.min(100, next.worldRelations.mountainTribes + 15);
      next.armyComposition.mountainAxemen += 1;
      next.flags.northernForgePact = true;
      window.PrinceTutu.evaluateSupplyLines(next);
      next.historyLog.unshift(`⚒️ [1 AP] ${prov.name} klanları orduna +1 Dağ Baltacısı Taburu gönderdi.`);
      window.PrinceTutu.evaluateAchievements(next);
      return { state: next, message: "⚒️ Dağ Klanları ile kan kardeşliği güçlendi (+1 Dağ Baltacısı Taburu)!" };
    }
  }

  if (actionType === "trade_caravan") {
    next.actionPoints -= 1;
    const profit = prov.owner === "furry" ? 65 : 50;
    next.inventory.gold += profit;
    if (prov.owner === "furry") next.relationships.furries = Math.min(100, next.relationships.furries + 8);
    if (prov.owner === "doxe") next.worldRelations.doxe = Math.min(100, next.worldRelations.doxe + 8);
    if (prov.owner === "tribes") next.worldRelations.mountainTribes = Math.min(100, next.worldRelations.mountainTribes + 8);
    window.PrinceTutu.Sound.play("coin");
    next.historyLog.unshift(`🚢 [1 AP] ${prov.name} ile Kraliyet Ticaret Kervanı tamamlandı (+${profit} Altın).`);
    window.PrinceTutu.evaluateAchievements(next);
    return {
      state: next,
      message: `🚢 ${prov.name} ticaret seferinden hazineye +${profit} Altın net kâr ve +8 Müttefik İlişkisi geldi!`
    };
  }

  return { state: next, message: "İşlem tamamlandı." };
};

// ----------------------------------------------------------------------------
// 9. KRALİYET DİVANI, HANEDAN VE DEMİRHANE AKSİYONLARI
// ----------------------------------------------------------------------------
window.PrinceTutu.executeCourtAction = function (state, actionId) {
  const next = JSON.parse(JSON.stringify(state));

  if (actionId === "visit_sisters") {
    if (next.flags.visitedSistersThisTurn) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: "👧 Bu turda kız kardeşlerinle zaten vakit geçirdin. Sonraki tur tekrar ziyaret edebilirsin." };
    }
    if (next.inventory.gold < 15) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: "❌ Kardeşlerine hediyeler ve özel muhafız tahsisi için 15 Altın gerekli!" };
    }
    next.inventory.gold -= 15;
    next.flags.visitedSistersThisTurn = true;
    next.flags.sistersProtected = true;
    next.relationships.sister9 = Math.min(100, next.relationships.sister9 + 10);
    next.relationships.sister13 = Math.min(100, next.relationships.sister13 + 10);
    next.stats.moralStanding = Math.min(100, next.stats.moralStanding + 6);
    next.rivalState.brotherPlotProgress = Math.max(0, next.rivalState.brotherPlotProgress - 10);
    window.PrinceTutu.Sound.play("magic");
    next.historyLog.unshift(
      "👧 [Hanedan] 9 ve 13 yaşındaki kız kardeşlerini ziyaret ettin; koridorda duydukları bir komployu sana fısıldadılar! (Darbe -10%)"
    );
    window.PrinceTutu.evaluateAchievements(next);
    return {
      state: next,
      message: "👧 Kız kardeşlerin çok mutlu oldu! Sana saraydaki gizli bir fısıltıyı ilettiler (+10 İlişki, +6 Ahlak, Darbe -10%)."
    };
  }

  if (actionId === "consult_emperor") {
    if (next.chapter >= 5) {
      return { state, message: "🕯️ İmparator Lalo ebediyete intikal etti." };
    }
    if (next.actionPoints <= 0) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: "❌ Bu işlem için 1 Stratejik Emir Hakkı (AP) gerekli!" };
    }
    next.actionPoints -= 1;
    next.relationships.father = Math.min(100, next.relationships.father + 12);
    next.stats.politicalPower = Math.min(100, next.stats.politicalPower + 8);
    next.stats.charisma = Math.min(100, next.stats.charisma + 6);
    next.flags.fathersWillSecured = true;
    window.PrinceTutu.Sound.play("fanfare");
    next.historyLog.unshift("👑 [1 AP] İmparator Lalo'nun hayır duasını ve devlet tecrübesini aldın (+8 Politik Güç, +6 Karizma).");
    return {
      state: next,
      message: "👑 Baban İmparator Lalo soyluların önünde sana olan güvenini ilan etti (+12 Baba, +8 Politik Güç, +6 Karizma)!"
    };
  }

  if (actionId === "grand_festival") {
    if (next.actionPoints <= 0) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: "❌ Festival düzenlemek için 1 AP gerekli!" };
    }
    if (next.inventory.gold < 50) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: "❌ İmparatorluk Şöleni için 50 Altın gerekli!" };
    }
    next.inventory.gold -= 50;
    next.actionPoints -= 1;
    next.stats.publicSupport = Math.min(100, next.stats.publicSupport + 15);
    next.stats.charisma = Math.min(100, next.stats.charisma + 8);
    next.relationships.people = Math.min(100, next.relationships.people + 15);
    Object.values(next.provinces).forEach((p) => {
      if (p.owner === "player") p.unrest = Math.max(0, p.unrest - 20);
    });
    window.PrinceTutu.Sound.play("fanfare");
    next.historyLog.unshift("🎪 [1 AP] Başkent Lalo'da Büyük Şafak Şöleni düzenlendi! (+15 Halk Desteği, Tüm Eyaletlerde -20% İsyan)");
    return {
      state: next,
      message: "🎪 Başkentte Büyük Şölen! Halk sokaklarda senin adını haykırıyor (+15 Halk Desteği, +8 Karizma, -20% İsyan)!"
    };
  }

  if (actionId === "forge_moonlight_sword") {
    if (next.inventory.items.some((i) => i.id === "moonlight_sword")) {
      return { state, message: "🗡️ Ayışığı Kraliyet Kılıcı zaten kuşandığın silahlar arasında!" };
    }
    if (next.inventory.gold < 65) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: "❌ Ayışığı Kraliyet Kılıcı dövdürmek için 65 Altın gerekli!" };
    }
    next.inventory.gold -= 65;
    next.inventory.items.push({
      id: "moonlight_sword",
      name: "Ayışığı Kraliyet Kılıcı",
      type: "silah",
      description: "Kuzey mitrili ve gümüşle dövülmüş efsanevi kılıç (Düelloda +14 Hasar & Kritik Odak)",
      power: 12
    });
    next.stats.militarySupport = Math.min(100, next.stats.militarySupport + 8);
    window.PrinceTutu.Sound.play("anvil");
    next.historyLog.unshift("⚒️ [Demirhane] Ayışığı Kraliyet Kılıcı dövüldü! (Düellolarda +14 Hasar, +8 Askeri Destek)");
    window.PrinceTutu.evaluateAchievements(next);
    return {
      state: next,
      message: "🗡️ Kraliyet Demirhanesi'nde 'Ayışığı Kraliyet Kılıcı' dövüldü! Düellolarda muazzam hasar bonusu aktif!"
    };
  }

  if (actionId === "forge_furry_cannons") {
    if (next.inventory.items.some((i) => i.id === "furry_cannons")) {
      return { state, message: "💣 Furry Barut Topçu Bataryası zaten orduna eklendi!" };
    }
    if (next.inventory.gold < 60) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: "❌ Furry Topçu Bataryası dökümü için 60 Altın gerekli!" };
    }
    next.inventory.gold -= 60;
    next.inventory.items.push({
      id: "furry_cannons",
      name: "Furry Barut Topçu Bataryası",
      type: "silah",
      description: "3v2 Muharebelerde 'Topçu Bombardımanı' yeteneğini açar ve düşman zarını sersemletir!",
      power: 10
    });
    next.armyComposition.furryArchers += 1;
    next.stats.militarySupport = Math.min(100, next.stats.militarySupport + 8);
    window.PrinceTutu.Sound.play("cannon");
    next.historyLog.unshift("💣 [Demirhane] Furry Barut Topçu Bataryası orduna katıldı! (+1 Nişancı Taburu & Savaşta Topçu Ateşi)");
    window.PrinceTutu.evaluateAchievements(next);
    return {
      state: next,
      message: "💣 Furry Barut Topçu Bataryası hazır! Artık 3v2 Muharebelerde 'Topçu Bombardımanı' kullanabilirsin!"
    };
  }

  if (actionId === "forge_doxe_aegis") {
    if (next.inventory.items.some((i) => i.id === "doxe_aegis")) {
      return { state, message: "🛡️ DOXE Kutsal Kalkanı zaten envanterinde!" };
    }
    if (next.inventory.gold < 55) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: "❌ DOXE Kutsal Kalkanı için 55 Altın gerekli!" };
    }
    next.inventory.gold -= 55;
    next.inventory.items.push({
      id: "doxe_aegis",
      name: "DOXE Kutsal Kalkanı & Sancağı",
      type: "zırh",
      description: "Düelloda +20 Maksimum Can verir ve orduna +1 DOXE Kutsal Paladin Taburu katar",
      power: 9
    });
    next.armyComposition.doxePaladins += 1;
    next.stats.moralStanding = Math.min(100, next.stats.moralStanding + 8);
    window.PrinceTutu.Sound.play("magic");
    next.historyLog.unshift("🛡️ [Demirhane] DOXE Kutsal Kalkanı & Sancağı kuşandı! (+1 Paladin Taburu, Düelloda +20 HP)");
    window.PrinceTutu.evaluateAchievements(next);
    return {
      state: next,
      message: "🛡️ DOXE Kutsal Kalkanı & Sancağı üretildi! Orduna +1 Paladin katıldı ve düello dayanıklılığın arttı!"
    };
  }

  return { state: next, message: "Saray işlemi tamamlandı." };
};
