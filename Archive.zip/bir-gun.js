// ============================================================================
// PRENS TUTU: BİR GÜN (10-15 Dakikalık Oynanabilir Görsel Roman & Karar Prototipi)
// Odak: "Tutu olarak, ailenle ilişkilerini ve ülkenin geleceğini aynı anda
//        etkileyen zor kararlar vermek."
// Sıfır harici sunucu — file:// protokolünde çift tıkla çalışır.
// ============================================================================

(function () {
  'use strict';

  var h = React.createElement;
  var useState = React.useState;
  var useEffect = React.useEffect;
  var useRef = React.useRef;

  // Klasör yolunu otomatik algıla (Ana dizinden veya /bir-gun/ alt dizininden açıldığında görseller bozulmasın)
  var ASSET_PREFIX = (function () {
    try {
      var path = window.location.pathname || '';
      if (path.indexOf('/bir-gun/') !== -1) return '../assets/';
    } catch (e) {}
    return './assets/';
  })();

  // Ses efektleri yardımcı fonksiyonu
  function playSfx(type) {
    try {
      if (window.TutuEngine && window.TutuEngine.AudioEngine) {
        var AE = window.TutuEngine.AudioEngine;
        if (type === 'choice' && AE.click) AE.click();
        else if (type === 'gold' && AE.coin) AE.coin();
        else if (type === 'guard' && AE.sword) AE.sword();
        else if (type === 'secret' && AE.victory) AE.victory();
        else if (type === 'danger' && AE.horn) AE.horn();
        else if (AE.click) AE.click();
      }
    } catch (e) {}
  }

  // Karakter Portre ve Stil Tanımları
  var CHARACTERS = {
    tutu: {
      id: 'tutu',
      name: 'Prens Tutu',
      title: 'Veliaht • Ortanca Kardeş (22)',
      img: ASSET_PREFIX + 'char_tutu.jpg',
      accent: '#f59e0b',
      border: 'border-amber-400',
      badgeBg: 'bg-amber-950/90 text-amber-300 border-amber-500/60',
      quote: 'Üç kriz, üç kardeş, tek bir gün.'
    },
    anzak: {
      id: 'anzak',
      name: 'Prens Anzak',
      title: 'Ağabey • Sınır Komutanı (27)',
      img: ASSET_PREFIX + 'char_anzak.jpg',
      accent: '#ef4444',
      border: 'border-red-500',
      badgeBg: 'bg-red-950/90 text-red-300 border-red-500/60',
      quote: 'Kızıl Geçit yanarken sarayda ferman tartışılmaz!'
    },
    adem: {
      id: 'adem',
      name: 'Prens Adem',
      title: 'Küçük Kardeş • Divan Katibi (19)',
      img: ASSET_PREFIX + 'char_adem.jpg',
      accent: '#a855f7',
      border: 'border-purple-400',
      badgeBg: 'bg-purple-950/90 text-purple-200 border-purple-500/60',
      quote: 'Bazen hepimizi kurtarmak için tek bir kağıttan vazgeçmek gerekir...'
    },
    ela: {
      id: 'ela',
      name: 'Prenses Ela',
      title: 'En Küçük Kız Kardeş (13)',
      img: ASSET_PREFIX + 'bg_palace_terrace.jpg',
      imgPos: 'center 25%',
      accent: '#38bdf8',
      border: 'border-sky-400',
      badgeBg: 'bg-sky-950/90 text-sky-200 border-sky-500/60',
      svgIcon: '🕯️',
      quote: 'Kimse bana bakmıyor diye hiçbir şey görmüyorum sanıyorlar.'
    },
    lalo: {
      id: 'lalo',
      name: 'İmparator Lalo',
      title: 'Can Çekişen Baba • Hükümdar (61)',
      img: ASSET_PREFIX + 'bg_throne.jpg',
      imgPos: 'center 30%',
      accent: '#eab308',
      border: 'border-yellow-500',
      badgeBg: 'bg-yellow-950/90 text-yellow-200 border-yellow-500/60',
      svgIcon: '👑',
      quote: 'Güneş batarken hanginizin tahta, hanginizin birbirinize layık olduğunu göreceğim.'
    },
    kassar: {
      id: 'kassar',
      name: 'Baron Kassar',
      title: 'Güney Tahıl ve Köle Loncası Başı',
      img: ASSET_PREFIX + 'bg_furry_port.jpg',
      imgPos: 'center 40%',
      accent: '#10b981',
      border: 'border-emerald-500',
      badgeBg: 'bg-emerald-950/90 text-emerald-200 border-emerald-500/60',
      svgIcon: '⚖️',
      quote: 'Aç karınlar ferman okumaz, Prensim. Ambarın anahtarı bende.'
    },
    varo: {
      id: 'varo',
      name: 'Başhekim Varo',
      title: 'Saray Hekimbaşı',
      img: ASSET_PREFIX + 'bg_doxe_cathedral.jpg',
      imgPos: 'center 35%',
      accent: '#f43f5e',
      border: 'border-rose-500',
      badgeBg: 'bg-rose-950/90 text-rose-200 border-rose-500/60',
      svgIcon: '🧪',
      quote: 'Hünkarımızın acılarını dindirmekten başka gayem yok...'
    }
  };

  // 6 Gizli Sır (Gün sonunda hangilerini çözdüğün gösterilir)
  var SECRETS_CATALOG = [
    {
      id: 'secret_letter',
      title: 'Kızıl Geçit Mektubundaki Yalan',
      summary: 'Sınır komutanı yalnızca 20 atlı istemiş. Büyük bir istila yok; Anzak orduyu arkasına alıp veliahtlığını ilan etmek için krizi büyütmüş.',
      hint: 'Silah Avlusu\'nda Anzak\'ın masadaki mühürlü sınır raporunu bizzat oku.'
    },
    {
      id: 'secret_cufflink',
      title: 'Mahzendeki Gümüş Kol Düğmesi',
      summary: 'Hekim Varo\'nun haşhaş şişelerinin yanında bulunan gümüş kol düğmesi kardeşi Adem\'e ait.',
      hint: 'Öğle vakti bitmeden Batı Kulesi\'nde küçük kız kardeşin Ela\'yı dinle.'
    },
    {
      id: 'secret_adem_debt',
      title: 'Adem\'in Baron Kassar\'a Kumar ve Senet Borcu',
      summary: 'Adem, Kassar\'a olan ağır borcu yüzünden Kölelik Fermanı\'nı geciktirmeye ve Varo\'yu saraya sokmaya mecbur bırakılmış.',
      hint: 'Divan Arşivi\'nde Adem ile yüzleş veya elindeki kanıtla onu sıkıştır.'
    },
    {
      id: 'secret_poppy_dose',
      title: 'Akşam Vasiyetini Engelleyen Haşhaş Dozu',
      summary: 'Hekim Varo, İmparator Lalo\'yu tedavi etmiyor; akşam vasiyeti imzalayamasın diye bilincini kapatan doğu haşhaşı veriyor.',
      hint: 'Hünkar Kasrı\'nı ziyaret edip Varo\'nun mahzenini veya iksir kadehini incele.'
    },
    {
      id: 'secret_grain_hoard',
      title: 'Dolu Tahıl Ambarları ve Kışkırtıcılar',
      summary: 'Kıtlık yok. Baron Kassar tahılı kasıtlı olarak ambarlarda kilitleyip halkı saraya yürümesi için gümüşle kışkırtıyor.',
      hint: 'Büyük Pazar Meydanı\'na gidip ambarları açtır veya tüccar kayıtlarını incele.'
    },
    {
      id: 'secret_master_plot',
      title: 'Üç Kriz, Tek Plan: Başkenti Boşaltma Tuzağı',
      summary: 'Kızıl Geçit\'teki akıncılar aslında Kassar\'ın kiraladığı paralı haydutlar. Amaç Anzak\'ı kışkırtıp saray muhafızlarını başkentten uzaklaştırmak!',
      hint: 'Kızıl Kule Zindanı\'ndaki yaralı sınır ulağını ve yakalanan kuryeyi sorgula.'
    }
  ];

  // Başlangıç Durumu
  function createInitialState() {
    return {
      phase: 'morning_intro', // 'morning_intro' | 'hub' | 'location_scene' | 'between_slots' | 'evening' | 'epilogue'
      introStep: 0,
      timeSlot: 0, // 0: Sabah, 1: Öğle, 2: İkindi
      guards: 3,   // 3 Saray Muhafız Birliği
      gold: 2,     // 2 Hazine Kesesi

      // İlişkiler ve Durumlar
      relAnzak: 50,
      relAdem: 50,
      relEla: 60,
      fatherRespect: 50,
      peopleCalm: false,
      decreeCompromised: false, // Kölelik fermanından taviz verildi mi?

      // Kriz Durumları
      anzakStatus: 'waiting', // 'waiting' | 'persuaded_stay' | 'controlled_march' | 'rogue_march' | 'all_guards_march'
      ademStatus: 'anxious',  // 'anxious' | 'redeemed' | 'arrested' | 'conspiring' | 'compromised_deal'
      elaStatus: 'waiting',   // 'waiting' | 'safe_ally' | 'captured' | 'rescued'
      fatherStatus: 'drugged',// 'drugged' | 'lucid' | 'talked_morning'
      kassarStatus: 'scheming', // 'scheming' | 'defeated_subsidy' | 'defeated_force' | 'appeased'

      // Ziyaret edilen yerler ve seçimler
      visited: {},
      currentLocation: null,
      locationStep: 0,
      betweenLogs: [],
      timeline: [],
      secrets: {},

      // Akşam sahnesi adımı
      eveningStep: 0,
      endingId: null
    };
  }

  var TIME_LABELS = [
    { index: 0, name: 'SABAH VAKTİ', sub: 'Güneş Doğarken • 1. Vakit (Kalan: 3)', icon: '🌅', tint: 'from-amber-900/40 via-stone-950/80 to-stone-950' },
    { index: 1, name: 'ÖĞLE VAKTİ', sub: 'Güneş Tepede • 2. Vakit (Kalan: 2)', icon: '☀️', tint: 'from-orange-900/40 via-stone-950/80 to-stone-950' },
    { index: 2, name: 'İKİNDİ VAKTİ', sub: 'Gölgeler Uzarken • Son Vakit (Kalan: 1)', icon: '🌇', tint: 'from-red-950/50 via-stone-950/85 to-stone-950' }
  ];

  // ============================================================================
  // SABAH GİRİŞİ: KAPINI ÇALAN ÜÇ KİŞİ, ÜÇ SORUN
  // ============================================================================
  var MORNING_INTRO_STEPS = [
    {
      speaker: 'tutu',
      bg: ASSET_PREFIX + 'bg_throne.jpg',
      locationTag: 'BAŞKENT LALO • ŞAFAK VAKTİ',
      title: 'Babamızın Son Günü',
      text: 'İmparator Lalo üç gündür yatağından kalkamıyor. Saray koridorlarında herkes fısıltıyla konuşuyor; çünkü bu akşam güneş battığında Hünkar son vasiyetini mühürleyecek. Tahtın kime kalacağı ve yıllardır hazırladığı "Köleliği Kaldırma Fermanı"nın yaşayıp yaşamayacağı bu gece belli olacak.\n\nDaha çizmelerini giymeden dairenin meşe kapısı üst üste üç kez yumruklandı.',
      choices: [
        {
          label: 'Kapıyı aç. Sabahın ilk kriziyle yüzleş.',
          nextStep: 1
        }
      ]
    },
    {
      speaker: 'anzak',
      bg: ASSET_PREFIX + 'bg_duel_arena.jpg',
      locationTag: '1. KRİZ • KIZIL GEÇİT VE AĞABEYİN ANZAK',
      title: 'Kılıç Kuşanmış Ağabey',
      text: 'Ağabeyin Anzak tam zırhıyla eşikte duruyor. Elinde mührü kırılmış bir sınır pusulası var.\n\n"Tutu! Kızıl Geçit\'te doğu akıncıları sınır karakolunu yakmış. Babam komada, emir verecek halde değil. Saraydaki 3 Muhafız Birliğinin tamamını bana devret, öğleden önce geçide yürüyeyim! Eğer bugün zaferle dönmezsem sınır düşer!"\n\nGözlerindeki ateşi tanıyorsun: Sınırda kahraman olursa, akşamki vasiyette ordu onun arkasında duracak. Ama saraydaki tüm muhafızları götürürse başkent tamamen savunmasız kalır.',
      choices: [
        {
          label: '"Anzak, sarayı tamamen boşaltamayız. Silah Avlusu\'nda bekle; raporu inceleyip yanına geleceğim."',
          effect: function (s) {
            s.timeline.push('Sabah Kapısı: Anzak\'a hemen muhafız vermedin, avluda beklemesini söyledin.');
          },
          nextStep: 2
        },
        {
          label: '"Al 1 Muhafız Birliğini, öncü olarak hazırlan; ama emrim olmadan yola çıkma." (-1 🛡️ Muhafız)',
          effect: function (s) {
            s.guards = Math.max(0, s.guards - 1);
            s.relAnzak += 10;
            s.anzakStatus = 'controlled_march';
            s.timeline.push('Sabah Kapısı: Anzak\'a 1 Muhafız Birliği verdin, sarayda 2 birlik kaldı.');
          },
          nextStep: 2
        }
      ]
    },
    {
      speaker: 'adem',
      bg: ASSET_PREFIX + 'bg_council.jpg',
      locationTag: '2. KRİZ • EKMEK İSYANI VE KARDEŞİN ADEM',
      title: 'Titreyen Eller, Kilitli Ambarlar',
      text: 'Anzak merdivenlerden inerken, küçük kardeşin Adem nefes nefese içeri dalıyor. Parmaklarında mürekkep lekeleri, gözlerinin altında uykusuzluk halkaları var.\n\n"Ağabey... Büyük Pazar\'da ekmek fiyatı bu sabah iki katına çıktı! Güney Baronu Kassar bütün tahıl ambarlarını kilitledi. Bana haber gönderdi: Eğer babamızın bu akşam imzalayacağı Köleliği Kaldırma Fermanı\'nı ertelersen, ambarları hemen açacak. Yoksa öğleden sonra aç halkı saray kapısına yürütecek!"\n\nAdem\'in sesi gereğinden fazla panik dolu. Sanki sadece halktan değil, Kassar\'ın kendisinden de ölümüne korkuyor.',
      choices: [
        {
          label: '"Adem, gözlerime bak. Kassar neden bu teklifi doğrudan bana değil de sana yaptı?"',
          effect: function (s) {
            s.relAdem -= 5;
            s.timeline.push('Sabah Kapısı: Adem\'in Baron Kassar ile olan tuhaf bağından şüphelendin.');
          },
          nextStep: 3
        },
        {
          label: '"Sakin ol Adem. Divan Arşivi\'ne geç, tahıl kayıtlarını ve fermanı hazırla; öğleden önce oraya gelmeye çalışacağım."',
          effect: function (s) {
            s.relAdem += 5;
            s.timeline.push('Sabah Kapısı: Adem\'i yatıştırıp Divan Arşivi\'ne yönlendirdin.');
          },
          nextStep: 3
        }
      ]
    },
    {
      speaker: 'ela',
      bg: ASSET_PREFIX + 'bg_palace_terrace.jpg',
      locationTag: '3. KRİZ • KÜÇÜK KIZ KARDEŞİN ELA VE HAŞHAŞ ŞİŞESİ',
      title: 'Koridorun Gölgesindeki Fısıltı',
      text: 'Tam kapıyı kapatacakken, 13 yaşındaki kız kardeşin Ela sütunun arkasından çıkıp cübbenin yenini tutuyor. Küçük avucunda koyu renkli, dibinde kızıl tortu kalmış bir cam şişe var.\n\n"Tutu abi... Babam hastalıktan konuşamıyor değil! Hekim Varo ona her öğlen doğu haşhaşı içiriyor, dün gece mahzenin penceresinden gördüm! Üstelik Varo\'nun yanından pelerinli biri çıktı, düşürdüğü şeyi sakladım... Anzak abime söyledim \'çocuk masalı\' dedi, Adem abime söyledim yüzü bembeyaz oldu. Abi, bugün öğleye kadar Batı Kulesi\'ne yanıma gelmezsen, yemin ederim mahzene tek başıma girip kanıtı alacağım!"',
      choices: [
        {
          label: '"Ela, sakın tek başına mahzene inme! Söz veriyorum, fırsat bulur bulmaz Batı Kulesi\'ne geleceğim."',
          effect: function (s) {
            s.relEla += 10;
            s.timeline.push('Sabah Kapısı: Ela sana haşhaş şişesinden bahsetti; öğleye kadar gelmezsen tek başına harekete geçecek.');
            s.phase = 'hub';
          }
        },
        {
          label: '"Şu an sınır ve pazar yanıyor Ela, odana kapan ve kapıyı kilitle."',
          effect: function (s) {
            s.relEla -= 10;
            s.timeline.push('Sabah Kapısı: Ela\'nın uyarısını erteledin; gözlerinde inatçı bir kırgınlıkla uzaklaştı.');
            s.phase = 'hub';
          }
        }
      ]
    }
  ];

  // ============================================================================
  // 6 MEKÂN TANIMI (3 VAKİTTE SADECE 3 TANESİNE GİDİLEBİLİR)
  // ============================================================================
  var LOCATIONS = [
    {
      id: 'courtyard_anzak',
      name: 'Silah Avlusu & Sınır Haritası',
      charId: 'anzak',
      shortRole: 'Anzak (27) • Kızıl Geçit Krizi',
      bg: ASSET_PREFIX + 'bg_duel_arena.jpg',
      icon: '⚔️',
      urgencyText: function (s) {
        if (s.anzakStatus === 'rogue_march') return 'Anzak muhafızları alıp yola çıktı!';
        if (s.anzakStatus === 'persuaded_stay') return 'Anzak sarayda kalmaya ikna oldu.';
        if (s.timeSlot === 0) return 'Anzak atları eyerliyor. Gitmezsen kendi başına hareket edebilir.';
        return 'Anzak sabırsızlanıyor!';
      },
      summary: 'Ağabeyin Anzak sınır seferi için muhafızları bekliyor. Sınır raporunun aslını inceleyebilir veya onunla yüzleşebilirsin.'
    },
    {
      id: 'west_tower_ela',
      name: 'Batı Kulesi & Eski Kütüphane',
      charId: 'ela',
      shortRole: 'Ela (13) • Haşhaş & Gizli Tanık',
      bg: ASSET_PREFIX + 'bg_palace_terrace.jpg',
      icon: '🕯️',
      urgencyText: function (s) {
        if (s.elaStatus === 'captured') return 'KRİTİK: Ela kulede yok! Mahzende yakalandı!';
        if (s.elaStatus === 'safe_ally') return 'Ela güvende ve bulduğu kanıtı sana verdi.';
        if (s.timeSlot === 0) return 'Öğleye kadar gitmezsen tek başına mahzene girecek!';
        if (s.timeSlot === 1) return 'SON ŞANS! Bu vakit gitmezsen Ela tek başına tehlikeye atılacak!';
        return 'Kule sessiz...';
      },
      summary: 'Küçük kız kardeşin Ela, Hekim Varo\'nun mahzeninde gördüğü pelerinli kişinin kanıtını saklıyor.'
    },
    {
      id: 'archive_adem',
      name: 'Divan Arşivi & Hazine Dairesi',
      charId: 'adem',
      shortRole: 'Adem (19) • Ferman & Gizli Borç',
      bg: ASSET_PREFIX + 'bg_council.jpg',
      icon: '📜',
      urgencyText: function (s) {
        if (s.ademStatus === 'redeemed') return 'Adem borcundan kurtuldu, akşam senin yanında duracak.';
        if (s.ademStatus === 'arrested') return 'Adem gözetim altında tutuluyor.';
        if (s.ademStatus === 'conspiring') return 'Adem panik içinde Kassar ile bağını gizlemeye çalışıyor.';
        return 'Adem Kölelik Fermanı ve tahıl defterlerinin başında tek başına.';
      },
      summary: 'Kardeşin Adem neden Baron Kassar\'ın şartını kabul etmen için bu kadar çırpınıyor? Hesap defterleri burada.'
    },
    {
      id: 'royal_chamber_father',
      name: 'Hünkar Kasrı & Hekim Mahzeni',
      charId: 'lalo',
      shortRole: 'İmparator Lalo & Hekim Varo',
      bg: ASSET_PREFIX + 'bg_throne.jpg',
      icon: '👑',
      urgencyText: function (s) {
        if (s.fatherStatus === 'lucid') return 'Babanın bilinci açık; akşam vasiyet için hazır.';
        if (s.timeSlot === 0) return 'Sabah vakti: Baban henüz öğle ilacını içmedi, yarı uyanık!';
        return 'Öğleden sonra: Hekim Varo babanı haşhaşla uyuttu. Uyandırmak için panzehir şart!';
      },
      summary: 'Ölüm döşeğindeki baban İmparator Lalo ve başından ayrılmayan Hekim Varo. Vasiyetin kaderi bu odada.'
    },
    {
      id: 'grand_market_kassar',
      name: 'Büyük Pazar & Tahıl Ambarları',
      charId: 'kassar',
      shortRole: 'Baron Kassar & Aç Halk',
      bg: ASSET_PREFIX + 'bg_furry_port.jpg',
      icon: '⚖️',
      urgencyText: function (s) {
        if (s.peopleCalm) return 'Pazar meydanı sakinleşti, halkın karnı doydu.';
        return 'Ekmek fiyatı iki katında! Halk akşam saray kapısına yürümek üzere.';
      },
      summary: 'Kilitli tahıl ambarları ve öfkeli kalabalık. Altınla sübvanse edebilir, muhafızla ambarı kırabilir veya Kassar ile masaya oturabilirsin.'
    },
    {
      id: 'red_dungeon_spy',
      name: 'Kızıl Kule Zindanı & Ulak Hücresi',
      charId: 'tutu',
      shortRole: 'Sınır Ulağı & Kassar\'ın Kuryesi',
      bg: ASSET_PREFIX + 'bg_vampire_citadel.jpg',
      icon: '🗝️',
      urgencyText: function (s) {
        return 'Kızıl Geçit\'ten gelen yaralı ulak ve dün gece yakalanan kurye burada.';
      },
      summary: 'Sınır saldırısı, ekmek krizi ve babanın hastalığı aynı güne mi denk geldi, yoksa hepsi tek bir elden mi çıktı?'
    }
  ];

  // ============================================================================
  // MEKÂN İÇİ SAHNE VE KARAR AĞAÇLARI
  // ============================================================================
  function getLocationScene(state) {
    var loc = state.currentLocation;
    var step = state.locationStep;

    // ------------------------------------------------------------------------
    // 1. SİLAH AVLUSU (ANZAK)
    // ------------------------------------------------------------------------
    if (loc === 'courtyard_anzak') {
      if (state.anzakStatus === 'rogue_march') {
        return {
          speaker: 'tutu',
          bg: ASSET_PREFIX + 'bg_duel_arena.jpg',
          title: 'Boş Kalan Avlu ve Kırık Mühür',
          text: 'Silah Avlusu\'na vardığında Anzak çoktan gitmiş! Sen başka krizlerle uğraşırken beklemeyi reddetmiş ve saray muhafızlarından 1 birliği emrivakiyle peşine takıp Doğu Kapısı\'ndan çıkmış.\n\nAncak çadırındaki taş masanın üzerinde, aceleyle bıraktığı orijinal sınır mektubunu buluyorsun. Mektubu okuduğunda kanın donuyor:\n\n"Komutan Anzak, Kızıl Geçit\'te yalnızca bir düzine kaçakçı görüldü. 20 atlı göndermeniz kafidir."\n\nOrtada bir ordu istilası yok! Anzak, akşam vasiyet okunurken sınır fatihi olarak saraya dönüp tahtı talep etmek için krizi uydurmuş.',
          secretUnlocked: 'secret_letter',
          choices: [
            {
              label: 'Mektubu cebine koy. Akşam divanda Anzak\'ın gerçek niyetini kanıtlayacaksın. (Vakti Tamamla)',
              action: function (s) {
                s.secrets.secret_letter = true;
                s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Silah Avlusu: Anzak çoktan gitmişti ama sahte istila mektubunu ele geçirdin.');
              }
            }
          ]
        };
      }

      if (step === 0) {
        return {
          speaker: 'anzak',
          bg: ASSET_PREFIX + 'bg_duel_arena.jpg',
          title: 'Kızıl Geçit Haritası Başında',
          text: 'Anzak avluda zırhının kayışlarını sıkıyor. Masanın üzerinde Kızıl Geçit haritası ve yarı katlanmış mühürlü bir parşömen duruyor.\n\n"Nihayet geldin Tutu! Atlar hazır. Saray muhafızlarını ver, akşam olmadan akıncıların başını ezip döneyim. Babam gözlerini açtığında Lalo İmparatorluğu\'nu kimin kılıcının koruduğunu görsün!"\n\nGöz ucuyla masadaki parşömene bakıyorsun. Anzak fark ettiğini anlayınca elini kağıdın üzerine koyuyor.',
          choices: [
            {
              label: '"O elinin altındaki sınır raporunu ver Anzak. Kaç düşman olduğunu kendi gözümle okuyacağım."',
              nextStep: 1
            },
            {
              label: 'Raporu sorma; ağabeyine güven ve saraydan 1 Muhafız Birliği daha ver. (-1 🛡️ Muhafız)',
              disabled: state.guards < 1,
              action: function (s) {
                s.guards -= 1;
                s.relAnzak += 15;
                s.anzakStatus = 'controlled_march';
                s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Silah Avlusu: Raporu sorgulamadan Anzak\'a muhafız desteği verdin.');
              }
            }
          ]
        };
      }

      return {
        speaker: 'anzak',
        bg: ASSET_PREFIX + 'bg_duel_arena.jpg',
        title: 'Yirmi Atlılık Gerçek',
        secretUnlocked: 'secret_letter',
        text: 'Mektubu Anzak\'ın elinden çekip okuyorsun. Satırlar çok net: Sınır komutanı yalnızca "yirmi atlı" istemiş! Ortada büyük bir kuşatma yok.\n\nAnzak dişlerini sıkarak sana yaklaşıyor, sesi ilk kez titriyor:\n\n"Yirmi atlıyla gidip sıradan bir devriye mi olayım Tutu?! Babam her zaman seni ve Adem\'i yanına aldı, bana sadece sınırın çamurunu bıraktı! Bu akşam vasiyet yazılırken elimde bir zafer olmazsa beni yine kapı dışarı edeceksiniz!"',
        choices: [
          {
            label: '"Anzak, sen benim ağabeyimsin. Taht kavgası için sarayı savunmasız bırakma; bu akşam babanın huzurunda Kuzey ve Doğu Orduları Başkomutanlığını senin hakkın olarak savunacağım. Kal."',
            action: function (s) {
              s.secrets.secret_letter = true;
              s.relAnzak += 25;
              s.anzakStatus = 'persuaded_stay';
              s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Silah Avlusu: Mektuptaki gerçeği buldun ve Anzak\'ı onur sözüyle sarayda kalmaya ikna ettin!');
            }
          },
          {
            label: '"Sahte raporla muhafız istemek ihanettir! Kılıcını bırak ve akşamki divana kadar dairenden çıkma!"',
            action: function (s) {
              s.secrets.secret_letter = true;
              s.relAnzak -= 25;
              s.anzakStatus = 'persuaded_stay';
              s.fatherRespect += 10;
              s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Silah Avlusu: Anzak\'ın yalanını yüzüne vurup onu sertçe durdurdun. Aranızdaki bağ koptu.');
            }
          },
          {
            label: '"Şan istiyorsan git Anzak, ama saray muhafızlarını değil, sadece kendi 20 muhafızını götür."',
            action: function (s) {
              s.secrets.secret_letter = true;
              s.relAnzak += 5;
              s.anzakStatus = 'controlled_march';
              s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Silah Avlusu: Saray muhafızlarını korudun, Anzak\'ı sadece küçük bir devriyeyle gönderdin.');
            }
          }
        ]
      };
    }

    // ------------------------------------------------------------------------
    // 2. BATI KULESİ (KÜÇÜK KIZ KARDEŞİN ELA)
    // ------------------------------------------------------------------------
    if (loc === 'west_tower_ela') {
      if (state.elaStatus === 'captured') {
        return {
          speaker: 'tutu',
          bg: ASSET_PREFIX + 'bg_palace_terrace.jpg',
          title: 'Devrilmiş Şamdan ve Kırık Pencere',
          text: 'Batı Kulesi\'ne çıktığında çok geç kaldığını anlıyorsun! Öğle vakti bitene kadar kimse yanına gelmeyince, 13 yaşındaki Ela sözünü tutmuş ve Hekim Varo\'nun mahzenine tek başına inmiş.\n\nYerde Ela\'nın mavi kurdelesi ve halının altına sıkıştırdığı gümüş işlemeli bir kol düğmesi duruyor. Kol düğmesinin üzerinde küçük kardeşin **Adem\'in** mühür arması var!\n\nTam o sırada kulenin mazgalına saplanmış imzasız bir pusula görüyorsun: *"Küçük kuş bizim misafirimiz. Akşam vasiyette Kölelik Fermanı yırtılmazsa ötmeyi kesecek."*',
          secretUnlocked: 'secret_cufflink',
          choices: [
            {
              label: 'Adem\'in kol düğmesini ve pusulayı al. Akşam Ela\'yı kurtarmak için muhafızlara ihtiyacın olacak!',
              action: function (s) {
                s.secrets.secret_cufflink = true;
                s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Batı Kulesi: Çok geç kaldın! Ela rehin alınmış ama bıraktığı Adem\'in kol düğmesini buldun.');
              }
            }
          ]
        };
      }

      if (step === 0) {
        return {
          speaker: 'ela',
          bg: ASSET_PREFIX + 'bg_palace_terrace.jpg',
          title: 'Çocuk Değil, Sarayın Tek Gören Gözü',
          text: 'Batı Kulesi\'nin kapısını tıklattığında Ela hızla sürgüyü açıyor. Seni görünce korkudan titreyen omuzları gevşiyor ve koşup koluna sarılıyor.\n\n"Geldin Tutu abi! Gelmeyeceksin, sen de Anzak abim gibi beni başından savacaksın sandım..."\n\nAvucunu açıyor. Haşhaş şişesinin yanında, gümüş telkari işlemeli bir kol düğmesi duruyor.\n\n"Dün gece Hekim Varo\'ya haşhaş kesesini teslim eden pelerinli adam mahzenden çıkarken bunu düşürdü abi. Bu kol düğmesi... Adem abimin tören gömleğine ait!"',
          secretUnlocked: 'secret_cufflink',
          choices: [
            {
              label: '"Aferin benim cesur kardeşim. Bana gerçeği gösterdin. Şimdi nasıl hareket edeceğimize birlikte karar verelim."',
              nextStep: 1
            }
          ]
        };
      }

      return {
        speaker: 'ela',
        bg: ASSET_PREFIX + 'bg_palace_terrace.jpg',
        title: 'Ela\'nın Güvenliği ve Kanıt',
        text: 'Ela gözlerini silip ciddiyetle sana bakıyor:\n\n"Hekim Varo bugün öğleden sonra babama en ağır dozu verecek abi. Akşam vasiyet saatinde babam tek kelime bile edemesin istiyorlar. Adem abim neden böyle bir şey yapsın? Onu Kassar mı tehdit ediyor?"',
        choices: [
          {
            label: '"Kanıtları bana ver Ela. Seni koruması için kapına 1 Muhafız Birliği bırakıyorum; akşama kadar güvendesin." (-1 🛡️ Muhafız)',
            disabled: state.guards < 1,
            action: function (s) {
              s.secrets.secret_cufflink = true;
              s.guards -= 1;
              s.relEla += 25;
              s.elaStatus = 'safe_ally';
              s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Batı Kulesi: Ela\'dan Adem\'in kol düğmesini aldın ve kapısına 1 Muhafız dikerek onu tam korumaya aldın.');
            }
          },
          {
            label: '"Muhafızlarımız sınırlı Ela; ama benim dairemin gizli geçidinde saklanacaksın. Akşam divanda benimle birlikte şahitlik edeceksin."',
            action: function (s) {
              s.secrets.secret_cufflink = true;
              s.relEla += 20;
              s.elaStatus = 'safe_ally';
              s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Batı Kulesi: Ela\'yı tek başına gitmekten vazgeçirip güvenli geçide sakladın; Adem\'in kol düğmesi sende.');
            }
          }
        ]
      };
    }

    // ------------------------------------------------------------------------
    // 3. DİVAN ARŞİVİ (KARDEŞİN ADEM)
    // ------------------------------------------------------------------------
    if (loc === 'archive_adem') {
      if (step === 0) {
        var hasCufflink = !!state.secrets.secret_cufflink;
        return {
          speaker: 'adem',
          bg: ASSET_PREFIX + 'bg_council.jpg',
          title: 'Mühürlü Ferman ve Gizlenen Defter',
          text: 'Divan Arşivi\'nde mumlar erimiş. Kardeşin Adem, babamızın yıllardır üzerinde çalıştığı "Köleliği Kaldırma Fermanı"nın başında duruyor. Seni görünce açık duran özel bir borç senedini hızla cübbesinin altına çekiyor.\n\n"Tutu... Pazar meydanından haber geldi, Kassar beklemekten vazgeçiyor. Eğer fermanı bugün rafa kaldırmazsak her şeyimizi kaybedeceğiz!"' +
            (hasCufflink ? '\n\nElini cebine atıyorsun; Ela\'nın mahzende bulduğu, Adem\'e ait gümüş kol düğmesi parmaklarının arasında.' : ''),
          choices: [
            hasCufflink ? {
              label: 'Gümüş kol düğmesini masaya bırak: "Bunu dün gece Hekim Varo\'nun mahzeninde düşürmüşsün Adem. Babamı neden uyutuyorsunuz?!"',
              nextStep: 1
            } : {
              label: 'Cübbesinin altına sakladığı senedi çekip al: "Benden ne saklıyorsun Adem?!"',
              nextStep: 1
            }
          ]
        };
      }

      return {
        speaker: 'adem',
        bg: ASSET_PREFIX + 'bg_council.jpg',
        title: 'Kardeşin İtirafı: Borç ve Korku',
        secretUnlocked: 'secret_adem_debt',
        text: 'Adem olduğu yere çöküyor, yüzünü ellerinin arasına alıyor.\n\n"Yemin ederim babamı zehirlemiyorum Tutu! Geçen kış güney loncalarını kendi tarafımıza çekmek için Baron Kassar\'dan 2 kese altın borç aldım... Faiziyle beni esir aldı! Bana dedi ki: \'Ya Hekim Varo\'nun imparatoru birkaç gün uyutmasına göz yumarsın ve fermanı ertelersin, ya da senetleri açıklayıp seni vatan hainliğiyle idam ettiririm!\' Varo bana sadece ağrı kesici haşhaş verdiğini söyledi... Babamı öldürmek istemedim ağabey, sadece zaman kazanmak istedim!"',
        choices: [
          {
            label: 'Hazineden 2 Kese Altın çıkarıp senedi kapat: "Sen benim kardeşimsin Adem. Borcunu ödüyorum; ama bu akşam divanda Kassar ve Varo\'yu kendi ağzınla ifşa edeceksin!" (-2 💰 Altın)',
            disabled: state.gold < 2,
            action: function (s) {
              s.secrets.secret_adem_debt = true;
              s.gold -= 2;
              s.relAdem += 30;
              s.ademStatus = 'redeemed';
              s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Divan Arşivi: Tüm hazineyi (2 Kese Altın) verip Adem\'in borcunu kapattın ve onu Kassar\'a karşı yanına çektin.');
            }
          },
          {
            label: '"Hata yapmışsın ama seni Kassar\'a yem etmem. Gel birlikte babama her şeyi itiraf edelim; bedeli neyse kardeşçe ödeyelim."',
            action: function (s) {
              s.secrets.secret_adem_debt = true;
              s.relAdem += 15;
              s.fatherRespect += 10;
              s.ademStatus = 'redeemed';
              s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Divan Arşivi: Altının yetmedi/harcamadın ama Adem\'i dürüstçe itiraf etmeye ikna ettin.');
            }
          },
          {
            label: '"Babamızın kanı üzerinden pazarlık yapan kardeşim olamaz! Muhafızlar, Adem\'i akşamki divana kadar hücreye kapatın!" (-1 🛡️ Muhafız)',
            disabled: state.guards < 1,
            action: function (s) {
              s.secrets.secret_adem_debt = true;
              s.guards -= 1;
              s.relAdem -= 35;
              s.fatherRespect += 15;
              s.ademStatus = 'arrested';
              s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Divan Arşivi: Adem\'i vatana ihanetten tutuklattın.');
            }
          },
          {
            label: '"Adem\'in başı yanmasın... Fermanı erteliyorum, git Kassar\'a söyle senedini yırtsın ve ambarları açsın."',
            action: function (s) {
              s.secrets.secret_adem_debt = true;
              s.relAdem += 20;
              s.fatherRespect -= 30;
              s.decreeCompromised = true;
              s.peopleCalm = true;
              s.ademStatus = 'compromised_deal';
              s.kassarStatus = 'appeased';
              s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Divan Arşivi: Kardeşin Adem\'i kurtarmak için babanın Kölelik Fermanı\'ndan vazgeçtin.');
            }
          }
        ]
      };
    }

    // ------------------------------------------------------------------------
    // 4. HÜNKAR KASRI & HEKİM MAHZENİ (BABAN & HEKİM VARO)
    // ------------------------------------------------------------------------
    if (loc === 'royal_chamber_father') {
      var isMorning = state.timeSlot === 0;
      if (step === 0) {
        return {
          speaker: isMorning ? 'lalo' : 'varo',
          bg: ASSET_PREFIX + 'bg_throne.jpg',
          title: isMorning ? 'Sabah Güneşi ve Yarı Açık Gözler' : 'Ağır Haşhaş Kokusu ve Uyuyan İmparator',
          secretUnlocked: 'secret_poppy_dose',
          text: isMorning
            ? 'Sabah vakti olduğu için Hekim Varo henüz öğle iksirini içirememiş! İmparator Lalo yastığında doğrulmaya çalışıyor, seni görünce kuru dudaklarında zayıf bir tebessüm beliriyor.\n\n"Tutu... Oğlum. Masadaki bakır kadehe bak... Varo her öğlen onu içirdiğinde sesim kısılıyor, kolum kalkmıyor. Bu akşam vasiyeti yazamazsam Anzak kılıcına, Adem korkusuna yenilecek..."'
            : 'Odaya girdiğinde ağır, tatlımsı bir duman genzini yakıyor. Öğle vakti geçtiği için Hekim Varo çoktan haşhaşlı kadehi babana içirmiş! İmparator Lalo derin, yapay bir uykuda.\n\nHekim Varo önünde eğiliyor: "Prensim, Hünkarımız çok ızdırap çekiyordu, dinlenmeleri için şurup verdim. Yarına kadar uyanamazlar..."\n\nOysa biliyorsun: Bu akşam uyanamazsa vasiyet yazılamayacak!',
          choices: isMorning
            ? [
                {
                  label: 'Masadaki haşhaşlı kadehi yere dök, Varo\'yu kov ve babanla baş başa konuş!',
                  nextStep: 1
                }
              ]
            : [
                {
                  label: '1 Muhafız Birliği ile Hekim Varo\'nun mahzenini bas ve ayıltıcı panzehiri zorla al! (-1 🛡️ Muhafız)',
                  disabled: state.guards < 1,
                  action: function (s) {
                    s.secrets.secret_poppy_dose = true;
                    s.guards -= 1;
                    s.fatherStatus = 'lucid';
                    s.fatherRespect += 20;
                    s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Hünkar Kasrı: Muhafızlarla Varo\'yu etkisiz hale getirip panzehirle babanı uyandırdın.');
                  }
                },
                {
                  label: 'Hekim çırağına 1 Kese Altın vererek gizli ayıltıcı otu satın al ve babana içir. (-1 💰 Altın)',
                  disabled: state.gold < 1,
                  action: function (s) {
                    s.secrets.secret_poppy_dose = true;
                    s.gold -= 1;
                    s.fatherStatus = 'lucid';
                    s.fatherRespect += 15;
                    s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Hünkar Kasrı: 1 Kese Altın ile panzehiri bulup babanın bilincini açtın.');
                  }
                },
                {
                  label: 'Kadehten numune al ama ne muhafızın ne altının var; baban akşam yarı baygın olacak...',
                  action: function (s) {
                    s.secrets.secret_poppy_dose = true;
                    s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Hünkar Kasrı: Haşhaş komplosunu öğrendin ama babanı uyandıracak kaynağın yoktu.');
                  }
                }
              ]
        };
      }

      // Sabah babanla özel konuşma (step 1)
      return {
        speaker: 'lalo',
        bg: ASSET_PREFIX + 'bg_throne.jpg',
        title: 'Babanın Son Sınavı',
        text: 'Bakır kadeh mermer zeminde parçalanıyor. Hekim Varo muhafız korkusuyla geri çekilirken, baban elini sıkıca tutuyor:\n\n"Beni dinle Tutu... Bu akşam güneş battığında tahtı sana bırakmak istiyorum. Ama iki şartım var: Birincisi, ömrümün son eseri olan Köleliği Kaldırma Fermanı\'nı Baron Kassar\'a yem etmeyeceksin. İkincisi, kardeşlerin Anzak, Adem ve Ela bu geceden sağ ve bir arada çıkacak. Bana hangi sözü veriyorsun?"',
        choices: [
          {
            label: '"Baba, hem fermanı yaşatacağım hem de kardeşlerimi birbirine kırdırmayacağım. Akşam gözlerin açık olsun."',
            action: function (s) {
              s.secrets.secret_poppy_dose = true;
              s.fatherStatus = 'lucid';
              s.fatherRespect += 30;
              s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Hünkar Kasrı: Sabah erkenden babanın haşhaş içmesini önledin; bilinci tamamen açık!');
            }
          }
        ]
      };
    }

    // ------------------------------------------------------------------------
    // 5. BÜYÜK PAZAR MEYDANI & TAHIL AMBARLARI (BARON KASSAR)
    // ------------------------------------------------------------------------
    if (loc === 'grand_market_kassar') {
      return {
        speaker: 'kassar',
        bg: ASSET_PREFIX + 'bg_furry_port.jpg',
        title: 'Kilitli Ambarlar ve Ekmek Kuyruğu',
        secretUnlocked: 'secret_grain_hoard',
        text: 'Büyük Pazar Meydanı kaynıyor. Yüzlerce insan boş fırınların önünde bağırıyor. Oysa taş ambarların mazgallarından taze buğday kokusu yayılıyor — kıtlık falan yok, ambarlar ağzına kadar dolu!\n\nBaron Kassar, kadife paltosuyla balkonundan sana gülümsüyor:\n\n"Hoş geldiniz Prens Tutu. Gördüğünüz gibi halkınız çok öfkeli. Babanızın şu \'Köleliği Kaldırma Fermanı\'nı süresiz ertelediğinizi ilan edin; ambarların kapısını hemen açayım, üstelik hazinenize 1 Kese Altın bağış yapayım. Ne dersiniz?"',
        choices: [
          {
            label: 'Hazineden 1 Kese Altın harcayarak limandaki bağımsız gemilerden un satın al ve halka ücretsiz dağıt! (-1 💰 Altın)',
            disabled: state.gold < 1,
            action: function (s) {
              s.secrets.secret_grain_hoard = true;
              s.gold -= 1;
              s.peopleCalm = true;
              s.fatherRespect += 15;
              s.kassarStatus = 'defeated_subsidy';
              s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Büyük Pazar: 1 Kese Altın ile halka ücretsiz buğday dağıttın; Kassar\'ın ekmek şantajı çöktü!');
            }
          },
          {
            label: '1 Muhafız Birliği ile Kassar\'ın ambar kapılarını koçbaşıyla kır, tahılı halka dağıt ve içerideki rüşvet defterine el koy! (-1 🛡️ Muhafız)',
            disabled: state.guards < 1,
            action: function (s) {
              s.secrets.secret_grain_hoard = true;
              s.secrets.secret_adem_debt = true;
              s.guards -= 1;
              s.peopleCalm = true;
              s.fatherRespect += 20;
              s.kassarStatus = 'defeated_force';
              s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Büyük Pazar: Muhafızlarla Kassar\'ın ambarlarını kırıp halka açtın ve rüşvet kayıtlarını ele geçirdin.');
            }
          },
          {
            label: 'Kassar\'ın anlaşmasını kabul et: Kölelik Fermanı\'nı ertele, ambarları açtır ve +1 Kese Altın al. (+1 💰 Altın, Ferman İptal)',
            action: function (s) {
              s.secrets.secret_grain_hoard = true;
              s.gold += 1;
              s.peopleCalm = true;
              s.decreeCompromised = true;
              s.fatherRespect -= 35;
              s.kassarStatus = 'appeased';
              s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Büyük Pazar: Halkı doyurmak ve altın almak için Baron Kassar\'a boyun eğip Kölelik Fermanı\'nı sattın.');
            }
          }
        ]
      };
    }

    // ------------------------------------------------------------------------
    // 6. KIZIL KULE ZİNDANI (SINIR ULAĞI VE CASUS SORGUSU)
    // ------------------------------------------------------------------------
    if (loc === 'red_dungeon_spy') {
      return {
        speaker: 'tutu',
        bg: ASSET_PREFIX + 'bg_vampire_citadel.jpg',
        title: 'Üç Krizin Birleştiği Karanlık Hücre',
        secretUnlocked: 'secret_master_plot',
        text: 'Kızıl Kule Zindanı\'na indiğinde iki kişiyi sorguluyorsun: Kızıl Geçit\'ten gelen yaralı sınır ulağı ve dün gece saray duvarında yakalanan Kassar\'ın kuryesi.\n\nKuryenin çizmesinden çıkan mühürlü emirname bütün yapbozu tamamlıyor:\n\n1. Baron Kassar, Kızıl Geçit\'te sahte bir sınır baskını düzenlemesi için haydutlara para vermiş — amacı Anzak\'ın gururunu okşayıp **Saray Muhafızlarını başkentten uzaklaştırmak!**\n2. Muhafızlar gidince pazardaki aç halkı saraya yürütecek.\n3. O kargaşada Hekim Varo\'nun uyuttuğu İmparator\'a sahte vasiyet mühürletilecek!',
        choices: [
          {
            label: 'İmzalı itirafnameyi al! Bu belge akşam hem Anzak\'ı uyandıracak hem de Kassar\'ı bitirecek. (+1 🛡️ Muhafız disiplini korunur)',
            action: function (s) {
              s.secrets.secret_master_plot = true;
              s.secrets.secret_letter = true;
              s.fatherRespect += 15;
              if (s.anzakStatus !== 'persuaded_stay') {
                s.anzakStatus = 'persuaded_stay';
                s.relAnzak += 15;
              }
              s.timeline.push(TIME_LABELS[s.timeSlot].name + ' — Kızıl Kule Zindanı: Üç krizin tek bir Kassar planı olduğunu kanıtlayan itirafnameyi ele geçirdin ve Anzak\'a haber uçurdun!');
            }
          }
        ]
      };
    }

    return null;
  }

  // ============================================================================
  // SEN BAŞKA YERDEYKEN KARAKTERLERİN OTONOM HAREKETLERİ (VAKİT ARASI)
  // ============================================================================
  function processOffScreenActions(state) {
    var logs = [];
    var slot = state.timeSlot; // Tamamlanan vakit: 0 (Sabah), 1 (Öğle), 2 (İkindi)

    // 1. ANZAK'IN HAREKETİ
    if (slot === 0 && !state.visited.courtyard_anzak && state.anzakStatus === 'waiting') {
      state.anzakStatus = 'rogue_march';
      if (state.guards > 0) {
        state.guards -= 1;
        logs.push({
          charId: 'anzak',
          title: 'Anzak Beklemekten Vazgeçti! (-1 🛡️ Muhafız)',
          text: 'Sen sabah başka bir işle ilgilenirken, ağabeyin Anzak Silah Avlusu\'nda beklemeye tahammül edemedi. Saray Muhafızlarından 1 birliği emrivakiyle peşine takıp Kızıl Geçit\'e doğru yola çıktı! Saray savunması zayıfladı.'
        });
      } else {
        logs.push({
          charId: 'anzak',
          title: 'Anzak Tek Başına Sınıra At Sürdü!',
          text: 'Sen sabah avluya gitmeyince Anzak kendi yaverleriyle Doğu Kapısı\'ndan çıktı.'
        });
      }
    }

    // 2. ELA'NIN HAREKETİ (En kritik zaman sınırı: Öğle sonuna kadar gidilmezse yakalanır!)
    if (slot === 0 && !state.visited.west_tower_ela && state.elaStatus === 'waiting') {
      logs.push({
        charId: 'ela',
        title: 'Ela Batı Kulesi\'nde Seni Bekliyor (Son Çağrı!)',
        text: 'Küçük kız kardeşin Ela sabah boyu pencereden avluyu gözetledi. Öğle vaktinde de yanına gitmezsen, söz verdiği gibi Hekim Varo\'nun mahzenine tek başına girecek!'
      });
    } else if (slot === 1 && !state.visited.west_tower_ela && state.elaStatus === 'waiting') {
      state.elaStatus = 'captured';
      logs.push({
        charId: 'ela',
        title: 'FELAKET: Ela Tek Başına Harekete Geçti ve Yakalandı!',
        text: 'Öğle vakti bitene kadar kimse onu dinlemeyince, 13 yaşındaki Ela gizlice Hekim Varo\'nun mahzenine indi. Orada Baron Kassar\'ın adamları tarafından yakalanıp rehin alındı! Akşam onu kurtarmak için sarayda muhafız gücüne ihtiyacın olacak.'
      });
    }

    // 3. ADEM'İN HAREKETİ
    if (slot === 1 && !state.visited.archive_adem && state.ademStatus === 'anxious') {
      state.ademStatus = 'conspiring';
      logs.push({
        charId: 'adem',
        title: 'Adem Korkuyla Kassar\'ın Elçisiyle Görüştü',
        text: 'Divan Arşivi\'nde yalnız kalan Adem, borç senetlerinin açıklanacağı korkusuyla Baron Kassar\'ın kâtibine akşamki vasiyet saatinde fermanı geciktireceğine dair söz verdi.'
      });
    }

    // 4. BABAN VE HEKİM VARO'NUN HAREKETİ
    if (slot === 0 && !state.visited.royal_chamber_father && state.fatherStatus === 'drugged') {
      logs.push({
        charId: 'varo',
        title: 'Hekim Varo Öğle Haşhaşını Hazırladı',
        text: 'Sabah Hünkar Kasrı\'na gitmediğin için Hekim Varo babana ilk haşhaş dozunu içirdi. Babanın bilinci kapanıyor; artık onu uyandırmak için panzehir bulman gerekecek.'
      });
    }

    // 5. PAZAR MEYDANI HAREKETİ
    if (slot === 2 && !state.peopleCalm) {
      logs.push({
        charId: 'kassar',
        title: 'Aç Kalabalık Saray Kapısına Dayandı!',
        text: 'İkindi biterken Büyük Pazar\'daki ekmek krizi çözülmediği için Baron Kassar\'ın kışkırttığı yüzlerce kişi meşalelerle Saray Meydanı\'na yürüdü!'
      });
    }

    if (logs.length === 0) {
      logs.push({
        charId: 'tutu',
        title: 'Sarayda Gergin Sessizlik',
        text: 'Aldığın önlemler sayesinde bu vakit saray koridorlarında yeni bir felaket patlak vermedi; ancak akşam güneşi hızla batıyor.'
      });
    }

    return logs;
  }

  // ============================================================================
  // AKŞAM YÜZLEŞMESİ (TAHT ODASI — TÜM KARARLARIN ÇARPIŞMASI)
  // ============================================================================
  function getEveningScene(state) {
    var step = state.eveningStep;

    // ADIM 0: Akşamın Durum Tablosu ve İlk Çarpışma (Ela & Pazar Durumu)
    if (step === 0) {
      var introParts = [];
      introParts.push('Güneş kızıl bir kor gibi batarken Taht Odası\'nın meşaleleri yakılıyor. Bütün gün yaptığın — ve zamanın yetmediği için bıraktığın — her şey şimdi bu salonda karşına çıkıyor:');

      if (state.fatherStatus === 'lucid') {
        introParts.push('• **İmparator Lalo:** Panzehir ve müdahalen sayesinde babanın bilinci AÇIK! Yatağında dik oturuyor, elinde altın mühür var.');
      } else {
        introParts.push('• **İmparator Lalo:** Hekim Varo\'yu durduramadığın için baban haşhaş dumanı altında YARI BAYGIN. Kendi başına konuşamıyor!');
      }

      if (state.elaStatus === 'captured') {
        introParts.push('• **Prenses Ela (REHİN):** Öğleye kadar yanına gitmediğin için küçük kız kardeşin Ela, Baron Kassar\'ın adamlarının elinde rehin!');
      } else {
        introParts.push('• **Prenses Ela (GÜVENDE):** Küçük kız kardeşin Ela yanında duruyor ve bulduğu kanıtı sıkıca tutuyor.');
      }

      if (state.peopleCalm) {
        introParts.push('• **Başkent Sokakları:** Pazar meydanındaki ekmek krizi çözüldüğü için halk sakin.');
      } else {
        introParts.push('• **Başkent Sokakları:** Ekmek krizi çözülmedi! Saray kapısının önünde öfkeli halkın uğultusu duyuluyor.');
      }

      // Eğer Ela yakalandıysa ilk karar Ela'yı kurtarmak üzerine!
      if (state.elaStatus === 'captured') {
        return {
          speaker: 'kassar',
          bg: ASSET_PREFIX + 'bg_throne.jpg',
          title: 'Akşam Yüzleşmesi I: Küçük Kardeşin İçin Fidye',
          text: introParts.join('\n\n') + '\n\nBaron Kassar\'ın elçisi salonun ortasında duruyor: "Prens Tutu, küçük kız kardeşiniz Ela mahzenimizde misafir. Şimdi ya Köleliği Kaldırma Fermanı\'nı kendi elinizle ateşe atarsınız, ya da kardeşinizi bir daha göremezsiniz!"',
          choices: [
            {
              label: 'Sarayda tuttuğun 2 Muhafız Birliğiyle mahzene ani baskın yap ve Ela\'yı zorla kurtar! (En az 2 🛡️ Muhafız Gerekir)',
              disabled: state.guards < 2,
              action: function (s) {
                s.elaStatus = 'rescued';
                s.relEla += 15;
                s.timeline.push('Akşam Yüzleşmesi: Sarayda bıraktığın muhafızlar sayesinde Ela\'yı Kassar\'ın elinden burnu kanamadan kurtardın!');
                s.eveningStep = 1;
              }
            },
            {
              label: 'Muhafızın yetmiyor... Ela\'nın hayatı için Kölelik Fermanı\'nı şömineye atıp yak! (Ferman Yok Olur)',
              action: function (s) {
                s.elaStatus = 'rescued';
                s.decreeCompromised = true;
                s.fatherRespect -= 30;
                s.timeline.push('Akşam Yüzleşmesi: Sarayda yeterli muhafız bırakmadığın için Ela\'yı kurtarmak uğruna babanın Kölelik Fermanı\'nı yaktın.');
                s.eveningStep = 1;
              }
            },
            {
              label: '"İmparatorluk şantaja boyun eğmez!" Fermanı yakmayı reddet! (Ela büyük tehlikede!)',
              action: function (s) {
                s.relEla -= 50;
                s.timeline.push('Akşam Yüzleşmesi: Fermanı korumak için Kassar\'ın şantajını reddettin; Ela mahzende terk edildi!');
                s.eveningStep = 1;
              }
            }
          ]
        };
      }

      return {
        speaker: state.fatherStatus === 'lucid' ? 'lalo' : 'tutu',
        bg: ASSET_PREFIX + 'bg_throne.jpg',
        title: 'Akşam Yüzleşmesi I: Meşaleler Altında Üç Kardeş',
        text: introParts.join('\n\n') + '\n\nSalonun kapıları açılıyor. Ağabeyin Anzak, kardeşin Adem ve divan üyeleri içeri giriyor.',
        choices: [
          {
            label: 'Yüzleşmeyi başlat: Kardeşlerinle ve vasiyetle hesaplaşma vakti.',
            action: function (s) {
              s.eveningStep = 1;
            }
          }
        ]
      };
    }

    // ADIM 1: Anzak ve Adem ile Hesaplaşma
    if (step === 1) {
      var secretCount = Object.keys(state.secrets).length;
      return {
        speaker: 'anzak',
        bg: ASSET_PREFIX + 'bg_throne.jpg',
        title: 'Akşam Yüzleşmesi II: Kılıç, Borç ve Kanıtlar',
        text: (state.anzakStatus === 'rogue_march'
          ? 'Ağabeyin Anzak tozlu zırhıyla içeri giriyor: "Kızıl Geçit\'te birkaç haydut dışında kimseyi bulamadık ama ordu benim emrimde! Tutu başkenti yönetemedi, taht benim hakkımdır!"'
          : 'Ağabeyin Anzak kılıcına dayanarak sana bakıyor: "Evet Tutu, akşam oldu. Şimdi babamızın ve divanın önünde söyle bakalım: Bu ülkeyi nasıl bir arada tutacaksın?"') +
          '\n\nYanında Adem başı önünde bekliyor. Bugün topladığın kanıt sayısı: **' + secretCount + ' / 6 Sır**.',
        choices: [
          {
            label: 'Topladığın kanıtları (Sınır mektubu / Haşhaş / Kassar\'ın kumpası) ortaya koy, gerçek suçlunun Baron Kassar ve Hekim Varo olduğunu ilan et; kardeşlerini ise affedip birliğe çağır!',
            disabled: secretCount < 2,
            action: function (s) {
              s.relAnzak += 15;
              s.relAdem += 15;
              s.fatherRespect += 20;
              s.timeline.push('Akşam Yüzleşmesi: Kanıtlarla Kassar-Varo komplosunu çökerttin ve kardeşlerini parçalamak yerine birleştirdin.');
              s.eveningStep = 2;
            }
          },
          {
            label: 'Sert Adalet: Hem Kassar\'ı hem de hataları yüzünden Anzak ve Adem\'i divan önünde mahkûm et! "Taht merhametle değil, kanunla korunur!"',
            action: function (s) {
              s.relAnzak -= 30;
              s.relAdem -= 30;
              s.fatherRespect += 10;
              s.ademStatus = 'arrested';
              s.timeline.push('Akşam Yüzleşmesi: Kanunu kardeşlerinin üstünde tuttun; Anzak ve Adem\'i divan önünde cezalandırdın.');
              s.eveningStep = 2;
            }
          },
          {
            label: 'Aileyi Koru, Suçu Örtbas Et: Bütün kanıtları yak, fermanı ertele ve kardeşlerinle tahtı paylaşma anlaşması yap.',
            action: function (s) {
              s.decreeCompromised = true;
              s.relAnzak += 10;
              s.relAdem += 20;
              s.fatherRespect -= 25;
              s.timeline.push('Akşam Yüzleşmesi: Kardeşlerini korumak için kanıtları gizledin ve reform fermanından vazgeçtin.');
              s.eveningStep = 2;
            }
          }
        ]
      };
    }

    // ADIM 2: Vasiyetin Mühürlenmesi ve Sonun Belirlenmesi
    return {
      speaker: 'lalo',
      bg: ASSET_PREFIX + 'bg_throne.jpg',
      title: 'Akşam Yüzleşmesi III: Son Mühür',
      text: state.fatherStatus === 'lucid'
        ? 'İmparator Lalo titreyen eliyle balmumu mührü kaldırıyor. Gözleri tek tek Anzak\'ın, Adem\'in, Ela\'nın ve en sonunda senin yüzünde geziyor:\n\n"Sabah size üç kriz ve tek bir gün bıraktım. Kiminiz şan peşinde koştu, kiminiz korkusuna yenildi... Şimdi kararımı mühürlüyorum."'
        : 'İmparator Lalo haşhaşın etkisiyle gözlerini açamıyor. Başhekim ve divan üyeleri vasiyet parşömenini senin ve ağabeyinin önüne sürüyor. Bu gecenin sonunu sabahki tercihlerin belirledi.',
      choices: [
        {
          label: 'Mührün basılmasını izle ve Günün Sonucunu Gör.',
          action: function (s) {
            s.endingId = evaluateEnding(s);
            s.phase = 'epilogue';
            playSfx('secret');
          }
        }
      ]
    };
  }

  // ============================================================================
  // 6 FARKLI SON DEĞERLENDİRMESİ
  // ============================================================================
  var ENDINGS = {
    ending_true_unity: {
      id: 'ending_true_unity',
      rank: 'DESTANSI SON (I / VI)',
      title: '👑 Gerçek Vasiyet: Aileyi ve Ülkeyi Birleştiren Taç',
      subtitle: 'Ne kardeşlerini feda ettin ne de babanın adalet fermanını.',
      color: 'border-amber-400 bg-amber-950/40 text-amber-200',
      summary: 'İmparator Lalo bilinci açık halde son mührünü bastı: Tahtı sana, orduların komutasını ağabeyin Anzak\'a, hazine reformunu borcundan kurtardığın Adem\'e ve saray istihbaratını küçük kız kardeşin Ela\'ya bıraktı. Köleliği Kaldırma Fermanı yürürlüğe girdi, Baron Kassar ve Hekim Varo zindana atıldı. Zamanın yetmediği bir günde en doğru öncelikleri seçtin.'
    },
    ending_tragic_ela: {
      id: 'ending_tragic_ela',
      rank: 'TRAJİK SON (II / VI)',
      title: '🥀 Batı Kulesi\'nin Sessizliği',
      subtitle: 'Devleti kurtarmaya çalışırken en küçük kardeşini unuttun.',
      color: 'border-rose-500 bg-rose-950/40 text-rose-200',
      summary: 'Sınırla, pazarla ve fermanlarla uğraşırken Batı Kulesi\'nde seni bekleyen 13 yaşındaki kız kardeşin Ela\'ya zaman ayırmadın; akşam olduğunda ise onu kurtaracak muhafızın kalmamıştı. Tahtı ve fermanı korudun ama saray koridorlarında bir daha Ela\'nın ayak sesleri duyulmadı. Kazandığın taç ömür boyu omuzlarında bir kurşun gibi ağır kaldı.'
    },
    ending_anzak_coup: {
      id: 'ending_anzak_coup',
      rank: 'ASKERİ DARBE SONU (III / VI)',
      title: '⚔️ Anzak\'ın Kılıcı ve Boş Kalan Saray',
      subtitle: 'Muhafızları kaptırdın, baban uyutuldu, taht kılıca boyun eğdi.',
      color: 'border-red-500 bg-red-950/40 text-red-200',
      summary: 'İmparator Lalo haşhaş uykusundan uyanamadı ve sarayda yeterli muhafız birliğin kalmadı. Ağabeyin Anzak ordunun gücüyle Taht Odası\'nı teslim aldı ve kendini Naip İmparator ilan etti. Sen ve kardeşlerin sarayda birer rehineye dönüştünüz.'
    },
    ending_iron_broken_family: {
      id: 'ending_iron_broken_family',
      rank: 'DEMİR ADALET SONU (IV / VI)',
      title: '⚖️ Demir Adalet, Kırık Sofra',
      subtitle: 'Ülkeyi ve fermanı kurtardın ama masada tek başına kaldın.',
      color: 'border-sky-400 bg-sky-950/40 text-sky-200',
      summary: 'Köleliği Kaldırma Fermanı imzalandı, Baron Kassar ezildi ve baban tacı sana bıraktı. Ancak bu uğurda kardeşin Adem\'i zindana gönderdin ve ağabeyin Anzak\'ı sürgün ettin. Akşam yemeğinde uzun kraliyet sofrasında sadece sen ve küçük Ela vardınız. Güçlü bir hükümdar oldun ama aileni kaybettin.'
    },
    ending_family_compromise: {
      id: 'ending_family_compromise',
      rank: 'TAVİZ SONU (V / VI)',
      title: '🩸 Kardeşler Sağ, Ferman Külde',
      subtitle: 'Aileni korumak için ülkenin geleceğini Baron Kassar\'a sattın.',
      color: 'border-purple-400 bg-purple-950/40 text-purple-200',
      summary: 'Anzak, Adem ve Ela bu geceden sağ ve özgür çıktı; kardeşlerin sana minnettar. Ancak onları kurtarmak için babanın ömrünü adadığı Köleliği Kaldırma Fermanı\'nı yaktın. Baron Kassar ambarları açtı ama artık imparatorluğun gerçek sahibi loncalar oldu.'
    },
    ending_puppet_throne: {
      id: 'ending_puppet_throne',
      rank: 'GÖLGE SON (VI / VI)',
      title: '🕯️ Haşhaş Dumanı ve Kukla Taht',
      subtitle: 'Baban uyanamadı, sokaklar durulmadı, karanlıkta sıkıştın.',
      color: 'border-stone-400 bg-stone-900/70 text-stone-200',
      summary: 'Hekim Varo\'nun haşhaşı İmparator Lalo\'yu susturdu; vasiyet hiçbir zaman imzalanamadı. Saray kapısında aç halkın isyanı, içeride kardeşlerinin güvensizliği arasında mühürsüz bir Naip olarak kaldın. Sabah kaçırdığın ipuçları akşam ellerini kollarını bağladı.'
    }
  };

  function evaluateEnding(s) {
    // 1. Ela kurtarılamadıysa
    if (s.elaStatus === 'captured') {
      return 'ending_tragic_ela';
    }
    // 2. Anzak kontrolden çıktı, baban baygın ve muhafızın yoksa
    if (s.anzakStatus === 'rogue_march' && s.fatherStatus !== 'lucid' && s.guards === 0) {
      return 'ending_anzak_coup';
    }
    // 3. Ferman yakıldı/ertelendiyse (Aile için taviz)
    if (s.decreeCompromised) {
      return 'ending_family_compromise';
    }
    // 4. Baban uyanık, ferman korundu, ancak kardeşler tutuklandı/küskünse
    if (s.ademStatus === 'arrested' || s.relAnzak < 35 || s.relAdem < 35) {
      return 'ending_iron_broken_family';
    }
    // 5. Baban uyanık, ferman korundu, Ela güvende ve kardeşlerle bağ güçlüyse
    if (s.fatherStatus === 'lucid' && !s.decreeCompromised && s.elaStatus !== 'captured') {
      return 'ending_true_unity';
    }
    // 6. Diğer durumlar (Baban baygın kaldı)
    return 'ending_puppet_throne';
  }

  // ============================================================================
  // YARDIMCI GÖRSEL BİLEŞENLER (PORTRE KARTI & ÜST BAR)
  // ============================================================================
  function CharacterPortraitCard(props) {
    var charObj = CHARACTERS[props.charId] || CHARACTERS.tutu;
    return h(
      'div',
      {
        className: 'relative rounded-2xl overflow-hidden border-2 ' + charObj.border + ' bg-stone-950 shadow-2xl transition-all duration-300'
      },
      h(
        'div',
        { className: 'relative h-56 sm:h-64 w-full overflow-hidden bg-stone-900' },
        h('img', {
          src: charObj.img,
          alt: charObj.name,
          style: { objectPosition: charObj.imgPos || 'center top' },
          className: 'w-full h-full object-cover transition-transform duration-700 hover:scale-105'
        }),
        h('div', {
          className: 'absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/25 to-transparent'
        }),
        charObj.svgIcon
          ? h(
              'div',
              {
                className: 'absolute top-3 right-3 w-10 h-10 rounded-full bg-stone-950/85 border border-amber-500/40 flex items-center justify-center text-xl shadow-lg'
              },
              charObj.svgIcon
            )
          : null,
        h(
          'div',
          { className: 'absolute bottom-3 left-3 right-3' },
          h(
            'span',
            {
              className: 'inline-block text-[10px] font-bold uppercase tracking-widest px-2.5 py-0.5 rounded-full border mb-1 ' + charObj.badgeBg
            },
            charObj.title
          ),
          h(
            'h3',
            { className: 'text-xl font-bold royal-font text-amber-100 drop-shadow' },
            charObj.name
          )
        )
      ),
      h(
        'div',
        { className: 'p-3.5 bg-stone-950/95 border-t border-amber-500/20' },
        h(
          'p',
          { className: 'text-xs italic text-amber-200/80 leading-relaxed' },
          '"' + charObj.quote + '"'
        )
      )
    );
  }

  // ============================================================================
  // ANA BİLEŞEN: BirGunApp
  // ============================================================================
  function BirGunApp(props) {
    var _state = useState(createInitialState);
    var state = _state[0];
    var setState = _state[1];

    var _showDesignModal = useState(false);
    var showDesignModal = _showDesignModal[0];
    var setShowDesignModal = _showDesignModal[1];

    function updateState(mutator) {
      setState(function (prev) {
        var next = JSON.parse(JSON.stringify(prev));
        mutator(next);
        return next;
      });
    }

    function restartGame() {
      playSfx('choice');
      setState(createInitialState());
    }

    var unlockedSecretsCount = Object.keys(state.secrets).length;
    var currentSlotInfo = TIME_LABELS[Math.min(2, state.timeSlot)];

    // ------------------------------------------------------------------------
    // ÜST KAYNAK VE ZAMAN ÇUBUĞU (HUD)
    // ------------------------------------------------------------------------
    var topBar = h(
      'header',
      {
        className: 'sticky top-0 z-30 backdrop-blur-md bg-stone-950/90 border-b border-amber-500/30 px-4 py-3 shadow-xl'
      },
      h(
        'div',
        { className: 'max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-3' },
        // Sol: Başlık
        h(
          'div',
          { className: 'flex items-center gap-3' },
          h(
            'div',
            {
              className: 'w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-800 flex items-center justify-center text-stone-950 font-black text-lg shadow-md'
            },
            '👑'
          ),
          h(
            'div',
            null,
            h(
              'div',
              { className: 'flex items-center gap-2' },
              h('h1', { className: 'text-base sm:text-lg font-bold royal-font text-amber-300' }, 'PRENS TUTU: BİR GÜN'),
              h(
                'span',
                { className: 'text-[10px] uppercase tracking-wider px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold' },
                '10–15 Dk Temel Bölüm'
              )
            ),
            h(
              'p',
              { className: 'text-xs text-stone-400 hidden sm:block' },
              'Ailenle ilişkilerini ve ülkenin geleceğini aynı anda etkileyen zor kararlar.'
            )
          )
        ),

        // Orta: Sınırlı Kaynaklar (Zaman, Muhafız, Hazine, Sırlar)
        h(
          'div',
          { className: 'flex flex-wrap items-center gap-2 sm:gap-3' },
          // Vakit Göstergesi
          h(
            'div',
            {
              className: 'px-3 py-1.5 rounded-xl bg-stone-900/90 border border-amber-500/40 flex items-center gap-2',
              title: 'Her vakitte yalnızca 1 yere gidebilirsin!'
            },
            h('span', { className: 'text-base' }, state.phase === 'evening' || state.phase === 'epilogue' ? '🌙' : currentSlotInfo.icon),
            h(
              'div',
              { className: 'text-left' },
              h('div', { className: 'text-[10px] uppercase tracking-wider text-stone-400' }, 'VAKİT (EN SERT KISIT)'),
              h(
                'div',
                { className: 'text-xs font-bold text-amber-300' },
                state.phase === 'morning_intro'
                  ? 'ŞAFAK (Kapıda 3 Kriz)'
                  : state.phase === 'evening'
                  ? 'AKŞAM (Vasiyet Saati)'
                  : state.phase === 'epilogue'
                  ? 'GÜN SONU'
                  : currentSlotInfo.name + ' (' + (3 - state.timeSlot) + ' Hak Kaldı)'
              )
            )
          ),

          // Muhafız Birliği
          h(
            'div',
            {
              className: 'px-3 py-1.5 rounded-xl bg-stone-900/90 border border-red-500/40 flex items-center gap-2',
              title: 'Saray Muhafız Birlikleri: Sınıra mı, Pazara mı, Ela ve Babanı korumaya mı?'
            },
            h('span', { className: 'text-base' }, '🛡️'),
            h(
              'div',
              null,
              h('div', { className: 'text-[10px] uppercase tracking-wider text-stone-400' }, 'MUHAFIZ'),
              h('div', { className: 'text-xs font-bold text-red-300' }, state.guards + ' / 3 Birlik')
            )
          ),

          // Hazine
          h(
            'div',
            {
              className: 'px-3 py-1.5 rounded-xl bg-stone-900/90 border border-yellow-500/40 flex items-center gap-2',
              title: 'Hazine Kesesi: Adem\'in borcuna mı, halkın ekmeğine mi, panzehire mi?'
            },
            h('span', { className: 'text-base' }, '💰'),
            h(
              'div',
              null,
              h('div', { className: 'text-[10px] uppercase tracking-wider text-stone-400' }, 'HAZİNE'),
              h('div', { className: 'text-xs font-bold text-yellow-300' }, state.gold + ' Kese Altın')
            )
          ),

          // Sırlar
          h(
            'div',
            {
              className: 'px-3 py-1.5 rounded-xl bg-stone-900/90 border border-sky-500/40 flex items-center gap-2',
              title: 'Bulunan Gizli Sırlar'
            },
            h('span', { className: 'text-base' }, '🗝️'),
            h(
              'div',
              null,
              h('div', { className: 'text-[10px] uppercase tracking-wider text-stone-400' }, 'SIRLAR'),
              h('div', { className: 'text-xs font-bold text-sky-300' }, unlockedSecretsCount + ' / 6 Kanıt')
            )
          )
        ),

        // Sağ: Butonlar
        h(
          'div',
          { className: 'flex items-center gap-2' },
          h(
            'button',
            {
              onClick: function () { setShowDesignModal(true); },
              className: 'px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-stone-900 hover:bg-stone-800 text-amber-200 border border-amber-500/30 transition'
            },
            '📋 Tasarım Notu'
          ),
          h(
            'button',
            {
              onClick: restartGame,
              className: 'px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-amber-950/80 hover:bg-amber-900 text-amber-200 border border-amber-500/40 transition'
            },
            '↺ Baştan Oyna'
          ),
          props.onSwitchToLegacy
            ? h(
                'button',
                {
                  onClick: props.onSwitchToLegacy,
                  className: 'px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-stone-900 hover:bg-stone-800 text-stone-400 hover:text-stone-200 border border-stone-700 transition',
                  title: 'Eski 18 Eyaletli Sandbox Sürümüne Geç'
                },
                '🗺️ Eski Sandbox'
              )
            : null
        )
      )
    );

    // ------------------------------------------------------------------------
    // SAHNE GÖRÜNÜMÜ (SABAH GİRİŞİ, MEKÂN İÇİ VEYA AKŞAM YÜZLEŞMESİ)
    // ------------------------------------------------------------------------
    function renderVisualNovelStage(sceneObj, onChoiceSelect) {
      var speakerObj = CHARACTERS[sceneObj.speaker] || CHARACTERS.tutu;

      return h(
        'div',
        { className: 'max-w-6xl mx-auto px-4 py-6' },
        // Ana Görsel Roman Sahne Kutusu
        h(
          'div',
          {
            className: 'relative rounded-3xl overflow-hidden border border-amber-500/40 shadow-2xl bg-stone-950'
          },
          // Arka Plan Görseli (Yüksek Çözünürlüklü 2D İllüstrasyon)
          h(
            'div',
            { className: 'relative h-64 sm:h-80 md:h-96 w-full overflow-hidden' },
            h('img', {
              src: sceneObj.bg || ASSET_PREFIX + 'bg_throne.jpg',
              alt: sceneObj.title,
              className: 'w-full h-full object-cover object-center scale-105 transition-all duration-1000'
            }),
            h('div', {
              className: 'absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/45 to-stone-950/30'
            }),

            // Sol Üst Konum Etiketi
            h(
              'div',
              { className: 'absolute top-4 left-4 right-4 flex flex-wrap items-center justify-between gap-2' },
              h(
                'span',
                {
                  className: 'px-3.5 py-1.5 rounded-full text-xs font-bold tracking-wider uppercase bg-stone-950/85 text-amber-300 border border-amber-500/50 backdrop-blur-md shadow-lg'
                },
                sceneObj.locationTag || (currentSlotInfo.icon + ' ' + currentSlotInfo.name)
              ),
              sceneObj.secretUnlocked
                ? h(
                    'span',
                    {
                      className: 'px-3.5 py-1.5 rounded-full text-xs font-bold bg-sky-950/90 text-sky-300 border border-sky-400/70 shadow-lg animate-pulse'
                    },
                    '🗝️ YENİ SIR AÇIĞA ÇIKTI!'
                  )
                : null
            ),

            // Sahne Başlığı
            h(
              'div',
              { className: 'absolute bottom-4 left-6 right-6' },
              h(
                'h2',
                { className: 'text-2xl sm:text-3xl font-extrabold royal-font text-amber-100 drop-shadow-lg' },
                sceneObj.title
              )
            )
          ),

          // Alt Kısım: Sol Karakter Portresi + Sağ Diyalog ve Seçimler
          h(
            'div',
            { className: 'grid grid-cols-1 lg:grid-cols-12 gap-6 p-6 bg-gradient-to-b from-stone-950 to-stone-900/95' },
            // Sol: Konuşan Karakter Portresi (4 Sütun)
            h(
              'div',
              { className: 'lg:col-span-4' },
              h(CharacterPortraitCard, { charId: sceneObj.speaker || 'tutu' }),
              // Kardeşlerle ve Babanla İlişki Özeti
              h(
                'div',
                { className: 'mt-4 p-3.5 rounded-xl bg-stone-900/90 border border-stone-800 text-xs space-y-2' },
                h('div', { className: 'font-bold text-amber-300/90 uppercase tracking-wider text-[11px]' }, 'Aile & Başkent Dengesi'),
                h(
                  'div',
                  { className: 'flex justify-between text-stone-300' },
                  h('span', null, '⚔️ Ağabeyin Anzak:'),
                  h('span', { className: 'font-semibold text-amber-300' }, state.relAnzak + ' / 100')
                ),
                h(
                  'div',
                  { className: 'flex justify-between text-stone-300' },
                  h('span', null, '📜 Kardeşin Adem:'),
                  h('span', { className: 'font-semibold text-purple-300' }, state.relAdem + ' / 100')
                ),
                h(
                  'div',
                  { className: 'flex justify-between text-stone-300' },
                  h('span', null, '🕯️ Kız Kardeşin Ela:'),
                  h(
                    'span',
                    { className: 'font-semibold ' + (state.elaStatus === 'captured' ? 'text-rose-400' : 'text-sky-300') },
                    state.elaStatus === 'captured' ? 'REHİN ALINDI!' : state.relEla + ' / 100'
                  )
                ),
                h(
                  'div',
                  { className: 'flex justify-between text-stone-300' },
                  h('span', null, '👑 Babanın Güveni:'),
                  h('span', { className: 'font-semibold text-yellow-300' }, state.fatherRespect + ' / 100')
                )
              )
            ),

            // Sağ: Hikâye Metni ve Karar Seçenekleri (8 Sütun)
            h(
              'div',
              { className: 'lg:col-span-8 flex flex-col justify-between space-y-6' },
              // Metin Alanı
              h(
                'div',
                {
                  className: 'p-5 sm:p-6 rounded-2xl bg-stone-900/80 border border-amber-500/25 shadow-inner space-y-4'
                },
                h(
                  'div',
                  { className: 'flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-amber-400' },
                  h('span', null, speakerObj.name),
                  h('span', { className: 'text-stone-500' }, '•'),
                  h('span', { className: 'text-stone-400 font-normal' }, speakerObj.title)
                ),
                sceneObj.text.split('\n\n').map(function (para, idx) {
                  return h(
                    'p',
                    { key: idx, className: 'story-prose text-stone-100 leading-relaxed' },
                    para
                  );
                })
              ),

              // Seçenekler
              h(
                'div',
                { className: 'space-y-3' },
                h(
                  'div',
                  { className: 'text-xs font-bold uppercase tracking-widest text-amber-400/90 px-1' },
                  'Kararın Nedir?'
                ),
                sceneObj.choices.map(function (ch, idx) {
                  var isDisabled = !!ch.disabled;
                  return h(
                    'button',
                    {
                      key: idx,
                      disabled: isDisabled,
                      onClick: function () {
                        if (!isDisabled) onChoiceSelect(ch);
                      },
                      className:
                        'w-full text-left p-4 rounded-xl border transition-all duration-200 flex items-start gap-3.5 ' +
                        (isDisabled
                          ? 'bg-stone-900/40 border-stone-800 text-stone-600 cursor-not-allowed'
                          : 'bg-gradient-to-r from-stone-900 via-stone-900 to-amber-950/30 hover:from-amber-950/60 hover:to-amber-900/30 border-amber-500/35 hover:border-amber-400 text-stone-100 shadow-lg hover:translate-x-1')
                    },
                    h(
                      'span',
                      {
                        className:
                          'w-7 h-7 rounded-lg flex items-center justify-center text-xs font-black shrink-0 mt-0.5 ' +
                          (isDisabled
                            ? 'bg-stone-800 text-stone-600'
                            : 'bg-amber-500/20 border border-amber-400/60 text-amber-300')
                      },
                      idx + 1
                    ),
                    h(
                      'div',
                      { className: 'flex-1' },
                      h('div', { className: 'text-sm sm:text-base font-semibold leading-snug' }, ch.label),
                      isDisabled
                        ? h(
                            'div',
                            { className: 'text-xs text-rose-400 mt-1' },
                            'Yetersiz kaynak (Muhafız veya Hazine Kesesi kalmadı).'
                          )
                        : null
                    )
                  );
                })
              )
            )
          )
        )
      );
    }

    // ------------------------------------------------------------------------
    // FAZ 1: SABAH GİRİŞİ (KAPINI ÇALAN ÜÇ KİŞİ)
    // ------------------------------------------------------------------------
    if (state.phase === 'morning_intro') {
      var introScene = MORNING_INTRO_STEPS[state.introStep];
      return h(
        'div',
        { className: 'min-h-screen pb-16' },
        topBar,
        renderVisualNovelStage(introScene, function (choice) {
          playSfx('choice');
          updateState(function (s) {
            if (choice.effect) choice.effect(s);
            if (typeof choice.nextStep === 'number') {
              s.introStep = choice.nextStep;
            }
          });
        })
      );
    }

    // ------------------------------------------------------------------------
    // FAZ 2: VAKİT MERKEZİ (SABAH / ÖĞLE / İKİNDİ — 6 YERDEN SADECE 1'İNİ SEÇ)
    // ------------------------------------------------------------------------
    if (state.phase === 'hub') {
      return h(
        'div',
        { className: 'min-h-screen pb-16' },
        topBar,
        h(
          'div',
          { className: 'max-w-6xl mx-auto px-4 py-6 space-y-6' },

          // Vakit Başlığı & Uyarı Banner'ı
          h(
            'div',
            {
              className:
                'p-6 rounded-3xl border border-amber-500/40 bg-gradient-to-r ' +
                currentSlotInfo.tint +
                ' shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4'
            },
            h(
              'div',
              { className: 'space-y-1.5' },
              h(
                'div',
                { className: 'inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-amber-300' },
                h('span', { className: 'text-lg' }, currentSlotInfo.icon),
                h('span', null, currentSlotInfo.sub)
              ),
              h(
                'h2',
                { className: 'text-2xl sm:text-3xl font-extrabold royal-font text-stone-100' },
                currentSlotInfo.name + ': Şimdi Nereye Gideceksin?'
              ),
              h(
                'p',
                { className: 'text-sm text-stone-300 max-w-2xl' },
                'Zamanın hepsine yetmez. Bu vakitte aşağıdaki 6 noktadan ',
                h('strong', { className: 'text-amber-300 underline' }, 'yalnızca birine'),
                ' gidebilirsin. Sen bir yerdeyken diğer karakterler kendi çıkarları için harekete geçecek!'
              )
            ),
            // 3 Vakit İlerleme Adımları
            h(
              'div',
              { className: 'flex items-center gap-2 self-stretch md:self-center' },
              TIME_LABELS.map(function (tl) {
                var done = tl.index < state.timeSlot;
                var active = tl.index === state.timeSlot;
                return h(
                  'div',
                  {
                    key: tl.index,
                    className:
                      'px-3.5 py-2 rounded-xl border text-center text-xs font-bold transition ' +
                      (active
                        ? 'bg-amber-500/25 border-amber-400 text-amber-200 shadow-lg scale-105'
                        : done
                        ? 'bg-stone-900/50 border-stone-800 text-stone-500 line-through'
                        : 'bg-stone-900/80 border-stone-700 text-stone-400')
                  },
                  h('div', null, tl.icon),
                  h('div', { className: 'mt-0.5' }, tl.name.split(' ')[0])
                );
              })
            )
          ),

          // 6 Mekân Kartı Grid'i
          h(
            'div',
            { className: 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5' },
            LOCATIONS.map(function (loc) {
              var isVisited = !!state.visited[loc.id];
              var charObj = CHARACTERS[loc.charId] || CHARACTERS.tutu;
              var urgency = loc.urgencyText(state);

              return h(
                'div',
                {
                  key: loc.id,
                  className:
                    'group rounded-2xl overflow-hidden border transition-all duration-300 flex flex-col justify-between ' +
                    (isVisited
                      ? 'bg-stone-950/60 border-stone-800 opacity-65'
                      : 'bg-stone-950/95 border-amber-500/35 hover:border-amber-400 shadow-xl hover:-translate-y-1')
                },
                h(
                  'div',
                  null,
                  // Görsel Başlık
                  h(
                    'div',
                    { className: 'relative h-44 w-full overflow-hidden bg-stone-900' },
                    h('img', {
                      src: loc.bg,
                      alt: loc.name,
                      className: 'w-full h-full object-cover transition-transform duration-700 group-hover:scale-110'
                    }),
                    h('div', {
                      className: 'absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/40 to-transparent'
                    }),
                    h(
                      'div',
                      { className: 'absolute top-3 left-3 flex items-center gap-2' },
                      h(
                        'span',
                        {
                          className: 'w-8 h-8 rounded-lg bg-stone-950/90 border border-amber-500/40 flex items-center justify-center text-base'
                        },
                        loc.icon
                      ),
                      h(
                        'span',
                        {
                          className: 'px-2.5 py-1 rounded-full text-[11px] font-bold bg-stone-950/85 text-amber-200 border border-amber-500/30'
                        },
                        loc.shortRole
                      )
                    ),
                    isVisited
                      ? h(
                          'span',
                          {
                            className: 'absolute top-3 right-3 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase bg-emerald-950/90 text-emerald-300 border border-emerald-500/40'
                          },
                          '✓ Ziyaret Edildi'
                        )
                      : null,
                    h(
                      'div',
                      { className: 'absolute bottom-3 left-3 right-3' },
                      h('h3', { className: 'text-lg font-bold royal-font text-stone-100' }, loc.name)
                    )
                  ),

                  // Açıklama & Aciliyet Durumu
                  h(
                    'div',
                    { className: 'p-4 space-y-3' },
                    h('p', { className: 'text-xs text-stone-300 leading-relaxed' }, loc.summary),
                    h(
                      'div',
                      {
                        className:
                          'p-2.5 rounded-xl border text-xs font-medium ' +
                          (urgency.indexOf('SON ŞANS') !== -1 || urgency.indexOf('KRİTİK') !== -1
                            ? 'bg-rose-950/60 border-rose-500/50 text-rose-200 animate-pulse'
                            : 'bg-amber-950/30 border-amber-500/25 text-amber-200/90')
                      },
                      '⏳ ',
                      urgency
                    )
                  )
                ),

                // Alt Buton
                h(
                  'div',
                  { className: 'p-4 pt-0' },
                  h(
                    'button',
                    {
                      disabled: isVisited,
                      onClick: function () {
                        playSfx('choice');
                        updateState(function (s) {
                          s.currentLocation = loc.id;
                          s.locationStep = 0;
                          s.visited[loc.id] = true;
                          s.phase = 'location_scene';
                        });
                      },
                      className:
                        'w-full py-2.5 px-4 rounded-xl text-xs font-bold uppercase tracking-wider transition ' +
                        (isVisited
                          ? 'bg-stone-900 text-stone-600 cursor-not-allowed'
                          : 'bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-stone-950 shadow-md')
                    },
                    isVisited ? 'Bu Mekâna Zaten Gittin' : 'Bu Vakti Burada Harca →'
                  )
                )
              );
            })
          )
        )
      );
    }

    // ------------------------------------------------------------------------
    // FAZ 3: MEKÂN İÇİ GÖRSEL ROMAN SAHNESİ
    // ------------------------------------------------------------------------
    if (state.phase === 'location_scene') {
      var locScene = getLocationScene(state);
      return h(
        'div',
        { className: 'min-h-screen pb-16' },
        topBar,
        renderVisualNovelStage(locScene, function (choice) {
          playSfx('choice');
          updateState(function (s) {
            if (typeof choice.nextStep === 'number') {
              s.locationStep = choice.nextStep;
            } else {
              if (choice.action) choice.action(s);
              // Vakit tamamlandı -> Sen orada değilken diğer karakterler ne yaptı?
              s.betweenLogs = processOffScreenActions(s);
              s.phase = 'between_slots';
            }
          });
        })
      );
    }

    // ------------------------------------------------------------------------
    // FAZ 4: SEN ORADA DEĞİLKEN (VAKİT ARASI OTONOM HAREKETLER)
    // ------------------------------------------------------------------------
    if (state.phase === 'between_slots') {
      var isLastSlot = state.timeSlot >= 2;
      return h(
        'div',
        { className: 'min-h-screen pb-16' },
        topBar,
        h(
          'div',
          { className: 'max-w-4xl mx-auto px-4 py-8 space-y-6' },
          h(
            'div',
            { className: 'p-6 sm:p-8 rounded-3xl bg-stone-950 border border-amber-500/40 shadow-2xl space-y-6' },
            h(
              'div',
              { className: 'border-b border-stone-800 pb-4' },
              h(
                'span',
                { className: 'text-xs font-bold uppercase tracking-widest text-amber-400' },
                TIME_LABELS[state.timeSlot].name + ' SONA ERDİ'
              ),
              h(
                'h2',
                { className: 'text-2xl sm:text-3xl font-extrabold royal-font text-stone-100 mt-1' },
                'Sen Orada Değilken Sarayda Neler Oldu?'
              ),
              h(
                'p',
                { className: 'text-sm text-stone-400 mt-1' },
                'Zamanını tek bir yere ayırdığın sırada diğer karakterler kendi çıkarları ve korkuları doğrultusunda hamle yaptı:'
              )
            ),

            // Otonom Olay Kartları
            h(
              'div',
              { className: 'space-y-4' },
              state.betweenLogs.map(function (item, idx) {
                var cObj = CHARACTERS[item.charId] || CHARACTERS.tutu;
                return h(
                  'div',
                  {
                    key: idx,
                    className: 'p-4 rounded-2xl bg-stone-900/90 border border-stone-700/80 flex flex-col sm:flex-row items-start gap-4'
                  },
                  h('img', {
                    src: cObj.img,
                    alt: cObj.name,
                    className: 'w-16 h-16 rounded-xl object-cover object-top border border-amber-500/40 shrink-0'
                  }),
                  h(
                    'div',
                    { className: 'space-y-1' },
                    h('div', { className: 'text-xs font-bold uppercase tracking-wider text-amber-300' }, cObj.name),
                    h('h4', { className: 'text-base font-bold text-stone-100' }, item.title),
                    h('p', { className: 'text-sm text-stone-300 leading-relaxed' }, item.text)
                  )
                );
              })
            ),

            // Sonraki Vakte veya Akşam Yüzleşmesine Geçiş Butonu
            h(
              'div',
              { className: 'pt-2' },
              h(
                'button',
                {
                  onClick: function () {
                    playSfx('choice');
                    updateState(function (s) {
                      if (s.timeSlot < 2) {
                        s.timeSlot += 1;
                        s.phase = 'hub';
                      } else {
                        s.eveningStep = 0;
                        s.phase = 'evening';
                      }
                    });
                  },
                  className:
                    'w-full py-4 px-6 rounded-2xl font-bold text-sm sm:text-base uppercase tracking-wider bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-stone-950 shadow-xl transition'
                },
                isLastSlot
                  ? '🌙 Güneş Batıyor — Akşam Vasiyet Yüzleşmesine Geç →'
                  : TIME_LABELS[state.timeSlot + 1].icon + ' ' + TIME_LABELS[state.timeSlot + 1].name + ' Başlasın →'
              )
            )
          )
        )
      );
    }

    // ------------------------------------------------------------------------
    // FAZ 5: AKŞAM YÜZLEŞMESİ (VASİYET SAHNESİ)
    // ------------------------------------------------------------------------
    if (state.phase === 'evening') {
      var evScene = getEveningScene(state);
      return h(
        'div',
        { className: 'min-h-screen pb-16' },
        topBar,
        renderVisualNovelStage(evScene, function (choice) {
          playSfx('choice');
          updateState(function (s) {
            if (choice.action) choice.action(s);
          });
        })
      );
    }

    // ------------------------------------------------------------------------
    // FAZ 6: GÜN SONU KARNESİ, KARARLARIN İZİ VE SIRLAR TABLOSU
    // ------------------------------------------------------------------------
    var endingObj = ENDINGS[state.endingId] || ENDINGS.ending_puppet_throne;
    return h(
      'div',
      { className: 'min-h-screen pb-20' },
      topBar,
      h(
        'div',
        { className: 'max-w-5xl mx-auto px-4 py-8 space-y-8' },

        // Final Başlık Kartı
        h(
          'div',
          {
            className: 'p-6 sm:p-8 rounded-3xl border-2 shadow-2xl space-y-4 ' + endingObj.color
          },
          h(
            'div',
            { className: 'inline-block px-3 py-1 rounded-full text-xs font-black uppercase tracking-widest bg-stone-950/80 border border-current' },
            endingObj.rank
          ),
          h('h2', { className: 'text-2xl sm:text-4xl font-extrabold royal-font text-white' }, endingObj.title),
          h('p', { className: 'text-base sm:text-lg font-semibold italic opacity-90' }, endingObj.subtitle),
          h('p', { className: 'story-prose text-stone-100 pt-2 border-t border-white/15' }, endingObj.summary)
        ),

        // İki Sütun: 1) Kararlarının İzi & Aile Durumu, 2) Bulunan ve Kaçırılan Sırlar
        h(
          'div',
          { className: 'grid grid-cols-1 lg:grid-cols-2 gap-6' },

          // Sol: Kararlarının İzi
          h(
            'div',
            { className: 'p-6 rounded-3xl bg-stone-950 border border-amber-500/30 space-y-4' },
            h(
              'h3',
              { className: 'text-lg font-bold royal-font text-amber-300' },
              '📜 Sabahki Kararlarının Akşama İzi'
            ),
            h(
              'div',
              { className: 'space-y-2.5' },
              state.timeline.map(function (item, idx) {
                return h(
                  'div',
                  {
                    key: idx,
                    className: 'p-3 rounded-xl bg-stone-900/90 border border-stone-800 text-xs text-stone-200 leading-relaxed'
                  },
                  item
                );
              })
            )
          ),

          // Sağ: Bulunan ve Kaçırılan Sırlar (Tekrar Oynama İsteği İçin)
          h(
            'div',
            { className: 'p-6 rounded-3xl bg-stone-950 border border-sky-500/30 space-y-4' },
            h(
              'div',
              { className: 'flex items-center justify-between' },
              h('h3', { className: 'text-lg font-bold royal-font text-sky-300' }, '🗝️ Gizli Sırlar (' + unlockedSecretsCount + ' / 6)'),
              h('span', { className: 'text-xs text-stone-400' }, 'Tek bir günde hepsini görmek imkânsızdır')
            ),
            h(
              'div',
              { className: 'space-y-3' },
              SECRETS_CATALOG.map(function (sec) {
                var found = !!state.secrets[sec.id];
                return h(
                  'div',
                  {
                    key: sec.id,
                    className:
                      'p-3.5 rounded-xl border text-xs space-y-1 ' +
                      (found
                        ? 'bg-sky-950/35 border-sky-500/50 text-stone-100'
                        : 'bg-stone-900/50 border-stone-800 text-stone-400')
                  },
                  h(
                    'div',
                    { className: 'font-bold flex items-center justify-between' },
                    h('span', null, (found ? '✓ ' : '🔒 ') + sec.title),
                    h(
                      'span',
                      {
                        className:
                          'text-[10px] px-2 py-0.5 rounded ' +
                          (found ? 'bg-sky-500/20 text-sky-300' : 'bg-stone-800 text-stone-500')
                      },
                      found ? 'AÇIĞA ÇIKTI' : 'KAÇIRILDI'
                    )
                  ),
                  h(
                    'p',
                    { className: 'leading-relaxed' },
                    found ? sec.summary : 'İpucu (Sonraki Oyun İçin): ' + sec.hint
                  )
                );
              })
            )
          )
        ),

        // Tekrar Oyna Çağrısı
        h(
          'div',
          {
            className: 'p-6 rounded-3xl bg-gradient-to-r from-amber-950/60 via-stone-900 to-amber-950/60 border border-amber-500/40 flex flex-col sm:flex-row items-center justify-between gap-4'
          },
          h(
            'div',
            { className: 'space-y-1 text-center sm:text-left' },
            h('h4', { className: 'text-lg font-bold royal-font text-amber-200' }, 'Aynı Günü Farklı Önceliklerle Dene'),
            h(
              'p',
              { className: 'text-xs sm:text-sm text-stone-300' },
              'Sabah bıraktığın mekânlara bu kez ilk vakitte gidersen Anzak, Adem ve Ela nasıl davranacak?'
            )
          ),
          h(
            'button',
            {
              onClick: restartGame,
              className: 'px-6 py-3.5 rounded-2xl font-bold text-sm uppercase tracking-wider bg-amber-500 hover:bg-amber-400 text-stone-950 shadow-xl shrink-0 transition'
            },
            '↺ Yeni Bir Gün Başlat (Tekrar Oyna)'
          )
        )
      ),

      // Tasarım Notu Modalı
      showDesignModal
        ? h(
            'div',
            {
              className: 'fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4',
              onClick: function () { setShowDesignModal(false); }
            },
            h(
              'div',
              {
                className: 'max-w-xl w-full p-6 rounded-3xl bg-stone-950 border border-amber-500/50 space-y-4 text-sm text-stone-200',
                onClick: function (e) { e.stopPropagation(); }
              },
              h('h3', { className: 'text-xl font-bold royal-font text-amber-300' }, 'Prens Tutu — Bir Gün (Neden Bu Bölüm?)'),
              h(
                'p',
                null,
                'Bu 10–15 dakikalık dikey dilim, karmaşık harita/demirhane/düello sistemlerini bir kenara bırakıp oyunun kalbindeki tek bir deneyimi sınar:'
              ),
              h(
                'blockquote',
                { className: 'p-3 rounded-xl bg-amber-950/30 border-l-4 border-amber-400 italic text-amber-100' },
                '"Tutu olarak, ailenle ilişkilerini ve ülkenin geleceğini aynı anda etkileyen zor kararlar vermek."'
              ),
              h(
                'ul',
                { className: 'list-disc pl-5 space-y-1.5 text-xs text-stone-300' },
                h('li', null, 'Birbirine bağlı 3 sorun (Kızıl Geçit, Ekmek İsyanı, Babanın Haşhaşla Uyutulması).'),
                h('li', null, 'Zamanın (3 Vakit), Muhafızın (3 Birlik) ve Hazinenin (2 Kese) hepsine yetmemesi.'),
                h('li', null, 'Sen başka yerdeyken Anzak, Adem ve Ela\'nın kendi çıkarları/korkuları için harekete geçmesi.'),
                h('li', null, 'Akşam olduğunda sabahki kararlarının değiştirdiği bir vasiyet sahnesiyle yüzleşmek.')
              ),
              h(
                'div',
                { className: 'pt-2 text-right' },
                h(
                  'button',
                  {
                    onClick: function () { setShowDesignModal(false); },
                    className: 'px-4 py-2 rounded-xl bg-amber-500 text-stone-950 font-bold text-xs'
                  },
                  'Kapat'
                )
              )
            )
          )
        : null
    );
  }

  window.BirGunApp = BirGunApp;
})();
