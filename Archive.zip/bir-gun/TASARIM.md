# Prens Tutu — Bir Gün (Dikey Dilim Prototipi)

## Tek cümlelik deneyim
Tutu olarak, aileni ve ülkenin geleceğini **aynı anda** etkileyen zor kararlar vermek.

## Neden bu kadar küçük?
Harita, savaş, demirhane, düello ve fermanlar bilerek **yok**. Bu prototip tek bir soruyu sınıyor:
"Zamanım yetmezken kimi dinleyeceğimi, neyi bırakacağımı seçmek eğlenceli mi?"

## Yapı (10–15 dakika)
- **Sabah girişi:** Üç kişi, üç sorunla kapını çalıyor.
- **3 vakit:** Sabah, Öğle, İkindi. Her vakitte **yalnızca bir yere** gidebilirsin. Gidilecek yer sayısı 5–6.
- **Arada:** Sen bir yerdeyken diğer karakterler kendi çıkarları için harekete geçiyor.
- **Akşam:** Vasiyet sahnesi. Sabahki kararların akşamki durumu belirliyor.
- **Gün sonu:** Sonuç, kararlarının izi, bulunan ve bulunamayan sırlar.

## Birbirine bağlı üç sorun
| Sorun | Yüzeyde | Altında |
|---|---|---|
| Kızıl Geçit | Anzak sınıra saray muhafızlarının hepsini götürmek istiyor | Mektupta sadece "yirmi atlı" yazıyor; Anzak şan peşinde |
| Ekmek | Pazarda fiyat iki kat, baronlar ambarları kapattı | Baron Kassar öfkeyi gümüşle besliyor; şartı kölelik fermanının ertelenmesi |
| Baban | Öğleden sonraları konuşamıyor | Hekim Varo onu haşhaşla uyutuyor. Parayı Kassar veriyor, aracı Adem (Kassar'a borçlu) |

Bağlar: muhafız sayısı akşam Ela'yı kurtarıp kurtaramayacağını belirliyor. Ekmek anlaşması babanın son isteğine ters düşüyor. Babanın uyutulması ise ekmek krizinin bir parçası.

## Karakterler ve çıkarları
- **Anzak (27):** Taht istiyor. Sınırda kahraman olursa ordu onun arkasında durur. İzin vermezsen ve onu ikna etmezsen yine gider.
- **Adem (19):** Kassar'a borcu var. Fermanın ertelenmesi onun kurtuluşu. Ret, ifşa ya da uyarı gelirse karşı hamle yapıyor.
- **Ela (13):** Gerçeği görüyor ama kimse onu dinlemiyor. Öğleye kadar gitmezsen ya da onu geri çevirirsen tek başına harekete geçip yakalanıyor.
- **Baban:** Ölüyor. Akşam ne yaptığına bakarak vasiyeti yazacak.

## Kaynaklar
- **Zaman:** 3 vakit (en sert kısıt).
- **Muhafız:** 3 birlik (sınır mı, saray mı?).
- **Hazine:** 2 kese.

## Test ederken neye bakmalı
1. İlk oyunda oyuncu bir şeyi **bırakmak zorunda kaldığını** hissetti mi?
2. Akşam sahnesinde "ah, sabah şunu yapsaydım" dedi mi?
3. Bitince **hemen tekrar** oynamak istedi mi? İkinci oyunda neyi farklı denedi?
4. Hangi karakteri hatırlıyor? Neden?

Bu dört sorunun cevabı "evet"se temel sağlamdır ve oyun buradan büyütülür. "Hayır"sa yönü değiştirmenin zamanı gelmiştir.
