// ============================================================================
// PRENS TUTU: GÖLGELERİN TACI - MODÜL 3: COMBAT & DUEL ENGINE (engine-combat.js) v7.0
// İçerik:
//   - Harita Garnizonuna Bağlı 3v2 Zar Motoru & Monte Carlo Zafer Olasılığı
//   - Savaş Hileleri (Tactical Gambits - 3-5 Komuta Puanı / CP Sistemi):
//       * Kurt Kapanı (2 CP): En düşük zarı doğrudan 6'ya çevirir
//       * Sis Bombası (1 CP): Düşmanın çift zarlarından büyüğünü siler
//       * Patlayan Zarlar (2 CP): Atılan her 6 fazladan 1 zar hakkı doğurur
//   - Birlik Yetenekleri: Okçu Yaylımı, Paladin Işığı, Topçu Bombardımanı, Savaş Narası
//   - 2D Yan Profil Kılıç Düellosu & 3 Duruş (Stance) Sistemi:
//       * Saldırgan Duruş (Hasar +%40, Düşük Stamina maliyeti, Alınan Hasar +%25)
//       * Demir Muhafız (Alınan Hasar -%50, Başarılı Siperde Rakip 1 Tur Sersemler!)
//       * Gölge Dansçısı (Doğru Tahminde Anında +40 Kraliyet Odağı!)
// ============================================================================

window.PrinceTutu = window.PrinceTutu || {};

window.PrinceTutu.CombatEngine = {
  // 1. Muharebe Başlatıcı (18 Eyaletli Harita, Garnizon ve Komuta Puanı CP Entegrasyonlu)
  createBattleState(gameState, targetProvinceId = "eastern_pass") {
    const comp = gameState.armyComposition;
    const targetProv = gameState.provinces[targetProvinceId] || gameState.provinces.eastern_pass;

    const baseUnits =
      comp.infantry + comp.furryArchers + comp.mountainAxemen + comp.doxePaladins;
    const leadershipBonus = Math.floor(gameState.stats.militarySupport / 15);

    const garrisonSupport = Math.floor(
      ((gameState.provinces.eastern_pass?.owner === "player" ? gameState.provinces.eastern_pass.garrison : 0) +
        (gameState.provinces.capital_lalo?.garrison || 0)) / 5
    );

    const totalTroops = baseUnits + leadershipBonus + garrisonSupport;

    let enemyTroops = 12;
    let enemyFactionName = "Vampir-Kara Elf İttifakı";
    let isVampireEnemy = true;

    if (targetProvinceId === "eastern_pass" && targetProv.owner === "player") {
      const vampProv = gameState.provinces.vampire_citadel;
      enemyTroops = Math.max(6, (vampProv?.garrison || 11) + 1);
      enemyFactionName = "Vampir Lordu Malakor'un İstila Ordusu";
      isVampireEnemy = true;
    } else {
      enemyTroops = Math.max(4, targetProv.garrison + (targetProv.defenseBonus || 2));
      if (targetProv.owner === "brothers") {
        enemyFactionName = `${targetProv.name} (Anzak & Adem Garnizonu)`;
        isVampireEnemy = false;
      } else if (targetProv.owner === "vampire") {
        enemyFactionName = `${targetProv.name} (Vampir-Kara Elf Garnizonu)`;
        isVampireEnemy = true;
      } else {
        enemyFactionName = `${targetProv.name} Savunma Ordusu`;
        isVampireEnemy = false;
      }
    }

    const hasArtillery =
      gameState.inventory.items.some((i) => i.id === "furry_cannons") ||
      gameState.decrees.dragonfleetNavy;

    // Savaş başı 3-5 Komuta Puanı (CP) hesapla
    let maxCP = 3;
    if (gameState.stats.intelligence >= 55) maxCP += 1;
    if (gameState.decrees.imperialUniversity || gameState.stats.militarySupport >= 58 || gameState.flags.hasSpyNetwork) {
      maxCP += 1;
    }
    maxCP = Math.min(5, Math.max(3, maxCP));

    const winProb = this.estimateWinProbability(
      totalTroops,
      enemyTroops,
      comp.mountainAxemen > 0 || gameState.stats.intelligence >= 60,
      comp.doxePaladins > 0 && isVampireEnemy
    );

    return {
      targetProvinceId,
      targetProvinceName: targetProv.name,
      terrain: targetProv.terrain || "canyon",
      enemyFactionName,
      isVampireEnemy,
      playerTroops: totalTroops,
      maxPlayerTroops: totalTroops,
      enemyTroops: enemyTroops,
      maxEnemyTroops: enemyTroops,
      commandPoints: maxCP,
      maxCommandPoints: maxCP,
      wolfTrapQueued: false,
      smokeBombQueued: false,
      explodingDiceActive: false,
      bonusDiceRolled: [],
      round: 0,
      archerVolleyUsed: false,
      paladinPurgeUsed: false,
      artilleryUsed: false,
      warcryUsed: false,
      warcryActive: false,
      enemyStunned: false,
      hasArtillery,
      playerDice: [6, 5, 4],
      enemyDice: [5, 4],
      lastEffect: "none",
      effectTick: 0,
      winProbability: winProb,
      units: { ...comp },
      hasTacticalEdge: gameState.stats.intelligence >= 60,
      status: "ongoing",
      battleLog: [
        `⚔️ ${targetProv.name} Cephesi Kuruldu! Toplam ${totalTroops} Tabur (${baseUnits} Saha + ${leadershipBonus} Komuta + ${garrisonSupport} Garnizon İkmali).`,
        `🎖️ Komuta Puanı Hazır: ${maxCP} CP (Kurt Kapanı, Sis Bombası veya Patlayan Zarlar hilelerini kullanabilirsin!)`,
        `🎯 Karşıda ${enemyTroops} Taburluk ${enemyFactionName} var. Monte Carlo Zafer Şansı: %${winProb}`
      ]
    };
  },

  // 2. Monte Carlo Simülasyonu ile Gerçek Zamanlı Kazanma Olasılığı
  estimateWinProbability(pTroops, eTroops, hasDiceBonus, hasPaladinBonus) {
    if (pTroops <= 0) return 0;
    if (eTroops <= 0) return 100;
    const trials = 250;
    let wins = 0;

    for (let t = 0; t < trials; t++) {
      let p = pTroops;
      let e = eTroops;
      while (p > 0 && e > 0) {
        const pCount = Math.min(3, p);
        const eCount = Math.min(2, e);
        const pRolls = Array.from({ length: pCount }, () => Math.floor(Math.random() * 6) + 1).sort((a, b) => b - a);
        const eRolls = Array.from({ length: eCount }, () => Math.floor(Math.random() * 6) + 1).sort((a, b) => b - a);

        if (hasDiceBonus && pRolls.length > 0) pRolls[0] = Math.min(6, pRolls[0] + 1);

        const comps = Math.min(pRolls.length, eRolls.length);
        for (let i = 0; i < comps; i++) {
          if (pRolls[i] > eRolls[i]) {
            e -= hasPaladinBonus && i === 0 && pRolls[0] === 6 ? 2 : 1;
          } else {
            p -= 1;
          }
        }
      }
      if (p > 0) wins++;
    }
    return Math.round((wins / trials) * 100);
  },

  // 3. Furry Okçuları İlk Tur Menzilli Yaylım Ateşi
  triggerArcherVolley(battleState) {
    if (battleState.archerVolleyUsed || battleState.units.furryArchers <= 0 || battleState.status !== "ongoing") {
      return battleState;
    }
    window.PrinceTutu.Sound.play("sword");
    const archers = battleState.units.furryArchers;
    const kills = Math.max(1, Math.min(4, Math.ceil(archers * 0.8)));
    const nextEnemy = Math.max(0, battleState.enemyTroops - kills);
    const nextStatus = nextEnemy === 0 ? "won" : "ongoing";
    if (nextStatus === "won") window.PrinceTutu.Sound.play("victory");

    const winProb = this.estimateWinProbability(
      battleState.playerTroops,
      nextEnemy,
      battleState.hasTacticalEdge || battleState.units.mountainAxemen > 0,
      battleState.units.doxePaladins > 0 && battleState.isVampireEnemy
    );

    return {
      ...battleState,
      enemyTroops: nextEnemy,
      archerVolleyUsed: true,
      lastEffect: "archer_volley",
      effectTick: (battleState.effectTick || 0) + 1,
      winProbability: winProb,
      status: nextStatus,
      battleLog: [
        `🏹 FURRY OKÇU YAYLIM ATEŞİ! ${archers} Furry Nişancı Taburu yeşil izli oklarla gökyüzünü kararttı: Düşman -${kills} Tabur kaybetti!`,
        ...battleState.battleLog
      ]
    };
  },

  // 4. DOXE Kutsal Paladinleri "Işık Arındırması" Aktif Yeteneği
  triggerPaladinPurge(battleState) {
    if (battleState.paladinPurgeUsed || battleState.units.doxePaladins <= 0 || battleState.status !== "ongoing") {
      return battleState;
    }
    window.PrinceTutu.Sound.play("magic");
    const paladins = battleState.units.doxePaladins;
    const kills = battleState.isVampireEnemy
      ? Math.min(5, paladins + 1)
      : Math.min(3, paladins);
    const heal = 1;
    const nextEnemy = Math.max(0, battleState.enemyTroops - kills);
    const nextPlayer = Math.min(battleState.maxPlayerTroops + 2, battleState.playerTroops + heal);
    const nextStatus = nextEnemy === 0 ? "won" : "ongoing";
    if (nextStatus === "won") window.PrinceTutu.Sound.play("victory");

    const winProb = this.estimateWinProbability(
      nextPlayer,
      nextEnemy,
      battleState.hasTacticalEdge || battleState.units.mountainAxemen > 0,
      true
    );

    return {
      ...battleState,
      playerTroops: nextPlayer,
      enemyTroops: nextEnemy,
      paladinPurgeUsed: true,
      lastEffect: "paladin_purge",
      effectTick: (battleState.effectTick || 0) + 1,
      winProbability: winProb,
      status: nextStatus,
      battleLog: [
        `⚖️ DOXE KUTSAL IŞIK ARINDIRMASI! ${paladins} Paladin Taburu gökyüzünden altın ışık sütunu indirdi: Düşman -${kills} Tabur, Ordun +${heal} Tabur kazandı!`,
        ...battleState.battleLog
      ]
    };
  },

  // 5. Furry Barut Topçu Bombardımanı
  triggerArtilleryBarrage(battleState) {
    if (battleState.artilleryUsed || !battleState.hasArtillery || battleState.status !== "ongoing") {
      return battleState;
    }
    window.PrinceTutu.Sound.play("cannon");
    const kills = 3;
    const nextEnemy = Math.max(0, battleState.enemyTroops - kills);
    const nextStatus = nextEnemy === 0 ? "won" : "ongoing";
    if (nextStatus === "won") window.PrinceTutu.Sound.play("victory");

    const winProb = this.estimateWinProbability(
      battleState.playerTroops,
      nextEnemy,
      true,
      battleState.units.doxePaladins > 0 && battleState.isVampireEnemy
    );

    return {
      ...battleState,
      enemyTroops: nextEnemy,
      artilleryUsed: true,
      enemyStunned: true,
      lastEffect: "artillery_barrage",
      effectTick: (battleState.effectTick || 0) + 1,
      winProbability: winProb,
      status: nextStatus,
      battleLog: [
        `💣 FURRY BARUT TOPÇU BOMBARDIMANI! Alevli gülleler düşman saflarını parçaladı: Düşman -${kills} Tabur ve sonraki tur zarları -1 sersemledi!`,
        ...battleState.battleLog
      ]
    };
  },

  // 6. Kuzey Dağ Baltacıları Savaş Narası
  triggerBerserkerWarcry(battleState) {
    if (battleState.warcryUsed || battleState.units.mountainAxemen <= 0 || battleState.status !== "ongoing") {
      return battleState;
    }
    window.PrinceTutu.Sound.play("horn");
    const nextPlayer = Math.min(battleState.maxPlayerTroops + 2, battleState.playerTroops + 1);
    return {
      ...battleState,
      playerTroops: nextPlayer,
      warcryUsed: true,
      warcryActive: true,
      lastEffect: "berserker_cry",
      effectTick: (battleState.effectTick || 0) + 1,
      battleLog: [
        `🪓 KUZEY DAĞ BALTACILARI SAVAŞ NARASI! Orduna +1 Coşku Taburu eklendi ve bir sonraki zar atışında TÜM zarların +1 bonus alacak!`,
        ...battleState.battleLog
      ]
    };
  },

  // --------------------------------------------------------------------------
  // 7. YENİ v7.0: SAVAŞ HİLELERİ (TACTICAL GAMBITS - KOMUTA PUANI / CP SİSTEMİ)
  // --------------------------------------------------------------------------
  // A) KURT KAPANI (2 CP): En düşük zarı doğrudan 6'ya çevirir!
  triggerGambitWolfTrap(battleState) {
    if (battleState.status !== "ongoing" || battleState.commandPoints < 2) {
      window.PrinceTutu.Sound.play("alert");
      return battleState;
    }
    window.PrinceTutu.Sound.play("anvil");

    const updatedDice = [...(battleState.playerDice || [6, 5, 4])];
    if (updatedDice.length > 0) {
      // En düşük zarı bul ve 6 yap
      let minIdx = 0;
      for (let i = 1; i < updatedDice.length; i++) {
        if (updatedDice[i] <= updatedDice[minIdx]) minIdx = i;
      }
      updatedDice[minIdx] = 6;
      updatedDice.sort((a, b) => b - a);
    }

    // Anında taktiksel kıskaç hasarı (-2 Düşman Taburu) VE sıradaki zar atışı için de Kurt Kapanı garantisi
    const instantKills = battleState.round > 0 ? 2 : 1;
    const nextEnemy = Math.max(0, battleState.enemyTroops - instantKills);
    const nextStatus = nextEnemy === 0 ? "won" : "ongoing";
    if (nextStatus === "won") window.PrinceTutu.Sound.play("victory");

    const winProb = this.estimateWinProbability(
      battleState.playerTroops,
      nextEnemy,
      true,
      battleState.units.doxePaladins > 0 && battleState.isVampireEnemy
    );

    return {
      ...battleState,
      commandPoints: battleState.commandPoints - 2,
      playerDice: updatedDice,
      wolfTrapQueued: true,
      enemyTroops: nextEnemy,
      lastEffect: "wolf_trap",
      effectTick: (battleState.effectTick || 0) + 1,
      winProbability: winProb,
      status: nextStatus,
      battleLog: [
        `🐺 SAVAŞ HİLESİ — KURT KAPANI (2 CP): En düşük zar doğrudan 6'ya çevrildi! Kıskaçtaki düşman -${instantKills} Tabur kaybetti ve sıradaki zar atışında en düşük zarın 6 olacak!`,
        ...battleState.battleLog
      ]
    };
  },

  // B) SİS BOMBASI (1 CP): Düşmanın çift zarlarından büyüğünü siler!
  triggerGambitSmokeBomb(battleState) {
    if (battleState.status !== "ongoing" || battleState.commandPoints < 1) {
      window.PrinceTutu.Sound.play("alert");
      return battleState;
    }
    window.PrinceTutu.Sound.play("cannon");

    let updatedEnemyDice = [...(battleState.enemyDice || [5, 4])];
    let removedDie = updatedEnemyDice[0] || 5;
    if (updatedEnemyDice.length > 1) {
      updatedEnemyDice.sort((a, b) => b - a);
      removedDie = updatedEnemyDice.shift(); // En büyük zarı sil!
    } else if (updatedEnemyDice.length === 1) {
      updatedEnemyDice[0] = 1;
    }

    const winProb = this.estimateWinProbability(
      battleState.playerTroops,
      battleState.enemyTroops,
      true,
      battleState.units.doxePaladins > 0 && battleState.isVampireEnemy
    );

    return {
      ...battleState,
      commandPoints: battleState.commandPoints - 1,
      enemyDice: updatedEnemyDice,
      smokeBombQueued: true,
      lastEffect: "smoke_bomb",
      effectTick: (battleState.effectTick || 0) + 1,
      winProbability: winProb,
      battleLog: [
        `💨 SAVAŞ HİLESİ — SİS BOMBASI (1 CP): Düşmanın en yüksek zarı (${removedDie}) dumanla silindi! Sıradaki çarpışmada düşman büyük zarını kaybedecek!`,
        ...battleState.battleLog
      ]
    };
  },

  // C) PATLAYAN ZARLAR (2 CP): Atılan her 6 fazladan 1 zar hakkı doğurur!
  triggerGambitExplodingDice(battleState) {
    if (battleState.status !== "ongoing" || battleState.commandPoints < 2) {
      window.PrinceTutu.Sound.play("alert");
      return battleState;
    }
    window.PrinceTutu.Sound.play("magic");

    // Mevcut zarlardaki 6'lar için anında patlayan zar at ve savaş boyunca aktif et
    const currentSixes = (battleState.playerDice || []).filter((d) => d === 6).length;
    const extraCount = Math.max(1, currentSixes);
    const bonusRolls = Array.from({ length: extraCount }, () => Math.floor(Math.random() * 6) + 1);
    const bonusKills = bonusRolls.filter((r) => r >= 4).length || 1;

    const nextEnemy = Math.max(0, battleState.enemyTroops - bonusKills);
    const nextStatus = nextEnemy === 0 ? "won" : "ongoing";
    if (nextStatus === "won") window.PrinceTutu.Sound.play("victory");

    const winProb = this.estimateWinProbability(
      battleState.playerTroops,
      nextEnemy,
      true,
      battleState.units.doxePaladins > 0 && battleState.isVampireEnemy
    );

    return {
      ...battleState,
      commandPoints: battleState.commandPoints - 2,
      explodingDiceActive: true,
      bonusDiceRolled: bonusRolls,
      enemyTroops: nextEnemy,
      lastEffect: "exploding_dice",
      effectTick: (battleState.effectTick || 0) + 1,
      winProbability: winProb,
      status: nextStatus,
      battleLog: [
        `💥 SAVAŞ HİLESİ — PATLAYAN ZARLAR (2 CP): Atılan her 6 artık fazladan +1 Zar doğuruyor! Anında patlayan zar [${bonusRolls.join(", ")}] ile düşman -${bonusKills} Tabur kaybetti!`,
        ...battleState.battleLog
      ]
    };
  },

  // 8. Risk Tarzı 3v2 Zar Muharebe Turu (Savaş Hileleri & Taktik Entegrasyonlu)
  executeBattleRound(battleState, tactic = "standard") {
    if (battleState.status !== "ongoing") return battleState;
    window.PrinceTutu.Sound.play("dice");

    const nextRound = battleState.round + 1;
    const maxPlayerDice = tactic === "shield_wall" ? 2 : 3;
    const pDiceCount = Math.min(maxPlayerDice, battleState.playerTroops);
    const eDiceCount = Math.min(2, battleState.enemyTroops);

    let pRolls = Array.from({ length: pDiceCount }, () => Math.floor(Math.random() * 6) + 1).sort((a, b) => b - a);
    let eRolls = Array.from({ length: eDiceCount }, () => Math.floor(Math.random() * 6) + 1).sort((a, b) => b - a);

    const bonusNotes = [];

    if ((battleState.hasTacticalEdge || battleState.units.mountainAxemen > 0) && pRolls.length > 0) {
      pRolls[0] = Math.min(6, pRolls[0] + 1);
      bonusNotes.push("Taktik/Baltacı +1");
    }

    if (battleState.warcryActive) {
      pRolls = pRolls.map((r) => Math.min(6, r + 1));
      bonusNotes.push("🪓 Savaş Narası (+1 Tüm Zarlar)");
    }

    if (battleState.enemyStunned) {
      eRolls = eRolls.map((r) => Math.max(1, r - 1));
      bonusNotes.push("💣 Topçu Sarsıntısı (Düşman -1)");
    }

    if (tactic === "all_out" && pRolls.length > 1) {
      pRolls[1] = Math.min(6, pRolls[1] + 1);
      bonusNotes.push("Topyekün Hücum +1");
    } else if (tactic === "shield_wall" && pRolls.length > 0) {
      pRolls[0] = Math.min(6, pRolls[0] + 1);
      bonusNotes.push("🛡️ Kalkan Duvarı");
    }

    // Kurt Kapanı Hilesi kuyruktaysa en düşük zarı doğrudan 6 yap!
    if (battleState.wolfTrapQueued && pRolls.length > 0) {
      pRolls[pRolls.length - 1] = 6;
      pRolls.sort((a, b) => b - a);
      bonusNotes.push("🐺 Kurt Kapanı (En Düşük Zar ➔ 6!)");
    }

    // Sis Bombası Hilesi kuyruktaysa düşmanın çift zarlarından büyüğünü sil!
    if (battleState.smokeBombQueued && eRolls.length > 1) {
      const removed = eRolls.shift();
      bonusNotes.push(`💨 Sis Bombası (Düşman ${removed} Zarı Silindi!)`);
    }

    // Patlayan Zarlar Hilesi aktifse atılan her 6 fazladan 1 zar hakkı doğurur!
    const bonusDiceRolled = [];
    let explodingExtraKills = 0;
    if (battleState.explodingDiceActive) {
      const sixCount = pRolls.filter((r) => r === 6).length;
      for (let s = 0; s < sixCount; s++) {
        const extraRoll = Math.floor(Math.random() * 6) + 1;
        bonusDiceRolled.push(extraRoll);
        if (extraRoll >= 3) {
          explodingExtraKills += 1;
        }
      }
      if (sixCount > 0) {
        bonusNotes.push(`💥 Patlayan Zarlar (+${sixCount} Ek Zar: [${bonusDiceRolled.join(", ")}] ➔ +${explodingExtraKills} Hasar)`);
      }
    }

    let pLoss = 0;
    let eLoss = explodingExtraKills;
    const comparisons = Math.min(pRolls.length, eRolls.length);

    for (let i = 0; i < comparisons; i++) {
      if (pRolls[i] > eRolls[i]) {
        eLoss++;
        if (i === 0 && pRolls[0] === 6 && battleState.units.doxePaladins > 0) {
          eLoss++;
          bonusNotes.push("⚖️ Paladin Kritik (+1)");
        }
      } else {
        pLoss++;
      }
    }

    if (tactic === "all_out" && pLoss > 0) {
      pLoss++;
      bonusNotes.push("Açık Cephe Kaybı (-1)");
    } else if (tactic === "shield_wall" && pLoss > 1) {
      pLoss = 1;
      bonusNotes.push("Kalkan Koruması (Maks 1 Kayıp)");
    }

    const nextPlayer = Math.max(0, battleState.playerTroops - pLoss);
    const nextEnemy = Math.max(0, battleState.enemyTroops - eLoss);

    let nextStatus = "ongoing";
    let msg = `🎲 Tur ${nextRound}: Sen [${pRolls.join(", ")}] vs Düşman [${eRolls.join(", ")}] ${
      bonusNotes.length ? `(${bonusNotes.join(", ")})` : ""
    } ➔ Düşman -${eLoss}, Sen -${pLoss} Tabur.`;

    if (nextEnemy === 0) {
      nextStatus = "won";
      window.PrinceTutu.Sound.play("victory");
      msg = `🏆 KESİN ZAFER! ${battleState.enemyFactionName} tamamen bozguna uğratıldı!`;
    } else if (nextPlayer === 0) {
      nextStatus = "lost";
      window.PrinceTutu.Sound.play("defeat");
      msg = `💀 BOZGUN! Birliklerin ağır kayıplarla geri çekilmek zorunda kaldı.`;
    }

    const winProb = this.estimateWinProbability(
      nextPlayer,
      nextEnemy,
      battleState.hasTacticalEdge || battleState.units.mountainAxemen > 0,
      battleState.units.doxePaladins > 0 && battleState.isVampireEnemy
    );

    return {
      ...battleState,
      round: nextRound,
      playerTroops: nextPlayer,
      enemyTroops: nextEnemy,
      playerDice: pRolls,
      enemyDice: eRolls,
      bonusDiceRolled,
      wolfTrapQueued: false,
      smokeBombQueued: false,
      warcryActive: false,
      enemyStunned: false,
      lastEffect: "dice_clash",
      effectTick: (battleState.effectTick || 0) + 1,
      winProbability: winProb,
      status: nextStatus,
      battleLog: [msg, ...battleState.battleLog]
    };
  },

  // --------------------------------------------------------------------------
  // 9. 2D YAN PROFİL KILIÇ DÜELLOSU MOTORU & 3 DURUŞ (STANCE) SİSTEMİ
  // --------------------------------------------------------------------------
  createDuelState(gameState, opponentId = "anzak") {
    const hasMoonlightSword = gameState.inventory.items.some((i) => i.id === "moonlight_sword");
    const hasSilverDagger = gameState.inventory.items.some((i) => i.name.includes("Gümüş Hançer"));
    const hasDoxeAegis = gameState.inventory.items.some((i) => i.id === "doxe_aegis");
    const hasNorthernArmor =
      gameState.decrees.mountainSmithGuild ||
      gameState.flags.northernForgePact ||
      gameState.inventory.items.some((i) => i.id === "north_armor");

    const isMalakor = opponentId === "malakor";
    const opponentName = isMalakor ? "Kan Lordu Malakor" : "Ağabey Anzak (27)";
    const opponentTitle = isMalakor
      ? "Vampir-Kara Elf İttifakı Başkomutanı"
      : "Kraliyet Muhafızları Asi Komutanı";

    let maxHP = 105;
    if (hasNorthernArmor) maxHP += 25;
    if (hasDoxeAegis) maxHP += 20;

    const enemyMaxHP = isMalakor ? 165 : 140;

    return {
      opponentId,
      opponentName,
      opponentTitle,
      isMalakor,
      playerHP: maxHP,
      maxPlayerHP: maxHP,
      anzakHP: enemyMaxHP,
      maxAnzakHP: enemyMaxHP,
      stamina: 100,
      maxStamina: 100,
      focus: 30, // 70+ olduğunda '⚡ İmparatorluk İnfaz Darbesi' açılır!
      maxFocus: 100,
      stance: "iron_guard", // 'aggressive' | 'iron_guard' | 'shadow_dancer'
      enemyStunned: false,
      round: 0,
      hasMoonlightSword,
      hasSilverDagger,
      hasNorthernArmor,
      hasDoxeAegis,
      lastMoveType: "idle",
      lastHitWasCrit: false,
      effectTick: 0,
      anzakIntent: isMalakor
        ? "Ağır Yukarıdan Kan Kılıcı İndirme (Heavy Slash) — [Siper & Kontra ile Ezilir!]"
        : "Ağır Yukarıdan İndirme (Heavy Slash) — [Siper & Kontra ile Ezilir!]",
      status: "ongoing",
      duelLog: [
        isMalakor
          ? "🦇 Gölge Kalesi burçlarında yan profil düello başladı! Kan Lordu Malakor kızıl kılıcını çekti!"
          : "⚔️ Taht Odası'nda çember kuruldu! Ağabeyin Anzak (27) çift elli kraliyet kılıcını çekti.",
        "🥋 DURUŞ SİSTEMİ AKTİF: Saldırgan Duruş (+%40 Hasar), Demir Muhafız (-%50 Alınan Hasar & Siperde Sersemletme), Gölge Dansçısı (Doğru Tahminde +40🔥 Odak)!",
        hasMoonlightSword
          ? "🗡️ Ayışığı Kraliyet Kılıcı elinde (+14 Efsanevi Hasar)!"
          : hasSilverDagger
          ? "🗡️ Gümüş Hançer elinde (+8 Keskinlik Hasarı)."
          : "⚠️ Özel silah yok!",
        hasNorthernArmor ? "🛡️ Kuzey Çeliği Zırhın kuşanıldı (+25 Can)." : "",
        hasDoxeAegis ? "⚖️ DOXE Kutsal Kalkanı kuşanıldı (+20 Can & Ekstra Stamina)." : ""
      ].filter(Boolean)
    };
  },

  setDuelStance(duelState, stanceId) {
    if (!duelState || duelState.status !== "ongoing") return duelState;
    window.PrinceTutu.Sound.play("click");
    const stanceNames = {
      aggressive: "🔥 Saldırgan Duruş (Hasar +%40, Stamina az harcanır, Alınan Hasar +%25)",
      iron_guard: "🛡️ Demir Muhafız (Alınan Hasar -%50, Başarılı Siperde Rakip 1 Tur Sersemler!)",
      shadow_dancer: "🌙 Gölge Dansçısı (Doğru Tahminde Anında +40🔥 Kraliyet Odağı!)"
    };
    return {
      ...duelState,
      stance: stanceId,
      duelLog: [
        `🥋 Duruş Değiştirildi ➔ ${stanceNames[stanceId] || stanceId}`,
        ...duelState.duelLog
      ]
    };
  },

  executeDuelRound(duelState, moveType, gameState) {
    if (duelState.status !== "ongoing") return duelState;

    const stance = duelState.stance || "iron_guard";
    const baseCosts = {
      dagger_lunge: 25,
      parry_riposte: 15,
      royal_psyche: 20,
      catch_breath: 0,
      royal_execution: 0
    };

    // Saldırgan Duruşta Stamina daha az harcanır (-7⚡ indirim)
    let requiredStamina = baseCosts[moveType] || 0;
    if (stance === "aggressive" && requiredStamina > 0) {
      requiredStamina = Math.max(8, requiredStamina - 7);
    }

    if (duelState.stamina < requiredStamina) {
      window.PrinceTutu.Sound.play("alert");
      return {
        ...duelState,
        duelLog: [
          `⚠️ Yetersiz Dayanıklılık (Stamina)! Bu hamle için ${requiredStamina} Stamina gerekiyor. 'Nefeslen & Odaklan (F)' seç!`,
          ...duelState.duelLog
        ]
      };
    }

    if (moveType === "royal_execution" && duelState.focus < 70) {
      window.PrinceTutu.Sound.play("alert");
      return {
        ...duelState,
        duelLog: [
          "⚠️ İmparatorluk İnfaz Darbesi için en az %70 Kraliyet Odağı (🔥) gerekli!",
          ...duelState.duelLog
        ]
      };
    }

    const weaponBonus = duelState.hasMoonlightSword ? 14 : duelState.hasSilverDagger ? 8 : 2;
    const intent = duelState.anzakIntent;
    const foeName = duelState.isMalakor ? "Malakor" : "Anzak";
    const wasEnemyStunned = !!duelState.enemyStunned;

    let pDmg = 0;
    let aDmg = 0;
    let stamDelta = -requiredStamina;
    let focusDelta = 15;
    let pHeal = 0;
    let isCrit = false;
    let nextEnemyStunned = false;
    let moveDesc = "";

    const critFocusGain = stance === "shadow_dancer" ? 40 : 35;

    if (moveType === "royal_execution") {
      window.PrinceTutu.Sound.play("magic");
      aDmg = 48 + weaponBonus;
      pDmg = 0;
      pHeal = 15;
      stamDelta = +22;
      focusDelta = -70;
      isCrit = true;
      moveDesc = `⚡ İMPARATORLUK İNFAZ DARBESİ! Ekranı yaran altın şimşekle kılıcın ${foeName}'ın savunmasını parçaladı: ${aDmg} GERÇEK HASAR ve +${pHeal} Can yenilendi!`;
    } else if (moveType === "dagger_lunge") {
      window.PrinceTutu.Sound.play("sword");
      if (wasEnemyStunned || intent.includes("Omuz Darbesi") || intent.includes("Kan Pençesi")) {
        aDmg = 32 + weaponBonus;
        pDmg = 4;
        focusDelta = critFocusGain;
        isCrit = true;
        moveDesc = `🗡️ KRİTİK AÇIK YAKALANDI! ${foeName} gardını açtığı anda şimşek gibi sapladın: ${aDmg} Hasar! (+${critFocusGain}🔥 Odak)`;
      } else if (intent.includes("Ağır Yukarıdan")) {
        aDmg = 18 + weaponBonus;
        pDmg = 21;
        moveDesc = `🗡️ Hızlı saplama ile ${aDmg} vurdun ama ${foeName}'ın ağır kılıcından kaçamadın.`;
      } else {
        aDmg = 20 + weaponBonus;
        pDmg = 11;
        moveDesc = `🗡️ Şimşek Hızında Saplama! ${foeName}'a ${aDmg} hasar verdin.`;
      }
    } else if (moveType === "parry_riposte") {
      window.PrinceTutu.Sound.play("shield");
      if (wasEnemyStunned || intent.includes("Ağır Yukarıdan")) {
        aDmg = 35 + weaponBonus;
        pDmg = 2;
        stamDelta += 12;
        focusDelta = critFocusGain;
        isCrit = true;
        if (stance === "iron_guard") {
          nextEnemyStunned = true;
          moveDesc = `🛡️ DEMİR MUHAFIZ SAVUŞTURMASI! ${foeName}'ın ağır darbesini kalkanınla ezup ${aDmg} kontra vurdun ve RAKİBİ 1 TUR SERSEMLETTİN! (+${critFocusGain}🔥 Odak)`;
        } else {
          moveDesc = `🛡️ KUSURSUZ SAVUŞTURMA! ${foeName}'ın ağır darbesini boşa çıkarıp göğsüne ${aDmg} kritik kontra indirdin! (+${critFocusGain}🔥 Odak)`;
        }
      } else if (intent.includes("Omuz Darbesi") || intent.includes("Kan Pençesi")) {
        aDmg = 6;
        pDmg = 24;
        focusDelta = 5;
        moveDesc = `💥 GARDIN KIRILDI! ${foeName} kalkanına omuz/pençe vurup savunmanı sarstı!`;
      } else {
        aDmg = 16;
        pDmg = 10;
        moveDesc = `🛡️ Savunma gardıyla ${aDmg} karşı hasar verdin.`;
      }
    } else if (moveType === "royal_psyche") {
      window.PrinceTutu.Sound.play("sword");
      const statPower = Math.floor((gameState.stats.intelligence + gameState.stats.charisma) / 4.0);
      if (wasEnemyStunned || intent.includes("Öfkeli Kesik") || intent.includes("Gölge Büyüsü")) {
        aDmg = statPower + 16;
        pDmg = 3;
        focusDelta = critFocusGain;
        isCrit = true;
        moveDesc = `🧠 ZİHİNSEL ÜSTÜNLÜK! Öfkeyle saldıran ${foeName}'ın dengesini bozup komutanların önünde ezdin: ${aDmg} Hasar! (+${critFocusGain}🔥 Odak)`;
      } else {
        aDmg = statPower;
        pDmg = 13;
        moveDesc = `🧠 Kraliyet Otoritesi! ${foeName}'ın iradesini sarsarak ${aDmg} darbe vurdun.`;
      }
    } else if (moveType === "catch_breath") {
      window.PrinceTutu.Sound.play("coin");
      stamDelta = duelState.hasDoxeAegis ? +48 : +40;
      pHeal = duelState.hasDoxeAegis ? 15 : 10;
      pDmg = intent.includes("Ağır Yukarıdan") ? 12 : 7;
      aDmg = 5;
      focusDelta = stance === "shadow_dancer" ? 28 : 20;
      moveDesc = `💨 Geri çekilip odaklandın (+${stamDelta} Stamina, +${pHeal} Can, +${focusDelta}🔥 Odak yenilendi).`;
    }

    // Duruş (Stance) Çarpanlarını Uygula
    if (stance === "aggressive" && moveType !== "catch_breath") {
      aDmg = Math.round(aDmg * 1.4);
      pDmg = Math.round(pDmg * 1.25);
    } else if (stance === "iron_guard") {
      pDmg = Math.floor(pDmg * 0.5);
    } else if (stance === "shadow_dancer") {
      pDmg = Math.floor(pDmg * 0.85);
    }

    // Rakip geçen turdan sersemletilmişse bu tur oyuncuya hiç hasar veremez!
    if (wasEnemyStunned) {
      pDmg = 0;
      moveDesc += ` (💫 ${foeName} sersemlediği için sana 0 hasar verebildi!)`;
    }

    const nextAnzakHP = Math.max(0, duelState.anzakHP - aDmg);
    const nextPlayerHP = Math.max(0, Math.min(duelState.maxPlayerHP, duelState.playerHP + pHeal - pDmg));
    const nextStamina = Math.max(0, Math.min(duelState.maxStamina, duelState.stamina + stamDelta));
    const nextFocus = Math.max(0, Math.min(duelState.maxFocus, duelState.focus + focusDelta));

    const intents = duelState.isMalakor
      ? [
          "Ağır Yukarıdan Kan Kılıcı İndirme (Heavy Slash) — [Siper & Kontra (S) ile Ezilir!]",
          "Kalkan Kırma ve Kan Pençesi (Guard Break) — [Kılıç Saplama (A) ile Ezilir, Siperi Kırar!]",
          "Öfkeli Kesik ve Gölge Büyüsü (Berserk Cleave) — [Psikolojik Sarsıntı (D) ile Ezilir!]"
        ]
      : [
          "Ağır Yukarıdan İndirme (Heavy Slash) — [Siper & Kontra (S) ile Ezilir!]",
          "Kalkan Kırma ve Omuz Darbesi (Guard Break) — [Kılıç Saplama (A) ile Ezilir, Siperi Kırar!]",
          "Öfkeli Kesik ve Savaş Narası (Berserk Cleave) — [Psikolojik Sarsıntı (D) ile Ezilir!]"
        ];
    const nextIntent = nextEnemyStunned
      ? "💫 SERSEMLEDİ! (Gardı Tamamen Açık — İstediğin Hamleyle Kritik Vur!)"
      : intents[(duelState.round + 1 + Math.floor(Math.random() * 2)) % intents.length];

    let nextStatus = "ongoing";
    if (nextAnzakHP === 0) {
      nextStatus = "won";
      window.PrinceTutu.Sound.play("victory");
      moveDesc = duelState.isMalakor
        ? "👑 EFSANEVİ ZAFER! Kan Lordu Malakor diz çöktü ve Gölge Kalesi burçlarına Prens Tutu'nun altın sancağı dikildi!"
        : "👑 ZAFER! Anzak kılıcını düşürüp diz çöktü! Tüm Taht Odası 'Yaşasın Prens Tutu!' diye inliyor!";
    } else if (nextPlayerHP === 0) {
      nextStatus = "lost";
      window.PrinceTutu.Sound.play("defeat");
      moveDesc = "🩸 Ağır yaralandın! Baş Danışman ve muhafızlar sis bombasıyla seni düello alanından kaçırdı.";
    }

    return {
      ...duelState,
      round: duelState.round + 1,
      playerHP: nextPlayerHP,
      anzakHP: nextAnzakHP,
      stamina: nextStamina,
      focus: nextFocus,
      enemyStunned: nextEnemyStunned,
      lastMoveType: moveType,
      lastHitWasCrit: isCrit,
      lastDamageDealt: aDmg,
      lastDamageTaken: pDmg,
      effectTick: (duelState.effectTick || 0) + 1,
      anzakIntent: nextIntent,
      status: nextStatus,
      duelLog: [moveDesc, ...duelState.duelLog]
    };
  }
};
