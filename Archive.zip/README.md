# 👑 Prens Tutu: Gölgelerin Tacı (v7.0 — 2D Grand World Atlas & Dark-Fantasy RPG Motoru)

**Prens Tutu: Gölgelerin Tacı**, tarayıcı üzerinde hiçbir harici sunucu veya 3D kütüphane gerektirmeden (`file://` protokolünde çift tıkla) çalışan; **bölümlere özel el çizimi 2D katmanlı sahne illüstrasyonları (Parallax SVG & Canvas 2D)**, prosedürel ortaçağ/savaş film müziği sentezleyicisi, **18 eyaletli Büyük Dünya Atlası (`GrandMap2D`)**, **İkmal Hatları & Abluka mekaniği**, **Kraliyet Demirhanesi**, **Komuta Puanı (CP) Savaş Hileleri** içeren 2D zar muharebe motoru ve **3 Duruşlu (Stance) 2D Yan Profil Kılıç Düellosu** sistemini birleştiren Türkçe bir Dark-Fantasy strateji ve RPG oyunudur.

## 🎨 v7.0 (2D Grand World Atlas & Dark-Fantasy Illustrated Edition) Yenilikleri

1. **🖼️ Katmanlı 2D Canlı Sahne İllüstrasyonları (`Story2DStage` - `engine-2d.js`):**
   - Her sahne ve bölüm için özel olarak tasarlanmış **2D Dark-Fantasy vektör/illüstrasyon sahneleri** (Altın Taht Salonu, Hazine Odası, Savaş Divanı, Kuzey Buzboynuz Zirveleri, Gümüş Pençe Limanı, Mermer Manastır, Kızıl Geçit, Kan Ayini Çölü, Zümrüt Çatı Terası, Gizli Hanedan Kulesi ve 9 farklı Final tablosu).
   - Fare hareketine duyarlı **3 katmanlı Parallax derinlik efekti**, **HTML5 Canvas 2D atmosferik parçacık motoru** (altın saray tozları, kar fırtınası, savaş kıvılcımları, kan damlaları) ve sahnedeki karakterlerin **2D portre kartları (`CharacterPortraitSVG`)**.
2. **🗺️ 18 Eyaletli Büyük Dünya Atlası (`GrandMap2D` - `engine-2d.js` & `engine-core.js`):**
   - **5 Büyük Krallık / 6 Fraksiyon ve 18 Stratejik Bölge:** Lalo İmparatorluğu (5 merkez bölge + Asi Baronluk), Furry Cumhuriyeti (3 kıyı/ada bölgesi), DOXE Kutsal Krallığı (3 güney bölgesi), Kuzey Dağ Klanları (3 sarp zirve bölgesi) ve Vampir - Kara Elf İttifakı (3 doğu karanlık bölgesi).
   - **İkmal Hatları ve Abluka (Supply Lines & Blockade):** Başkent veya müttefik limanlarla bağlantısı kesilen ya da düşman tarafından ablukaya alınan eyaletler her tur **-2 Garnizon** kaybeder ve **0 Vergi** üretir.
   - **Kademeli Fetih Kuralı:** Düşman başkentlerine doğrudan saldırılamaz; önce sınır kaleleri fethedilmeli veya krallıkla diplomatik müttefiklik kurulmalıdır.
   - **Canlı Harita Atmosferi:** Gündüz (`☀️`), Gece (`🌙`) ve Kanlı Ay (`🩸`) ışık filtreleri, karada hareket eden 2D ticaret kervanları ve Batı Denizinde yüzen 2D Furry kalyonları.
3. **⚔️ 2D Taktiksel Muharebe Meydanı & Zar Hileleri (`Battle2DArena` - `engine-2d.js` & `engine-combat.js`):**
   - Sol ve sağ cephede tabur kartları, Monte Carlo zafer simülasyonu, zıplayan ve `6` geldiğinde altın ışıkla parlayan 2D zarlar, Furry yeşil ok yaylımı, alevli topçu gülleleri, DOXE kutsal ışık sütunu ve Kuzey savaş narası şok dalgası animasyonları.
   - **Komuta Puanı (3-5 CP) Savaş Hileleri (Tactical Gambits):**
     - **🐺 Kurt Kapanı (2 CP):** En düşük zarınızı anında `6`'ya çevirir.
     - **💨 Sis Bombası (1 CP):** Düşmanın en yüksek zarını `-2` köreltir.
     - **💥 Patlayan Zarlar (2 CP):** Atılan her `6`, fazladan `+2` kombo hasar çarpanı doğurur.
4. **🤺 2D Yan Profil Kılıç Düellosu & Duruş Sistemi (`Duel2DArena` - `engine-2d.js` & `engine-combat.js`):**
   - Prens Tutu ile Komutan Anzak veya Kan Lordu Malakor arasında klasik RPG yan profil kılıç düellosu.
   - **3 Taktiksel Duruş (Stance):**
     - **🔥 Saldırgan Duruş:** Hasar `+%40`, Stamina maliyeti azalır, alınan hasar artar.
     - **🛡️ Demir Muhafız:** Alınan hasar `-%50`; başarılı **Siper & Kontra** rakibi **1 tur sersemletir (Stun)**!
     - **🌑 Gölge Dansçısı:** Doğru hamle tahmininde ve kritik vuruşta anında **+40 Kraliyet Odağı** kazandırır.
   - `%70+` Kraliyet Odağı ile ekranı karartan ve altın şimşekler çaktıran **⚡ İmparatorluk İnfaz Darbesi**.
5. **⌨️ Tam Klavye Erişilebilirliği (`Pro-Hotkeys`):**
   - **Sekmeler:** `Q` (Hikaye), `W` (18 Eyaletli Dünya Atlası), `E` (Saray & Demirhane), `R` (Fermanlar), `T` (Kayıt & Başarım).
   - **Hikaye:** `1-8` tuşlarıyla hızlı karar seçimi.
   - **Muharebe:** `1/2/3` (Taktik), `A/S/D/F` (Özel Birlik Yetenekleri).
   - **Düello:** `A/S/D/F` (Kılıç Hamleleri), `Space` (İmparatorluk İnfazı), `1/2/3` (Duruş Değiştirme).
   - **Hızlı Kayıt:** `Ctrl + S`.

## 💻 Çalıştırma

Hiçbir kurulum veya yerel sunucu gerekmez. Doğrudan [index.html](file:///Users/genai-hub_01/Desktop/Archive/index.html) dosyasına çift tıklayarak tarayıcınızda açabilirsiniz.
