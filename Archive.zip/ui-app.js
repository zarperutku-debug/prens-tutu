// ============================================================================
// PRENS TUTU: GÖLGELERİN TACI - MODÜL 5: REACT UI (ui-app.js) v7.0
// PURE JAVASCRIPT EDITION (No Babel, Zero Three.js - 100% works on file://!)
// İçerik: Dark-Fantasy Kraliyet Parşömen & Obsidyen Tasarımı, 18 Eyaletli
//         GrandMap2D, Her Bölüme Özel Katmanlı Story2DStage, CP Hileli
//         Battle2DArena, 3 Duruşlu Duel2DArena ve Tam Klavye Kısayolları (Pro-Hotkeys)
// ============================================================================

const { useState, useEffect, useMemo } = React;
const h = React.createElement;

const Icon = ({ name, size = 18, className = "" }) => {
  const paths = {
    crown: h("path", { d: "m2 4 3 12h14l3-12-6 7-4-7-4 7-6-7zm3 16h14" }),
    shield: h("path", { d: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" }),
    sword: h("path", { d: "M14.5 17.5 3 6V3h3l11.5 11.5M13 19l6-6M16 16l4 4M19 21l2-2" }),
    heart: h("path", {
      d: "M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"
    }),
    map: h("path", {
      d: "M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z M15 5.764v15 M9 3.236v15"
    }),
    scroll: h("path", {
      d: "M8 21h12a2 2 0 0 0 2-2v-2H10v2a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v3h4 M19 17V5a2 2 0 0 0-2-2H4"
    })
  };
  return h(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      width: size,
      height: size,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      className
    },
    paths[name] || paths.crown
  );
};

const PrinceTutuApp = () => {
  const [gameState, setGameState] = useState(() => {
    const saved = window.PrinceTutu.loadGame(1);
    return saved || window.PrinceTutu.getInitialState();
  });
  const [activeTab, setActiveTab] = useState("story"); // 'story' | 'map' | 'court' | 'decrees' | 'codex'
  const [selectedProvince, setSelectedProvince] = useState("capital_lalo");
  const [showStoryArt, setShowStoryArt] = useState(true);
  const [vnBeatIndex, setVnBeatIndex] = useState(0);
  const [vnTypedLen, setVnTypedLen] = useState(9999);
  const [vnShowAllText, setVnShowAllText] = useState(false);
  const [vnCinemaMode, setVnCinemaMode] = useState(false);
  const [manualSpeakerId, setManualSpeakerId] = useState(null);
  const [battleState, setBattleState] = useState(null);
  const [duelState, setDuelState] = useState(null);
  const [bannerMsg, setBannerMsg] = useState(
    "👑 Prens Tutu v8.0 (Görsel Roman RPG): Boyalı Sahne İllüstrasyonları, Konuşan Karakter Portreleri, Daktilo Diyalog Motoru ve 18 Eyaletli Dünya Atlası Aktif!"
  );
  const [muted, setMuted] = useState(false);
  const [musicOn, setMusicOn] = useState(false);
  const [saveSlots, setSaveSlots] = useState(() => window.PrinceTutu.getSaveSlotsSummary());

  const vnBeats = useMemo(() => {
    const sc = window.PrinceTutu.SCENES[gameState.scene];
    return window.PrinceTutu.parseSceneIntoVNBeats
      ? window.PrinceTutu.parseSceneIntoVNBeats(sc, gameState.scene)
      : [];
  }, [gameState.scene]);

  useEffect(() => {
    setVnBeatIndex(0);
    setManualSpeakerId(null);
  }, [gameState.scene]);

  useEffect(() => {
    const currentBeat = vnBeats[vnBeatIndex];
    if (!currentBeat || !currentBeat.text) {
      setVnTypedLen(9999);
      return;
    }
    setVnTypedLen(0);
    const totalLen = currentBeat.text.length;
    const timer = setInterval(() => {
      setVnTypedLen((prev) => {
        if (prev >= totalLen) {
          clearInterval(timer);
          return totalLen;
        }
        return prev + 4;
      });
    }, 18);
    return () => clearInterval(timer);
  }, [gameState.scene, vnBeatIndex, vnBeats]);

  const refreshSaveSlots = () => {
    setSaveSlots(window.PrinceTutu.getSaveSlotsSummary());
  };

  const toggleMute = () => {
    const nextMute = !muted;
    window.PrinceTutu.Sound.muted = nextMute;
    setMuted(nextMute);
  };

  const toggleMusic = () => {
    const nextMusic = window.PrinceTutu.Sound.toggleMusic();
    setMusicOn(nextMusic);
    setBannerMsg(
      nextMusic
        ? "🎵 Prosedürel Ortaçağ & Dark-Fantasy Film Müziği Sentezleyicisi başlatıldı!"
        : "🔇 Arka plan müziği duraklatıldı."
    );
  };

  useEffect(() => {
    if (battleState || duelState) {
      window.PrinceTutu.Sound.setMusicMood("battle");
    } else if (
      gameState.scene.includes("assassination") ||
      gameState.scene.includes("dungeon") ||
      gameState.scene.includes("forest")
    ) {
      window.PrinceTutu.Sound.setMusicMood("night");
    } else if (
      gameState.scene.includes("ending") &&
      window.PrinceTutu.SCENES[gameState.scene]?.isVictory
    ) {
      window.PrinceTutu.Sound.setMusicMood("victory");
    } else {
      window.PrinceTutu.Sound.setMusicMood("court");
    }
  }, [gameState.scene, battleState, duelState]);

  const handleSaveGame = (slot = 1) => {
    window.PrinceTutu.Sound.play("coin");
    const ok = window.PrinceTutu.saveGame(gameState, slot);
    refreshSaveSlots();
    setBannerMsg(
      ok
        ? `💾 Oyun ilerlemen Yuva ${slot} üzerine kaydedildi! (Kısayol: Ctrl+S)`
        : "⚠️ Kayıt sırasında hata oluştu."
    );
  };

  const handleLoadGame = (slot = 1) => {
    const loaded = window.PrinceTutu.loadGame(slot);
    if (loaded) {
      window.PrinceTutu.Sound.play("horn");
      setGameState(loaded);
      setBattleState(null);
      setDuelState(null);
      setBannerMsg(`📂 Yuva ${slot} yüklendi (Tur ${loaded.turn}, Bölüm ${loaded.chapter}).`);
    } else {
      window.PrinceTutu.Sound.play("alert");
      setBannerMsg(`⚠️ Yuva ${slot} içinde kayıtlı oyun bulunamadı.`);
    }
  };

  const handleNewGame = () => {
    window.PrinceTutu.Sound.play("horn");
    const fresh = window.PrinceTutu.getInitialState();
    setGameState(fresh);
    setBattleState(null);
    setDuelState(null);
    setActiveTab("story");
    setBannerMsg("🔄 Yeni saltanat başladı! Tur 1 — Altın Taht Salonu.");
  };

  const kingdomStatus = useMemo(() => {
    const { politicalPower, militarySupport, publicSupport } = gameState.stats;
    const avg = Math.round((politicalPower + militarySupport + publicSupport) / 3);
    if (avg >= 65)
      return {
        label: "Güçlü İmparatorluk",
        color: "text-emerald-300 border-emerald-500/40 bg-emerald-950/50"
      };
    if (avg >= 48)
      return {
        label: "İstikrarlı Denge",
        color: "text-amber-300 border-amber-500/40 bg-amber-950/50"
      };
    if (avg >= 35)
      return {
        label: "Hassas / Kırılgan",
        color: "text-orange-300 border-orange-500/40 bg-orange-950/50"
      };
    return {
      label: "Kritik Çöküş Riski",
      color: "text-red-300 border-red-500/40 bg-red-950/50"
    };
  }, [gameState.stats]);

  const legacyScore = useMemo(
    () => window.PrinceTutu.calculateLegacyScore(gameState),
    [gameState]
  );

  const checkChoice = (choice) => {
    if (choice.goldCost && gameState.inventory.gold < choice.goldCost) {
      return { ok: false, reason: `${choice.goldCost} Altın Gerekli` };
    }
    if (choice.requiresItem) {
      const has = gameState.inventory.items.some((i) => i.name === choice.requiresItem);
      if (!has) return { ok: false, reason: `${choice.requiresItem} Gerekli` };
    }
    if (choice.requiresStat) {
      const val = gameState.stats[choice.requiresStat.stat] || 0;
      if (val < choice.requiresStat.value) {
        return { ok: false, reason: `${choice.requiresStat.label} >= ${choice.requiresStat.value}` };
      }
    }
    if (choice.requiresCustom && !choice.requiresCustom(gameState)) {
      return { ok: false, reason: choice.customReason };
    }
    return { ok: true, reason: null };
  };

  const handleStoryChoice = (choice) => {
    const check = checkChoice(choice);
    if (!check.ok) {
      window.PrinceTutu.Sound.play("alert");
      return;
    }
    window.PrinceTutu.Sound.play("click");
    let next = JSON.parse(JSON.stringify(gameState));
    if (choice.goldCost) next.inventory.gold -= choice.goldCost;
    if (choice.statChange) {
      const sc = choice.statChange;
      if (sc.relationships) {
        Object.entries(sc.relationships).forEach(([k, v]) => {
          next.relationships[k] = Math.max(0, Math.min(100, (next.relationships[k] || 0) + v));
        });
      }
      if (sc.worldRelations) {
        Object.entries(sc.worldRelations).forEach(([k, v]) => {
          next.worldRelations[k] = Math.max(0, Math.min(100, (next.worldRelations[k] || 0) + v));
        });
      }
      if (sc.stats) {
        Object.entries(sc.stats).forEach(([k, v]) => {
          next.stats[k] = Math.max(0, Math.min(100, (next.stats[k] || 0) + v));
        });
      }
      if (sc.flags) {
        Object.entries(sc.flags).forEach(([k, v]) => {
          next.flags[k] = v;
        });
      }
      if (sc.decrees) {
        Object.entries(sc.decrees).forEach(([k, v]) => {
          next.decrees[k] = v;
        });
      }
      if (sc.worldState) {
        Object.entries(sc.worldState).forEach(([k, v]) => {
          next.worldState[k] = v;
        });
      }
      if (sc.inventory?.gold) {
        next.inventory.gold += sc.inventory.gold;
        window.PrinceTutu.Sound.play("coin");
      }
      if (sc.armyDelta) {
        Object.entries(sc.armyDelta).forEach(([unit, count]) => {
          next.armyComposition[unit] = (next.armyComposition[unit] || 0) + count;
        });
      }
      if (sc.rivalDelta?.brotherPlotProgress) {
        next.rivalState.brotherPlotProgress = Math.max(
          0,
          Math.min(100, next.rivalState.brotherPlotProgress + sc.rivalDelta.brotherPlotProgress)
        );
      }
    }
    if (choice.nextScene && window.PrinceTutu.SCENES[choice.nextScene]) {
      next.scene = choice.nextScene;
      next.chapter = window.PrinceTutu.SCENES[choice.nextScene].chapter || next.chapter;
      next.historyLog.unshift(`📖 ${choice.text}`);
    }
    next = window.PrinceTutu.processTurnSimulation(next);
    window.PrinceTutu.saveGame(next, 1);
    refreshSaveSlots();
    setBannerMsg(`✨ ${choice.consequence}`);
    setGameState(next);
    if (choice.specialAction === "startBattle") {
      const targetId = choice.battleTarget || "eastern_pass";
      setBattleState(window.PrinceTutu.CombatEngine.createBattleState(next, targetId));
    } else if (choice.specialAction === "startDuel") {
      const foe = choice.duelOpponent || "anzak";
      setDuelState(window.PrinceTutu.CombatEngine.createDuelState(next, foe));
    }
  };

  // Haritadan Sefer Başlatma (Kademeli Fetih Kuralı & 1 AP Kontrolü)
  const handleStartMapCampaign = (provId) => {
    const check = window.PrinceTutu.canLaunchCampaign(gameState, provId);
    if (!check.ok) {
      window.PrinceTutu.Sound.play("alert");
      setBannerMsg(`🔒 ${check.reason}`);
      return;
    }
    if (gameState.actionPoints <= 0) {
      window.PrinceTutu.Sound.play("alert");
      setBannerMsg("❌ Askeri sefer başlatmak için 1 Stratejik Emir Hakkı (AP) gerekli!");
      return;
    }
    const next = JSON.parse(JSON.stringify(gameState));
    next.actionPoints -= 1;
    setGameState(next);
    setBattleState(window.PrinceTutu.CombatEngine.createBattleState(next, provId));
  };

  // Savaş Sonucu İşleyici
  const closeBattleModal = () => {
    if (!battleState) return;
    const next = JSON.parse(JSON.stringify(gameState));
    const targetId = battleState.targetProvinceId;
    if (battleState.status === "won") {
      const targetProv = next.provinces[targetId];
      const loot = targetProv?.isCapital ? 180 : targetId === "vampire_citadel" ? 150 : 105;
      next.inventory.gold += loot;
      next.stats.militarySupport = Math.min(100, next.stats.militarySupport + 16);
      next.stats.politicalPower = Math.min(100, next.stats.politicalPower + 12);
      if (targetProv) {
        targetProv.owner = "player";
        targetProv.garrison = Math.max(6, Math.floor(battleState.playerTroops * 0.7));
        targetProv.unrest = 10;
        targetProv.manualBlockade = false;
        targetProv.isBlockaded = false;
      }
      next.worldState.militaryStrength = "Muzaffer";
      if (targetId === "eastern_pass" || targetId === "vampire_citadel" || targetId === "elf_shadow_spire") {
        next.flags.easternVictory = true;
      }
      if (targetId === "vampire_citadel" || targetId === "elf_shadow_spire") {
        next.flags.vampireCitadelTaken = true;
      }
      if (targetId === "golden_plains" || targetId === "baron_ironkeep") {
        next.armyComposition.infantry += 2;
        next.rivalState.brotherPlotProgress = Math.max(0, next.rivalState.brotherPlotProgress - 22);
      }
      if (targetId === "dark_forest") {
        next.flags.ademNetworkCrushed = true;
        next.rivalState.brotherPlotProgress = Math.max(0, next.rivalState.brotherPlotProgress - 25);
      }
      window.PrinceTutu.evaluateSupplyLines(next);
      window.PrinceTutu.evaluateAchievements(next);
      next.historyLog.unshift(
        `🏆 ${battleState.targetProvinceName} Zaferi kazanıldı! (+${loot} Savaş Ganimeti Altını)`
      );
      setBannerMsg(
        `🏆 ${battleState.targetProvinceName} Fethedildi! +${loot} Altın, +16 Askeri Destek ve İkmal Hatları Güncellendi!`
      );
    } else if (battleState.status === "lost") {
      next.stats.militarySupport = Math.max(0, next.stats.militarySupport - 10);
      next.armyComposition.infantry = Math.max(2, next.armyComposition.infantry - 2);
      setBannerMsg("⚠️ Birliklerin ağır kayıpla geri çekildi (-10 Askeri Destek, -2 Piyade Taburu).");
    }
    setGameState(next);
    setBattleState(null);
  };

  // Düello Sonucu İşleyici
  const closeDuelModal = () => {
    if (!duelState) return;
    const next = JSON.parse(JSON.stringify(gameState));
    if (duelState.status === "won") {
      if (duelState.isMalakor) {
        next.flags.malakorDefeated = true;
        next.flags.vampireCitadelTaken = true;
        next.flags.easternVictory = true;
        next.provinces.vampire_citadel.owner = "player";
        next.provinces.vampire_citadel.garrison = 10;
        next.inventory.gold += 180;
        next.stats.militarySupport = Math.min(100, next.stats.militarySupport + 25);
        next.stats.charisma = Math.min(100, next.stats.charisma + 20);
        next.historyLog.unshift(
          "🩸 Kan Lordu Malakor birebir düelloda devrildi! Gölge Kalesi teslim oldu (+180 Altın)!"
        );
        setBannerMsg(
          "🩸 Kan Lordu Malakor'u düelloda yendin! Gölge Kalesi senin oldu ve +180 Altın kazandın!"
        );
      } else {
        next.flags.anzakDefeated = true;
        next.rivalState.brotherPlotProgress = 0;
        next.stats.politicalPower = Math.min(100, next.stats.politicalPower + 25);
        next.stats.militarySupport = Math.min(100, next.stats.militarySupport + 20);
        next.provinces.golden_plains.owner = "player";
        if (next.provinces.baron_ironkeep) next.provinces.baron_ironkeep.owner = "player";
        next.historyLog.unshift("⚔️ Ağabey Anzak Taht Düellosu'nda mağlup edildi!");
        setBannerMsg(
          "⚔️ Anzak'ı düelloda yendin! Kardeşlerin darbe planı çöktü ve Güney eyaletleri sana biat etti!"
        );
      }
      window.PrinceTutu.evaluateSupplyLines(next);
      window.PrinceTutu.evaluateAchievements(next);
    } else if (duelState.status === "lost") {
      next.stats.politicalPower = Math.max(0, next.stats.politicalPower - 10);
      next.rivalState.brotherPlotProgress = Math.min(95, next.rivalState.brotherPlotProgress + 15);
      setBannerMsg("🩸 Düellodan yaralı çekildin! Rakiplerinin saraydaki nüfuzu arttı.");
    }
    setGameState(next);
    setDuelState(null);
  };

  // ==========================================================================
  // 6. TAM KLAVYE ERİŞİLEBİLİRLİĞİ (PRO-HOTKEYS)
  //   - Sekmeler: Q (Hikaye), W (2D Harita), E (Saray & Demirhane), R (Fermanlar), T (Kayıt/Başarım)
  //   - Hikaye: 1-8 Seçenekler
  //   - Savaş Modalı: 1 (Standart), 2 (Hücum), 3 (Kalkan), A (Furry Oku), S (Paladin), D (Topçu), F (Nara)
  //   - Düello Modalı: A (Sapla), S (Siper), D (Psikolojik), F (Nefeslen), Space (İnfaz), 1/2/3 (Duruş)
  //   - Hızlı Kayıt: Ctrl + S (veya Cmd + S)
  // ==========================================================================
  useEffect(() => {
    const onKeyDown = (e) => {
      const key = e.key.toLowerCase();

      // Ctrl + S / Cmd + S Hızlı Kayıt
      if ((e.ctrlKey || e.metaKey) && key === "s") {
        e.preventDefault();
        handleSaveGame(1);
        return;
      }

      // 1. Savaş Modalı Kısayolları
      if (battleState) {
        if (battleState.status !== "ongoing") {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            closeBattleModal();
          }
          return;
        }
        if (e.key === "1") {
          setBattleState(window.PrinceTutu.CombatEngine.executeBattleRound(battleState, "standard"));
        } else if (e.key === "2") {
          setBattleState(window.PrinceTutu.CombatEngine.executeBattleRound(battleState, "all_out"));
        } else if (e.key === "3") {
          setBattleState(window.PrinceTutu.CombatEngine.executeBattleRound(battleState, "shield_wall"));
        } else if (key === "a") {
          setBattleState(window.PrinceTutu.CombatEngine.triggerArcherVolley(battleState));
        } else if (key === "s") {
          setBattleState(window.PrinceTutu.CombatEngine.triggerPaladinPurge(battleState));
        } else if (key === "d") {
          setBattleState(window.PrinceTutu.CombatEngine.triggerArtilleryBarrage(battleState));
        } else if (key === "f") {
          setBattleState(window.PrinceTutu.CombatEngine.triggerBerserkerWarcry(battleState));
        }
        return;
      }

      // 2. Düello Modalı Kısayolları
      if (duelState) {
        if (duelState.status !== "ongoing") {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            closeDuelModal();
          }
          return;
        }
        if (key === "a") {
          setDuelState(window.PrinceTutu.CombatEngine.executeDuelRound(duelState, "dagger_lunge", gameState));
        } else if (key === "s") {
          setDuelState(window.PrinceTutu.CombatEngine.executeDuelRound(duelState, "parry_riposte", gameState));
        } else if (key === "d") {
          setDuelState(window.PrinceTutu.CombatEngine.executeDuelRound(duelState, "royal_psyche", gameState));
        } else if (key === "f") {
          setDuelState(window.PrinceTutu.CombatEngine.executeDuelRound(duelState, "catch_breath", gameState));
        } else if (e.key === " " || e.code === "Space") {
          e.preventDefault();
          if (duelState.focus >= 70) {
            setDuelState(window.PrinceTutu.CombatEngine.executeDuelRound(duelState, "royal_execution", gameState));
          }
        } else if (e.key === "1") {
          setDuelState(window.PrinceTutu.CombatEngine.setDuelStance(duelState, "aggressive"));
        } else if (e.key === "2") {
          setDuelState(window.PrinceTutu.CombatEngine.setDuelStance(duelState, "iron_guard"));
        } else if (e.key === "3") {
          setDuelState(window.PrinceTutu.CombatEngine.setDuelStance(duelState, "shadow_dancer"));
        }
        return;
      }

      if (gameState.pendingEvent) return;

      // 3. Ana Sekme Kısayolları (Q, W, E, R, T)
      if (key === "q") {
        window.PrinceTutu.Sound.play("click");
        setActiveTab("story");
        return;
      }
      if (key === "w") {
        window.PrinceTutu.Sound.play("click");
        setActiveTab("map");
        return;
      }
      if (key === "e") {
        window.PrinceTutu.Sound.play("click");
        setActiveTab("court");
        return;
      }
      if (key === "r") {
        window.PrinceTutu.Sound.play("click");
        setActiveTab("decrees");
        return;
      }
      if (key === "t") {
        window.PrinceTutu.Sound.play("click");
        refreshSaveSlots();
        setActiveTab("codex");
        return;
      }

      // 4. Hikaye Seçenek Kısayolları (1-8)
      if (activeTab === "story") {
        const sc = window.PrinceTutu.SCENES[gameState.scene];
        if (sc && sc.choices && e.key >= "1" && e.key <= "8") {
          const idx = parseInt(e.key, 10) - 1;
          if (sc.choices[idx]) {
            handleStoryChoice(sc.choices[idx]);
          }
        }
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  });

  // Rastgele Kriz Olayı Seçimi
  const handleEventChoice = (evChoice) => {
    if (evChoice.costGold && gameState.inventory.gold < evChoice.costGold) {
      window.PrinceTutu.Sound.play("alert");
      setBannerMsg(`❌ Bu karar için ${evChoice.costGold} Altın gerekiyor!`);
      return;
    }
    window.PrinceTutu.Sound.play("click");
    const next = JSON.parse(JSON.stringify(gameState));
    evChoice.apply(next);
    next.pendingEvent = null;
    window.PrinceTutu.evaluateAchievements(next);
    next.historyLog.unshift(`⚡ Kriz Kararı: ${evChoice.text} (${evChoice.effectText})`);
    setBannerMsg(`⚡ Kriz Çözüldü: ${evChoice.effectText}`);
    setGameState(next);
  };

  // Ferman İlan Etme
  const handleEnactDecree = (decree) => {
    if (gameState.decrees[decree.id]) return;
    if (gameState.inventory.gold < decree.costGold) {
      window.PrinceTutu.Sound.play("alert");
      setBannerMsg("❌ Bu ferman için yeterli altının yok!");
      return;
    }
    if (decree.reqStat && gameState.stats[decree.reqStat.stat] < decree.reqStat.value) {
      window.PrinceTutu.Sound.play("alert");
      setBannerMsg(`❌ Gereksinim karşılanmıyor: ${decree.reqStat.label}`);
      return;
    }
    window.PrinceTutu.Sound.play("horn");
    const next = JSON.parse(JSON.stringify(gameState));
    next.inventory.gold -= decree.costGold;
    next.decrees[decree.id] = true;
    if (decree.id === "abolishSlavery") {
      next.worldRelations.doxe = Math.min(100, next.worldRelations.doxe + 30);
      next.relationships.people = Math.min(100, next.relationships.people + 25);
      next.armyComposition.doxePaladins += 2;
      next.worldState.slavery = "Yasaklandı";
    } else if (decree.id === "furryTradePact") {
      next.inventory.gold += 120;
      next.relationships.furries = Math.min(100, next.relationships.furries + 20);
      next.armyComposition.furryArchers += 2;
      next.worldState.economicState = "Altın Çağ";
    } else if (decree.id === "martialLaw") {
      next.stats.militarySupport = Math.min(100, next.stats.militarySupport + 18);
      next.stats.publicSupport = Math.max(0, next.stats.publicSupport - 10);
      next.armyComposition.infantry += 3;
    } else if (decree.id === "mountainSmithGuild") {
      next.worldRelations.mountainTribes = Math.min(100, next.worldRelations.mountainTribes + 25);
      next.armyComposition.mountainAxemen += 3;
      if (!next.inventory.items.some((i) => i.id === "north_armor")) {
        next.inventory.items.push({
          id: "north_armor",
          name: "Kuzey Çeliği Kraliyet Zırhı",
          type: "silah",
          description: "Dağ demircilerinin dövdüğü zırh (Düelloda +25 Can)",
          power: 8
        });
      }
    } else if (decree.id === "royalInquisition") {
      next.flags.hasSpyNetwork = true;
      next.rivalState.brotherPlotProgress = Math.max(0, next.rivalState.brotherPlotProgress - 35);
      next.stats.politicalPower = Math.min(100, next.stats.politicalPower + 12);
    } else if (decree.id === "imperialUniversity") {
      next.maxActionPoints = 3;
      next.actionPoints += 1;
      next.stats.intelligence = Math.min(100, next.stats.intelligence + 10);
    } else if (decree.id === "freePeasantLand") {
      next.stats.publicSupport = Math.min(100, next.stats.publicSupport + 18);
      next.armyComposition.infantry += 2;
      next.provinces.golden_plains.garrison = Math.max(2, next.provinces.golden_plains.garrison - 2);
    } else if (decree.id === "easternFortifications") {
      next.provinces.eastern_pass.garrison += 4;
      next.rivalState.vampireInvasionTimer += 3;
      next.stats.militarySupport = Math.min(100, next.stats.militarySupport + 10);
    } else if (decree.id === "dragonfleetNavy") {
      next.provinces.furry_coast.garrison += 3;
      next.armyComposition.furryArchers += 2;
      next.stats.militarySupport = Math.min(100, next.stats.militarySupport + 12);
      next.relationships.furries = Math.min(100, next.relationships.furries + 15);
    } else if (decree.id === "royalSisterAcademy") {
      next.relationships.sister9 = Math.min(100, next.relationships.sister9 + 15);
      next.relationships.sister13 = Math.min(100, next.relationships.sister13 + 15);
      next.stats.publicSupport = Math.min(100, next.stats.publicSupport + 12);
      next.rivalState.brotherPlotProgress = Math.max(0, next.rivalState.brotherPlotProgress - 15);
      next.flags.sistersProtected = true;
    }
    window.PrinceTutu.evaluateSupplyLines(next);
    window.PrinceTutu.evaluateAchievements(next);
    next.historyLog.unshift(`📜 Ferman İlan Edildi: ${decree.title}`);
    setGameState(next);
    setBannerMsg(`📜 ${decree.title} yürürlüğe girdi!`);
  };

  const currentScene = window.PrinceTutu.SCENES[gameState.scene];
  const activeProv = gameState.provinces[selectedProvince] || gameState.provinces.capital_lalo;
  const activeCrisis = gameState.pendingEvent
    ? window.PrinceTutu.RANDOM_EVENTS.find((e) => e.id === gameState.pendingEvent)
    : null;

  const getOwnerBadge = (owner) => {
    const map = {
      player: { text: "Prens Tutu (Lalo İmparatorluğu)", cls: "bg-blue-700 text-white border border-blue-400" },
      brothers: { text: "Asi Baronlar (Anzak & Adem)", cls: "bg-orange-700 text-white border border-orange-400" },
      vampire: { text: "Vampir-Kara Elf İttifakı", cls: "bg-red-800 text-white border border-red-400" },
      furry: { text: "Furry Cumhuriyeti", cls: "bg-emerald-700 text-white border border-emerald-400" },
      doxe: { text: "DOXE Kutsal Krallığı", cls: "bg-indigo-700 text-white border border-indigo-400" },
      tribes: { text: "Kuzey Dağ Klanları", cls: "bg-amber-600 text-black border border-amber-300" }
    };
    return map[owner] || map.player;
  };

  const totalProvincesCount = Object.keys(gameState.provinces).length;
  const totalPlayerProvs = Object.values(gameState.provinces).filter((p) => p.owner === "player").length;
  const totalBattalions =
    gameState.armyComposition.infantry +
    gameState.armyComposition.furryArchers +
    gameState.armyComposition.mountainAxemen +
    gameState.armyComposition.doxePaladins;

  const GrandMap2D = window.PrinceTutu.GrandMap2D;
  const Story2DStage = window.PrinceTutu.Story2DStage;
  const Battle2DArena = window.PrinceTutu.Battle2DArena;
  const Duel2DArena = window.PrinceTutu.Duel2DArena;
  const CharacterPortraitSVG = window.PrinceTutu.CharacterPortraitSVG;

  const campaignCheck = activeProv ? window.PrinceTutu.canLaunchCampaign(gameState, activeProv.id) : { ok: false };

  return h(
    "div",
    { className: "min-h-screen pb-14 text-amber-50" },
    h(
      "div",
      { className: "container mx-auto px-3 sm:px-5 pt-4 max-w-7xl" },
      // ======================================================================
      // ÜST KRALİYET BAŞLIĞI (DARK-FANTASY OBSIDIAN & GOLD HEADER)
      // ======================================================================
      h(
        "header",
        { className: "rpg-panel rounded-2xl p-4 mb-5" },
        h(
          "div",
          { className: "flex flex-col xl:flex-row justify-between items-center gap-4" },
          h(
            "div",
            { className: "flex items-center gap-3.5" },
            CharacterPortraitSVG
              ? h(CharacterPortraitSVG, { charId: "tutu", size: 58 })
              : h(
                  "div",
                  { className: "p-3 bg-amber-500/10 border border-amber-500/40 rounded-xl royal-glow" },
                  h(Icon, { name: "crown", size: 32, className: "text-amber-400" })
                ),
            h(
              "div",
              null,
              h(
                "div",
                { className: "flex flex-wrap items-center gap-2" },
                h(
                  "h1",
                  {
                    className:
                      "text-2xl md:text-3xl font-extrabold royal-font bg-gradient-to-r from-amber-200 via-yellow-400 to-amber-600 bg-clip-text text-transparent"
                  },
                  "Prens Tutu: Gölgelerin Tacı"
                ),
                h(
                  "span",
                  {
                    className:
                      "px-2.5 py-0.5 bg-amber-500/15 border border-amber-400/50 text-amber-300 text-[11px] font-bold rounded-full"
                  },
                  "🎭 Görsel Roman RPG & 18 Eyalet"
                ),
                h(
                  "span",
                  {
                    className:
                      "px-2.5 py-0.5 bg-yellow-500/15 border border-yellow-400/50 text-yellow-300 text-[11px] font-bold rounded-full"
                  },
                  "🏆 Miras: ",
                  legacyScore
                )
              ),
              h(
                "p",
                { className: "text-xs text-amber-200/75 mt-0.5" },
                "Tur ",
                gameState.turn,
                " • Bölüm ",
                gameState.chapter,
                "/5 • Mekan: ",
                currentScene?.location
              )
            )
          ),

          // Sekme Butonları (Q / W / E / R / T Kısayol Etiketli)
          h(
            "div",
            { className: "flex flex-wrap items-center justify-center gap-1.5" },
            [
              { id: "story", hotkey: "Q", label: "📖 Görsel Roman" },
              { id: "map", hotkey: "W", label: `🗺️ Dünya Atlası (${gameState.actionPoints} AP)` },
              { id: "court", hotkey: "E", label: "🏯 Saray & Demirhane" },
              { id: "decrees", hotkey: "R", label: "📜 Fermanlar (10)" },
              {
                id: "codex",
                hotkey: "T",
                label: `🏆 Başarım (${(gameState.unlockedAchievements || []).length}/12) & Kayıt`
              }
            ].map((tab) =>
              h(
                "button",
                {
                  key: tab.id,
                  onClick: () => {
                    window.PrinceTutu.Sound.play("click");
                    if (tab.id === "codex") refreshSaveSlots();
                    setActiveTab(tab.id);
                  },
                  className: `px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all border ${
                    activeTab === tab.id
                      ? "bg-gradient-to-r from-amber-500 to-yellow-600 text-black border-yellow-300 shadow-lg"
                      : "rpg-card text-amber-100 hover:bg-stone-800"
                  }`
                },
                h(
                  "span",
                  {
                    className: `px-1.5 py-0.2 rounded text-[10px] font-extrabold ${
                      activeTab === tab.id ? "bg-black/25 text-black" : "bg-stone-950 text-amber-400"
                    }`
                  },
                  tab.hotkey
                ),
                tab.label
              )
            ),
            h(
              "button",
              {
                onClick: () => setVnCinemaMode(!vnCinemaMode),
                className: `px-3 py-2 rounded-xl text-xs font-bold border transition-all ${
                  vnCinemaMode
                    ? "bg-amber-500 text-black border-yellow-200 shadow-lg"
                    : "rpg-card text-amber-200"
                }`,
                title: "Görsel Roman Sinema Modu (Yan Panelleri Gizle/Göster)"
              },
              vnCinemaMode ? "🎬 Sinema: Açık" : "🎬 Sinema"
            ),
            h(
              "button",
              {
                onClick: toggleMusic,
                className: `px-3 py-2 rounded-xl text-xs font-bold border transition-all ${
                  musicOn
                    ? "bg-amber-700 border-amber-300 text-white shadow-lg"
                    : "rpg-card text-amber-300"
                }`,
                title: "Prosedürel Film Müziği Sentezleyicisini Aç/Kapat"
              },
              musicOn ? "🎵 Müzik: Açık" : "🎵 Müzik"
            ),
            h(
              "button",
              {
                onClick: () => handleSaveGame(1),
                className:
                  "px-2.5 py-2 bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-500/40 rounded-xl text-xs font-bold text-emerald-300",
                title: "Hızlı Kaydet (Ctrl + S)"
              },
              "💾"
            ),
            h(
              "button",
              {
                onClick: handleNewGame,
                className: "px-2.5 py-2 rpg-card rounded-xl text-xs font-bold text-amber-200",
                title: "Yeni Oyun Başlat"
              },
              "🔄"
            ),
            h(
              "button",
              {
                onClick: toggleMute,
                className: "p-2 rpg-card rounded-xl text-xs",
                title: "Ses Efektlerini Aç/Kapat"
              },
              muted ? "🔇" : "🔊"
            )
          )
        ),

        // Alt Durum & Uyarı Şeridi
        h(
          "div",
          {
            className:
              "mt-3 pt-3 border-t border-amber-500/20 flex flex-col md:flex-row justify-between items-center gap-2 text-xs"
          },
          h("div", { className: "text-amber-300 font-medium" }, bannerMsg),
          h(
            "div",
            { className: "flex flex-wrap items-center gap-2" },
            h(
              "span",
              {
                className:
                  "px-2.5 py-1 bg-amber-950/80 border border-amber-500/40 rounded-lg text-amber-200 font-semibold"
              },
              "⚡ Emir Hakkı: ",
              gameState.actionPoints,
              "/",
              gameState.maxActionPoints,
              " AP"
            ),
            h(
              "span",
              {
                className:
                  "px-2.5 py-1 bg-orange-950/80 border border-orange-500/40 rounded-lg text-orange-300"
              },
              "⚠️ Kardeş Darbesi: ",
              h("strong", null, "%", gameState.rivalState.brotherPlotProgress)
            ),
            h(
              "span",
              {
                className: "px-2.5 py-1 bg-red-950/80 border border-red-500/40 rounded-lg text-red-300"
              },
              "🦇 Vampir Akını: ",
              h("strong", null, gameState.rivalState.vampireInvasionTimer, " Tur")
            )
          )
        )
      ),

      // ======================================================================
      // ANA GÖVDE IZGARASI (SOL: KARAKTER & ORDU | ORTA: GÖRSEL ROMAN SAHNESİ | SAĞ: DİPLOMASİ)
      // ======================================================================
      h(
        "div",
        { className: "grid lg:grid-cols-4 gap-5" },
        // SOL SÜTUN: İSTATİSTİKLER, SAHA ORDUSU VE HAZİNE (Sinema Modunda Gizlenir)
        !vnCinemaMode &&
          h(
            "div",
            { className: "lg:col-span-1 space-y-5" },
            h(
              "div",
              { className: "rpg-panel rounded-2xl p-5" },
              h(
                "h3",
                {
                  className:
                    "text-xs font-bold uppercase tracking-wider text-amber-400 mb-3 flex items-center gap-2 royal-font"
                },
                h(Icon, { name: "shield", size: 15 }),
                " Hükümdarlık Özellikleri"
              ),
              Object.entries(gameState.stats).map(([k, val]) => {
                const names = {
                  politicalPower: "Politik Güç",
                  moralStanding: "Ahlaki Duruş",
                  militarySupport: "Askeri Destek",
                  publicSupport: "Halk Desteği",
                  intelligence: "Zeka (Taktik & CP)",
                  charisma: "Karizma"
                };
                return h(
                  "div",
                  { key: k, className: "mb-2.5" },
                  h(
                    "div",
                    { className: "flex justify-between text-xs mb-1" },
                    h("span", { className: "text-amber-100/85" }, names[k]),
                    h("span", { className: "font-bold text-amber-300" }, val, "%")
                  ),
                  h(
                    "div",
                    { className: "w-full bg-stone-900 h-2 rounded-full overflow-hidden border border-amber-500/20" },
                    h("div", {
                      className: `h-full transition-all duration-500 ${
                        val >= 70
                          ? "bg-gradient-to-r from-emerald-600 to-emerald-400"
                          : val >= 45
                          ? "bg-gradient-to-r from-amber-600 to-yellow-400"
                          : "bg-gradient-to-r from-red-700 to-orange-500"
                      }`,
                      style: { width: `${val}%` }
                    })
                  )
                );
              })
            ),

            h(
              "div",
              { className: "rpg-panel rounded-2xl p-5" },
              h(
                "div",
                { className: "flex justify-between items-center mb-3" },
                h(
                  "h3",
                  {
                    className:
                      "text-xs font-bold uppercase tracking-wider text-red-400 flex items-center gap-2 royal-font"
                  },
                  h(Icon, { name: "sword", size: 15 }),
                  " Koalisyon Ordusu"
                ),
                h(
                  "span",
                  { className: "text-xs font-bold px-2 py-0.5 bg-red-950 border border-red-500/30 text-red-200 rounded" },
                  totalBattalions,
                  " Tabur"
                )
              ),
              h(
                "div",
                { className: "space-y-2 text-xs" },
                h(
                  "div",
                  { className: "flex justify-between p-2 rpg-card rounded-lg" },
                  h("span", null, "🛡️ Kraliyet Piyadesi"),
                  h("strong", { className: "text-white" }, gameState.armyComposition.infantry, " Tabur")
                ),
                h(
                  "div",
                  { className: "flex justify-between p-2 rpg-card rounded-lg" },
                  h("span", null, "🏹 Furry Keskin Nişancısı"),
                  h("strong", { className: "text-emerald-400" }, gameState.armyComposition.furryArchers, " Tabur")
                ),
                h(
                  "div",
                  { className: "flex justify-between p-2 rpg-card rounded-lg" },
                  h("span", null, "🪓 Kuzey Dağ Baltacısı"),
                  h("strong", { className: "text-amber-400" }, gameState.armyComposition.mountainAxemen, " Tabur")
                ),
                h(
                  "div",
                  { className: "flex justify-between p-2 rpg-card rounded-lg" },
                  h("span", null, "⚖️ DOXE Kutsal Paladini"),
                  h("strong", { className: "text-indigo-300" }, gameState.armyComposition.doxePaladins, " Tabur")
                )
              )
            ),

            h(
              "div",
              { className: "rpg-panel rounded-2xl p-5" },
              h(
                "div",
                {
                  className:
                    "flex items-center justify-between mb-3 p-3 bg-amber-950/50 border border-amber-500/40 rounded-xl"
                },
                h("span", { className: "text-xs text-amber-200 font-semibold royal-font" }, "Kraliyet Hazinesi"),
                h(
                  "span",
                  { className: "text-base font-extrabold text-yellow-400 flex items-center gap-1" },
                  "💰 ",
                  gameState.inventory.gold,
                  " Altın"
                )
              ),
              h(
                "div",
                { className: "space-y-2" },
                gameState.inventory.items.map((item, i) =>
                  h(
                    "div",
                    { key: i, className: "p-2.5 rpg-card rounded-xl text-xs" },
                    h(
                      "div",
                      { className: "flex justify-between font-bold text-amber-200 mb-0.5" },
                      h("span", null, item.name),
                      h("span", { className: "text-emerald-400" }, "+", item.power, " Etki")
                    ),
                    h("p", { className: "text-[11px] text-amber-100/70" }, item.description)
                  )
                )
              )
            )
          ),

        // ORTA SÜTUN (Sinema Modunda 4 Birim Tam Ekran, Normalde 2 Birim): GÖRSEL ROMAN SAHNESİ & HARİTA
        h(
          "div",
          { className: vnCinemaMode ? "lg:col-span-4" : "lg:col-span-2" },
          // TAB 1: GÖRSEL ROMAN (VISUAL NOVEL) SAHNESİ VE DİYALOG KUTUSU
          activeTab === "story" &&
            currentScene &&
            (() => {
              const activeBeat = vnBeats[vnBeatIndex] || {
                index: 0,
                text: currentScene.description || "",
                speakerId: "tutu",
                speakerName: "Prens Tutu",
                speakerTitle: "Altın Taht Veliahtı",
                speakerAccent: "#f59e0b",
                speakerBorder: "#fbbf24"
              };
              const effectiveSpeakerId = manualSpeakerId || activeBeat.speakerId || "tutu";
              const effectiveMeta =
                (window.PrinceTutu.CHARACTER_META && window.PrinceTutu.CHARACTER_META[effectiveSpeakerId]) || {
                  name: activeBeat.speakerName,
                  title: activeBeat.speakerTitle,
                  accent: activeBeat.speakerAccent,
                  border: activeBeat.speakerBorder
                };
              const isTyping = !vnShowAllText && vnTypedLen < (activeBeat.text || "").length;
              const hasMoreBeats = vnBeatIndex < vnBeats.length - 1;

              const handleAdvanceVN = () => {
                window.PrinceTutu.Sound.play("click");
                if (isTyping) {
                  setVnTypedLen((activeBeat.text || "").length);
                } else if (hasMoreBeats) {
                  setManualSpeakerId(null);
                  setVnBeatIndex(vnBeatIndex + 1);
                }
              };

              const vnDialogueBox = h(
                "div",
                {
                  className:
                    "rounded-2xl bg-black/88 backdrop-blur-xl border-2 border-amber-500/55 p-4 md:p-5 shadow-[0_15px_50px_rgba(0,0,0,0.95)] transition-all"
                },
                // Üst Konuşmacı Plakası & Görsel Roman Kontrolleri
                h(
                  "div",
                  { className: "flex flex-wrap items-center justify-between gap-2 pb-3 mb-3 border-b border-amber-500/25" },
                  h(
                    "div",
                    { className: "flex items-center gap-2.5" },
                    h(
                      "span",
                      {
                        className: "px-3 py-1 rounded-lg text-xs royal-font font-black uppercase tracking-wider shadow",
                        style: {
                          backgroundColor: `${effectiveMeta.accent || "#f59e0b"}28`,
                          color: effectiveMeta.border || "#fde047",
                          border: `1.5px solid ${effectiveMeta.border || "#fbbf24"}`
                        }
                      },
                      `💬 ${effectiveMeta.name}`
                    ),
                    h(
                      "span",
                      { className: "text-xs text-amber-200/80 font-semibold hidden sm:inline" },
                      effectiveMeta.title
                    )
                  ),
                  h(
                    "div",
                    { className: "flex flex-wrap items-center gap-1.5" },
                    // Paragraf Adım Düğmeleri
                    vnBeats.length > 1 &&
                      vnBeats.map((b, bIdx) =>
                        h(
                          "button",
                          {
                            key: bIdx,
                            onClick: () => {
                              window.PrinceTutu.Sound.play("click");
                              setManualSpeakerId(null);
                              setVnShowAllText(false);
                              setVnBeatIndex(bIdx);
                            },
                            className: `w-6 h-6 rounded-md text-[11px] font-extrabold transition-all ${
                              !vnShowAllText && vnBeatIndex === bIdx
                                ? "bg-amber-400 text-black shadow"
                                : "bg-stone-900 text-amber-200/75 border border-amber-500/30 hover:bg-stone-800"
                            }`
                          },
                          bIdx + 1
                        )
                      ),
                    h(
                      "button",
                      {
                        onClick: () => {
                          window.PrinceTutu.Sound.play("click");
                          setVnShowAllText(!vnShowAllText);
                        },
                        className: `px-2.5 py-1 rounded-lg text-[11px] font-bold border transition-all ${
                          vnShowAllText
                            ? "bg-amber-500 text-black border-yellow-200"
                            : "bg-stone-900 text-amber-200 border-amber-500/35 hover:bg-stone-800"
                        }`
                      },
                      vnShowAllText ? "🎭 Diyalog Modu" : "📜 Tüm Metin"
                    )
                  )
                ),

                // Ana Diyalog Alanı (Sol: Konuşan Karakter Portresi | Orta: Daktilo Metni)
                h(
                  "div",
                  {
                    onClick: !vnShowAllText ? handleAdvanceVN : undefined,
                    className: `flex flex-col sm:flex-row items-start gap-4 ${
                      !vnShowAllText ? "cursor-pointer" : ""
                    }`
                  },
                  CharacterPortraitSVG &&
                    h(
                      "div",
                      { className: "hidden sm:block shrink-0" },
                      h(CharacterPortraitSVG, {
                        charId: effectiveSpeakerId,
                        size: 86,
                        active: true
                      })
                    ),
                  h(
                    "div",
                    { className: "flex-1 min-w-0" },
                    vnShowAllText
                      ? h(
                          "div",
                          { className: "space-y-3 max-h-60 overflow-y-auto pr-1" },
                          vnBeats.map((b, i) =>
                            h(
                              "div",
                              { key: i, className: "p-2.5 rounded-xl bg-stone-950/80 border border-amber-500/20" },
                              h(
                                "div",
                                { className: "text-[11px] font-bold royal-font text-amber-300 mb-1" },
                                `${b.speakerName} (${b.speakerTitle}):`
                              ),
                              h("p", { className: "story-prose text-sm md:text-base leading-relaxed" }, b.text)
                            )
                          )
                        )
                      : h(
                          "div",
                          { className: "story-prose text-base md:text-lg leading-relaxed min-h-[84px]" },
                          (activeBeat.text || "").slice(0, vnTypedLen),
                          isTyping &&
                            h("span", { className: "inline-block w-2 h-4 ml-1 bg-amber-400 animate-pulse" })
                        )
                  )
                ),

                // Alt Görsel Roman İlerleme Çubuğu
                !vnShowAllText &&
                  h(
                    "div",
                    { className: "flex flex-wrap items-center justify-between gap-2 mt-3 pt-2.5 border-t border-white/10 text-xs" },
                    h(
                      "span",
                      { className: "text-[11px] text-amber-200/70" },
                      `📖 Sahne Diyaloğu ${vnBeatIndex + 1} / ${Math.max(1, vnBeats.length)} • Karakter portrelerine tıklayarak odaklanabilirsin`
                    ),
                    h(
                      "div",
                      { className: "flex items-center gap-2 ml-auto" },
                      vnBeatIndex > 0 &&
                        h(
                          "button",
                          {
                            onClick: () => {
                              window.PrinceTutu.Sound.play("click");
                              setManualSpeakerId(null);
                              setVnBeatIndex(vnBeatIndex - 1);
                            },
                            className:
                              "px-3 py-1.5 rounded-lg bg-stone-900 hover:bg-stone-800 border border-amber-500/30 text-amber-200 font-bold"
                          },
                          "◀ Önceki"
                        ),
                      ( isTyping || hasMoreBeats )
                        ? h(
                            "button",
                            {
                              onClick: handleAdvanceVN,
                              className:
                                "px-4 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black font-extrabold shadow-[0_0_15px_rgba(245,158,11,0.5)] animate-pulse"
                            },
                            isTyping
                              ? "⏩ Yazıyı Tamamla"
                              : `Sonraki Diyalog (${vnBeatIndex + 2}/${vnBeats.length}) ▸`
                          )
                        : h(
                            "span",
                            { className: "px-3 py-1 rounded-lg bg-emerald-950/90 border border-emerald-400/50 text-emerald-300 font-bold text-[11px]" },
                            "✓ Sahne Tamamlandı — Aşağıdan Kararını Seç"
                          )
                    )
                  )
              );

              return h(
                "div",
                { className: "rpg-panel rounded-2xl p-4 sm:p-6 min-h-[620px] flex flex-col justify-between" },
                h(
                  "div",
                  null,
                  // Bölüm İlerleme Çubuğu
                  h(
                    "div",
                    { className: "grid grid-cols-5 gap-1.5 mb-4" },
                    [
                      "I. Sabah Divanı",
                      "II. Gece Komplosu",
                      "III. Büyük İttifak",
                      "IV. Doğu Cephesi",
                      "V. Kader Gecesi"
                    ].map((label, i) => {
                      const chNum = i + 1;
                      const isCur = currentScene.chapter === chNum;
                      const isDone = currentScene.chapter > chNum;
                      return h(
                        "div",
                        {
                          key: chNum,
                          className: `py-1.5 px-2 rounded-lg text-[10px] font-bold text-center border royal-font ${
                            isCur
                              ? "bg-amber-500/25 border-amber-400 text-amber-200 shadow"
                              : isDone
                              ? "bg-emerald-950/60 border-emerald-500/40 text-emerald-300"
                              : "bg-stone-950/70 border-stone-800 text-stone-500"
                          }`
                        },
                        label
                      );
                    })
                  ),

                  // Sahne Başlığı
                  h(
                    "div",
                    { className: "flex flex-wrap items-center justify-between gap-2 border-b border-amber-500/25 pb-3 mb-4" },
                    h(
                      "div",
                      null,
                      h(
                        "span",
                        { className: "text-xs uppercase tracking-widest text-amber-400 font-bold" },
                        "Bölüm ",
                        currentScene.chapter,
                        " • ",
                        currentScene.location
                      ),
                      h(
                        "h2",
                        { className: "text-xl md:text-2xl font-bold royal-font text-amber-300 mt-0.5" },
                        currentScene.title
                      )
                    ),
                    h(
                      "div",
                      { className: "flex items-center gap-2" },
                      currentScene.endingBadge &&
                        h(
                          "span",
                          {
                            className: `px-3 py-1 border text-xs font-bold rounded-full ${
                              currentScene.isVictory === false
                                ? "bg-red-500/20 border-red-400 text-red-300"
                                : "bg-amber-500/20 border-amber-400 text-amber-300"
                            }`
                          },
                          currentScene.endingBadge
                        ),
                      h(
                        "button",
                        {
                          onClick: () => setVnCinemaMode(!vnCinemaMode),
                          className:
                            "px-2.5 py-1 rpg-card rounded-lg text-xs text-amber-200 font-semibold"
                        },
                        vnCinemaMode ? "📐 Yan Panelleri Göster" : "🎬 Tam Ekran Sahne"
                      ),
                      h(
                        "button",
                        {
                          onClick: () => setShowStoryArt(!showStoryArt),
                          className:
                            "px-2.5 py-1 rpg-card rounded-lg text-xs text-amber-300 font-semibold"
                        },
                        showStoryArt ? "🎨 Sahneyi Küçült" : "🎨 Sahneyi Aç"
                      )
                    )
                  ),

                  // TAM EKRAN BOYALI GÖRSEL ROMAN SAHNESİ + ENTEGRE DİYALOG KUTUSU
                  showStoryArt && Story2DStage
                    ? h(
                        Story2DStage,
                        {
                          sceneKey: gameState.scene,
                          scene: currentScene,
                          chapter: gameState.chapter,
                          gameState,
                          activeSpeakerId: effectiveSpeakerId,
                          onSelectSpeaker: (cId) => setManualSpeakerId(cId)
                        },
                        vnDialogueBox
                      )
                    : h("div", { className: "mb-5" }, vnDialogueBox)
                ),

              currentScene.isEnding
                ? h(
                    "div",
                    {
                      className: `p-6 border rounded-2xl text-center ${
                        currentScene.isVictory === false
                          ? "bg-gradient-to-r from-red-950/80 via-stone-900 to-black border-red-500/60"
                          : "bg-gradient-to-r from-amber-950/75 via-stone-900 to-black border-amber-500/60"
                      }`
                    },
                    h(
                      "h3",
                      { className: "text-xl font-bold royal-font text-amber-300 mb-2" },
                      currentScene.isVictory === false
                        ? "Saltanatın Trajik Sonu"
                        : "İmparatorluk Tarihi Altın Harflerle Yazıldı!"
                    ),
                    h(
                      "div",
                      {
                        className:
                          "inline-block px-4 py-1.5 bg-amber-500/20 border border-amber-400/50 rounded-full text-sm font-extrabold text-amber-200 mb-4"
                      },
                      "🏆 İmparatorluk Miras Puanı: ",
                      legacyScore,
                      " (",
                      legacyScore >= 1800
                        ? "S+ Efsanevi Hükümdar"
                        : legacyScore >= 1400
                        ? "A+ Büyük İmparator"
                        : "B+ Muzaffer Prens",
                      ")"
                    ),
                    h(
                      "div",
                      { className: "grid grid-cols-2 sm:grid-cols-4 gap-2 mb-5 text-xs" },
                      h(
                        "div",
                        { className: "p-2.5 bg-stone-950/80 rounded-xl border border-amber-500/20" },
                        h("div", { className: "text-amber-200/70" }, "Geçen Süre"),
                        h("div", { className: "text-sm font-bold text-white" }, gameState.turn, " Tur")
                      ),
                      h(
                        "div",
                        { className: "p-2.5 bg-stone-950/80 rounded-xl border border-amber-500/20" },
                        h("div", { className: "text-amber-200/70" }, "Kıta Hakimiyeti"),
                        h(
                          "div",
                          { className: "text-sm font-bold text-amber-400" },
                          totalPlayerProvs,
                          " / ",
                          totalProvincesCount
                        )
                      ),
                      h(
                        "div",
                        { className: "p-2.5 bg-stone-950/80 rounded-xl border border-amber-500/20" },
                        h("div", { className: "text-amber-200/70" }, "Toplam Ordu"),
                        h("div", { className: "text-sm font-bold text-emerald-400" }, totalBattalions, " Tabur")
                      ),
                      h(
                        "div",
                        { className: "p-2.5 bg-stone-950/80 rounded-xl border border-amber-500/20" },
                        h("div", { className: "text-amber-200/70" }, "Başarımlar"),
                        h(
                          "div",
                          { className: "text-sm font-bold text-yellow-400" },
                          (gameState.unlockedAchievements || []).length,
                          " / 12"
                        )
                      )
                    ),
                    h(
                      "button",
                      {
                        onClick: handleNewGame,
                        className:
                          "px-6 py-3 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black font-bold rounded-xl text-sm shadow-lg"
                      },
                      "🔄 Yeni Saltanat Başlat"
                    )
                  )
                : h(
                    "div",
                    { className: "space-y-3" },
                    h(
                      "div",
                      { className: "flex flex-wrap justify-between items-center gap-2" },
                      h(
                        "h4",
                        { className: "text-xs font-bold uppercase tracking-wider text-amber-400 royal-font" },
                        "Hükümdar Kararın Nedir? (Klavye 1-",
                        currentScene.choices.length,
                        " Kısayolu Aktif)"
                      ),
                      h(
                        "span",
                        { className: "text-[11px] text-amber-200/70" },
                        "💡 Karar öncesi [W] Dünya Atlası (",
                        gameState.actionPoints,
                        " AP) veya [E] Saray sekmesini kullanabilirsin."
                      )
                    ),
                    currentScene.choices.map((ch, idx) => {
                      const check = checkChoice(ch);
                      return h(
                        "button",
                        {
                          key: idx,
                          onClick: () => handleStoryChoice(ch),
                          disabled: !check.ok,
                          className: `w-full text-left p-4 rounded-xl border transition-all ${
                            check.ok
                              ? "rpg-card hover:bg-amber-950/40 hover:border-amber-400 hover:translate-x-1"
                              : "bg-stone-950/40 border-stone-800 opacity-50 cursor-not-allowed"
                          }`
                        },
                        h(
                          "div",
                          { className: "flex flex-wrap justify-between items-center gap-2 mb-1" },
                          h(
                            "span",
                            { className: "font-bold text-sm text-amber-50" },
                            h(
                              "span",
                              {
                                className:
                                  "inline-block px-2 py-0.5 mr-2 bg-amber-500/20 border border-amber-400/50 rounded text-[11px] text-amber-300 font-extrabold"
                              },
                              idx + 1
                            ),
                            ch.text
                          ),
                          h(
                            "div",
                            { className: "flex items-center gap-1.5" },
                            ch.goldCost &&
                              h(
                                "span",
                                {
                                  className:
                                    "px-2 py-0.5 bg-yellow-500/20 text-yellow-300 rounded text-xs font-semibold"
                                },
                                "💰 ",
                                ch.goldCost,
                                " Altın"
                              ),
                            ch.requiresItem &&
                              h(
                                "span",
                                {
                                  className:
                                    "px-2 py-0.5 bg-purple-500/20 text-purple-300 rounded text-xs font-semibold"
                                },
                                "📦 ",
                                ch.requiresItem
                              ),
                            !check.ok &&
                              h(
                                "span",
                                {
                                  className:
                                    "px-2 py-0.5 bg-red-500/20 text-red-300 rounded text-xs font-semibold"
                                },
                                "🔒 ",
                                check.reason
                              )
                          )
                        ),
                        h("div", { className: "text-xs text-amber-300/90 italic pl-7" }, ch.consequence)
                      );
                    })
                  )
              );
            })(),

          // TAB 2: 18 EYALETLİ BÜYÜK DÜNYA ATLASI (GrandMap2D)
          activeTab === "map" &&
            h(
              "div",
              { className: "rpg-panel rounded-2xl p-5 space-y-4" },
              h(
                "div",
                { className: "flex flex-wrap justify-between items-center gap-2" },
                h(
                  "div",
                  null,
                  h(
                    "h2",
                    { className: "text-xl font-bold royal-font text-amber-300" },
                    "🗺️ Büyük Dünya Atlası (18 Eyaletli Jeopolitik Kıta)"
                  ),
                  h(
                    "p",
                    { className: "text-xs text-amber-200/75" },
                    "İkmal hatlarını koru, düşman eyaletlerini ablukaya al ve sınır kalelerini aşarak başkentleri fethet! Kalan Emir Hakkı: ",
                    h("strong", { className: "text-amber-300" }, gameState.actionPoints, " AP")
                  )
                ),
                h(
                  "span",
                  {
                    className:
                      "px-3 py-1 bg-blue-950/80 border border-blue-400/40 rounded-xl text-xs font-bold text-blue-200"
                  },
                  "Hakimiyet: ",
                  totalPlayerProvs,
                  " / ",
                  totalProvincesCount,
                  " Eyalet"
                )
              ),

              GrandMap2D &&
                h(GrandMap2D, {
                  provinces: gameState.provinces,
                  selectedProvince,
                  onSelectProvince: (id) => setSelectedProvince(id),
                  gameState
                }),

              // 18 Eyalet Hızlı Seçim Çubuğu
              h(
                "div",
                { className: "flex flex-wrap gap-1.5" },
                Object.values(gameState.provinces).map((p) =>
                  h(
                    "button",
                    {
                      key: p.id,
                      onClick: () => {
                        window.PrinceTutu.Sound.play("click");
                        setSelectedProvince(p.id);
                      },
                      className: `px-2.5 py-1 rounded-lg text-[11px] font-bold border transition-all ${
                        selectedProvince === p.id
                          ? "bg-amber-500 text-black border-yellow-200 shadow"
                          : "rpg-card text-amber-100/90 hover:bg-stone-800"
                      }`
                    },
                    p.isCapital ? "👑 " : "",
                    p.name,
                    " (🛡️",
                    p.garrison,
                    p.isBlockaded ? " ⛓️" : "",
                    ")"
                  )
                )
              ),

              // Seçili Eyalet Detay ve Stratejik Emir Paneli
              activeProv &&
                h(
                  "div",
                  { className: "p-4 rpg-card rounded-xl space-y-3" },
                  h(
                    "div",
                    { className: "flex flex-wrap justify-between items-center gap-2" },
                    h(
                      "div",
                      null,
                      h(
                        "div",
                        { className: "flex items-center gap-2" },
                        h("h3", { className: "text-lg font-bold royal-font text-amber-300" }, activeProv.name),
                        activeProv.isCapital &&
                          h(
                            "span",
                            {
                              className:
                                "px-2 py-0.5 bg-amber-500/20 border border-amber-400 text-amber-200 text-[10px] font-bold rounded"
                            },
                            "👑 Krallık Başkenti"
                          ),
                        activeProv.isBlockaded
                          ? h(
                              "span",
                              {
                                className:
                                  "px-2 py-0.5 bg-red-900/80 border border-red-400 text-red-200 text-[10px] font-bold rounded"
                              },
                              "⛓️ ABLUKADA (-2🛡️/Tur, 0💰)"
                            )
                          : h(
                              "span",
                              {
                                className:
                                  "px-2 py-0.5 bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-[10px] font-bold rounded"
                              },
                              "🟢 İkmal Hattı Açık"
                            )
                      ),
                      h(
                        "span",
                        { className: "text-[11px] text-amber-200/80 font-semibold" },
                        activeProv.realm,
                        " • Kaynak: ",
                        activeProv.resource,
                        " • Tahkimat Sv.",
                        activeProv.fortLevel || 1
                      )
                    ),
                    h(
                      "span",
                      { className: `px-3 py-1 rounded-full text-xs font-bold ${getOwnerBadge(activeProv.owner).cls}` },
                      getOwnerBadge(activeProv.owner).text
                    )
                  ),

                  h("p", { className: "text-xs text-amber-100/85" }, activeProv.description),
                  h("p", { className: "text-[11px] text-amber-300 font-semibold" }, "⭐ ", activeProv.perk),

                  h(
                    "div",
                    { className: "grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs text-center" },
                    h(
                      "div",
                      { className: "p-2 bg-stone-950/90 rounded-lg border border-amber-500/20" },
                      "🛡️ Garnizon: ",
                      h("strong", null, activeProv.garrison, " Tabur")
                    ),
                    h(
                      "div",
                      { className: "p-2 bg-stone-950/90 rounded-lg border border-amber-500/20" },
                      "🏰 Savunma: ",
                      h("strong", null, "+", activeProv.defenseBonus)
                    ),
                    h(
                      "div",
                      { className: "p-2 bg-stone-950/90 rounded-lg border border-amber-500/20" },
                      "💰 Vergi: ",
                      h(
                        "strong",
                        { className: activeProv.isBlockaded ? "text-red-400" : "text-yellow-400" },
                        activeProv.isBlockaded ? "0 (Abluka)" : `+${activeProv.taxIncome}/Tur`
                      )
                    ),
                    h(
                      "div",
                      { className: "p-2 bg-stone-950/90 rounded-lg border border-amber-500/20" },
                      "🔥 İsyan Riski: ",
                      h("strong", null, "%", activeProv.unrest)
                    )
                  ),

                  // Eyalet Sahibine Göre Aksiyon Butonları
                  h(
                    "div",
                    { className: "grid sm:grid-cols-2 gap-2 pt-1" },
                    activeProv.owner === "player" &&
                      h(
                        React.Fragment,
                        null,
                        h(
                          "button",
                          {
                            onClick: () => {
                              const res = window.PrinceTutu.executeProvinceAction(
                                gameState,
                                activeProv.id,
                                "recruit_garrison"
                              );
                              setGameState(res.state);
                              setBannerMsg(res.message);
                            },
                            className:
                              "p-2.5 bg-blue-800 hover:bg-blue-700 border border-blue-400/40 rounded-lg text-xs font-bold text-left"
                          },
                          "🛡️ +3 Garnizon & +2 Saha Piyadesi (35 Altın, 1 AP)"
                        ),
                        h(
                          "button",
                          {
                            onClick: () => {
                              const res = window.PrinceTutu.executeProvinceAction(
                                gameState,
                                activeProv.id,
                                "pacify_unrest"
                              );
                              setGameState(res.state);
                              setBannerMsg(res.message);
                            },
                            className:
                              "p-2.5 bg-emerald-800 hover:bg-emerald-700 border border-emerald-400/40 rounded-lg text-xs font-bold text-left"
                          },
                          "🌾 Erzak Dağıt (-25% İsyan, +6 Vergi | 25 Altın, 1 AP)"
                        ),
                        h(
                          "button",
                          {
                            onClick: () => {
                              const res = window.PrinceTutu.executeProvinceAction(
                                gameState,
                                activeProv.id,
                                "upgrade_infrastructure"
                              );
                              setGameState(res.state);
                              setBannerMsg(res.message);
                            },
                            className:
                              "p-2.5 bg-amber-600 hover:bg-amber-500 text-black rounded-lg text-xs font-bold text-left"
                          },
                          "🏗️ Kale & Lonca Yatırımı (+12💰/Tur, +1🏰, +1🛡️ | 45 Altın, 1 AP)"
                        ),
                        h(
                          "button",
                          {
                            onClick: () => {
                              const res = window.PrinceTutu.executeProvinceAction(
                                gameState,
                                activeProv.id,
                                "counter_espionage"
                              );
                              setGameState(res.state);
                              setBannerMsg(res.message);
                            },
                            className:
                              "p-2.5 bg-indigo-800 hover:bg-indigo-700 border border-indigo-400/40 rounded-lg text-xs font-bold text-left"
                          },
                          "🕵️ Karşı-İstihbarat Taraması (Darbe -12%, +4 Zeka | 20 Altın, 1 AP)"
                        )
                      ),

                    (activeProv.owner === "furry" ||
                      activeProv.owner === "doxe" ||
                      activeProv.owner === "tribes") &&
                      h(
                        React.Fragment,
                        null,
                        h(
                          "button",
                          {
                            onClick: () => {
                              const res = window.PrinceTutu.executeProvinceAction(
                                gameState,
                                activeProv.id,
                                "diplomatic_envoy"
                              );
                              setGameState(res.state);
                              setBannerMsg(res.message);
                            },
                            className:
                              "p-2.5 bg-indigo-700 hover:bg-indigo-600 border border-indigo-400/40 rounded-lg text-xs font-bold text-left"
                          },
                          "🤝 Müttefik Elçisi Gönder (+15 İlişki & Özel Birim | 30 Altın, 1 AP)"
                        ),
                        h(
                          "button",
                          {
                            onClick: () => {
                              const res = window.PrinceTutu.executeProvinceAction(
                                gameState,
                                activeProv.id,
                                "trade_caravan"
                              );
                              setGameState(res.state);
                              setBannerMsg(res.message);
                            },
                            className:
                              "p-2.5 bg-emerald-700 hover:bg-emerald-600 border border-emerald-400/40 rounded-lg text-xs font-bold text-left"
                          },
                          "🚢 Kraliyet Ticaret Kervanı Gönder (+",
                          activeProv.owner === "furry" ? 65 : 50,
                          " Altın Net Kâr! | 1 AP)"
                        )
                      ),

                    (activeProv.owner === "vampire" || activeProv.owner === "brothers") &&
                      h(
                        React.Fragment,
                        null,
                        h(
                          "button",
                          {
                            onClick: () => {
                              const res = window.PrinceTutu.executeProvinceAction(
                                gameState,
                                activeProv.id,
                                "spy_sabotage"
                              );
                              setGameState(res.state);
                              setBannerMsg(res.message);
                            },
                            className:
                              "p-2.5 bg-purple-800 hover:bg-purple-700 border border-purple-400/40 rounded-lg text-xs font-bold text-left"
                          },
                          "🕵️ Düşman Garnizonunu Sabote Et (-3 Tabur | ",
                          gameState.flags.hasSpyNetwork ? 15 : 40,
                          " Altın, 1 AP)"
                        ),
                        h(
                          "button",
                          {
                            onClick: () => {
                              const res = window.PrinceTutu.executeProvinceAction(
                                gameState,
                                activeProv.id,
                                "blockade_supply"
                              );
                              setGameState(res.state);
                              setBannerMsg(res.message);
                            },
                            className:
                              "p-2.5 bg-amber-800 hover:bg-amber-700 border border-amber-400/40 rounded-lg text-xs font-bold text-left"
                          },
                          "⛓️ İkmal Hattını Kes & Ablukaya Al (-2🛡️/Tur & 0 Vergi | 30 Altın, 1 AP)"
                        ),
                        h(
                          "button",
                          {
                            onClick: () => {
                              const res = window.PrinceTutu.executeProvinceAction(
                                gameState,
                                activeProv.id,
                                "incite_rebellion"
                              );
                              setGameState(res.state);
                              setBannerMsg(res.message);
                            },
                            className:
                              "p-2.5 bg-orange-700 hover:bg-orange-600 border border-orange-400/40 rounded-lg text-xs font-bold text-left sm:col-span-2"
                          },
                          "🔥 Direniş Ayaklanması Çıkar (-4 Düşman Taburu, +1 Özgür Piyade | 35 Altın, 1 AP)"
                        ),
                        h(
                          "button",
                          {
                            onClick: () => handleStartMapCampaign(activeProv.id),
                            className: `sm:col-span-2 p-3 rounded-xl text-xs font-extrabold text-center shadow-lg border ${
                              campaignCheck.ok
                                ? "bg-gradient-to-r from-red-700 to-rose-600 hover:from-red-600 hover:to-rose-500 border-red-400 text-white"
                                : "bg-stone-900 border-red-500/40 text-red-300 opacity-80"
                            }`
                          },
                          campaignCheck.ok
                            ? `⚔️ ${activeProv.name} Üzerine 2D Meydan Muharebesi Seferi Düzenle! (1 AP)`
                            : `🔒 ${campaignCheck.reason}`
                        )
                      )
                  )
                )
            ),

          // TAB 3: KRALİYET DİVANI, HANEDAN & SARAY DEMİRHANESİ
          activeTab === "court" &&
            h(
              "div",
              { className: "rpg-panel rounded-2xl p-6 space-y-6" },
              h(
                "div",
                { className: "relative rounded-2xl overflow-hidden border border-amber-500/40 p-5" },
                h("img", {
                  src: "./assets/bg_throne.jpg",
                  alt: "Kraliyet Divanı",
                  className: "absolute inset-0 w-full h-full object-cover opacity-45"
                }),
                h("div", {
                  className: "absolute inset-0 bg-gradient-to-r from-black/90 via-black/70 to-black/85"
                }),
                h(
                  "div",
                  { className: "relative z-10" },
                  h(
                    "h2",
                    { className: "text-xl font-bold royal-font text-amber-300" },
                    "🏯 Kraliyet Divanı, Hanedan & Saray Demirhanesi"
                  ),
                  h(
                    "p",
                    { className: "text-xs text-amber-100/85 mt-1" },
                    "Kız kardeşlerinle ilgilenerek saray komplolarını bozabilir, Kraliyet Demirhanesi'nde AP harcamadan efsanevi silahlar ve topçu bataryaları üretebilirsin."
                  )
                )
              ),
              h(
                "div",
                { className: "space-y-3" },
                h(
                  "h3",
                  { className: "text-xs font-bold uppercase tracking-wider text-pink-400 royal-font" },
                  "👑 Hanedan & Saray Etkileşimleri"
                ),
                h(
                  "div",
                  { className: "grid sm:grid-cols-2 gap-3" },
                  h(
                    "div",
                    { className: "p-4 rpg-card rounded-xl flex flex-col justify-between" },
                    h(
                      "div",
                      { className: "flex items-start gap-3 mb-2" },
                      CharacterPortraitSVG && h(CharacterPortraitSVG, { charId: "sisters", size: 58, active: true }),
                      h(
                        "div",
                        null,
                        h("div", { className: "font-bold text-sm text-white mb-1" }, "👧 Kız Kardeşleri (9 ve 13) Ziyaret Et"),
                        h(
                          "p",
                          { className: "text-xs text-amber-100/80 mb-2" },
                          "Küçük kız kardeşlerinle vakit geçir ve muhafızlarını güçlendir. Sarayın gizli koridorlarında duydukları komployu sana fısıldarlar!"
                        ),
                        h(
                          "div",
                          { className: "text-[11px] text-emerald-400 font-semibold" },
                          "✨ 0 AP (Ücretsiz Emir!) • 15 Altın • +10 İlişki, +6 Ahlak, Darbe -10%"
                        )
                      )
                    ),
                    h(
                      "button",
                      {
                        disabled: gameState.flags.visitedSistersThisTurn,
                        onClick: () => {
                          const res = window.PrinceTutu.executeCourtAction(gameState, "visit_sisters");
                          setGameState(res.state);
                          setBannerMsg(res.message);
                        },
                        className: `w-full py-2 rounded-lg text-xs font-bold ${
                          gameState.flags.visitedSistersThisTurn
                            ? "bg-stone-800 text-stone-500"
                            : "bg-pink-700 hover:bg-pink-600 text-white"
                        }`
                      },
                      gameState.flags.visitedSistersThisTurn
                        ? "Bu Tur Ziyaret Edildi ✓"
                        : "👧 Kardeşlerini Ziyaret Et (15 Altın, 0 AP)"
                    )
                  ),
                  h(
                    "div",
                    { className: "p-4 rpg-card rounded-xl flex flex-col justify-between" },
                    h(
                      "div",
                      { className: "flex items-start gap-3 mb-2" },
                      CharacterPortraitSVG && h(CharacterPortraitSVG, { charId: "lalo", size: 58, active: true }),
                      h(
                        "div",
                        null,
                        h("div", { className: "font-bold text-sm text-white mb-1" }, "👑 İmparator Lalo ile Hünkar İstişaresi"),
                        h(
                          "p",
                          { className: "text-xs text-amber-100/80 mb-2" },
                          "Baban İmparator Lalo'nun hayır duasını ve resmi vasiyet desteğini alarak soylular üzerindeki otoriteni perçinle."
                        ),
                        h(
                          "div",
                          { className: "text-[11px] text-emerald-400 font-semibold" },
                          "✨ 1 AP • Ücretsiz • +12 Baba, +8 Politik Güç, +6 Karizma"
                        )
                      )
                    ),
                    h(
                      "button",
                      {
                        disabled: gameState.chapter >= 5,
                        onClick: () => {
                          const res = window.PrinceTutu.executeCourtAction(gameState, "consult_emperor");
                          setGameState(res.state);
                          setBannerMsg(res.message);
                        },
                        className:
                          "w-full py-2 bg-amber-500 hover:bg-amber-400 text-black rounded-lg text-xs font-bold"
                      },
                      "👑 Hünkar ile Görüş (1 AP)"
                    )
                  ),
                  h(
                    "div",
                    { className: "p-4 rpg-card rounded-xl flex flex-col justify-between" },
                    h(
                      "div",
                      { className: "flex items-start gap-3 mb-2" },
                      CharacterPortraitSVG && h(CharacterPortraitSVG, { charId: "tutu", size: 58, active: true }),
                      h(
                        "div",
                        null,
                        h("div", { className: "font-bold text-sm text-white mb-1" }, "🎪 Başkentte Büyük Şafak Şöleni"),
                        h(
                          "p",
                          { className: "text-xs text-amber-100/80 mb-2" },
                          "Halk ve loncalar için büyük bir turnuva ve erzak şöleni düzenle. Tüm eyaletlerdeki isyan ateşini söndürür!"
                        ),
                        h(
                          "div",
                          { className: "text-[11px] text-emerald-400 font-semibold" },
                          "✨ 1 AP • 50 Altın • +15 Halk Desteği, +8 Karizma, Tüm Eyaletlerde -20% İsyan"
                        )
                      )
                    ),
                    h(
                      "button",
                      {
                        onClick: () => {
                          const res = window.PrinceTutu.executeCourtAction(gameState, "grand_festival");
                          setGameState(res.state);
                          setBannerMsg(res.message);
                        },
                        className:
                          "w-full py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-xs font-bold"
                      },
                      "🎪 Şölen Düzenle (50 Altın, 1 AP)"
                    )
                  ),
                  h(
                    "div",
                    { className: "p-4 rpg-card rounded-xl flex flex-col justify-between" },
                    h(
                      "div",
                      { className: "flex items-start gap-3 mb-2" },
                      CharacterPortraitSVG && h(CharacterPortraitSVG, { charId: "anzak", size: 58, active: true }),
                      h(
                        "div",
                        null,
                        h("div", { className: "font-bold text-sm text-white mb-1" }, "🗡️ Ağabey Anzak'a Meydan Oku!"),
                        h(
                          "p",
                          { className: "text-xs text-amber-100/80 mb-2" },
                          "Darbe komplosunu beklemek yerine Anzak'ı komutanların önünde 2D Yan Profil Kraliyet Düellosuna davet et!"
                        ),
                        h(
                          "div",
                          { className: "text-[11px] text-amber-300 font-semibold" },
                          "✨ 0 AP • Kazanırsan Darbe Planı %0'a İner ve Güney Eyaletleri Sana Katılır!"
                        )
                      )
                    ),
                    h(
                      "button",
                      {
                        disabled: gameState.flags.anzakDefeated,
                        onClick: () => {
                          window.PrinceTutu.Sound.play("sword");
                          setDuelState(window.PrinceTutu.CombatEngine.createDuelState(gameState, "anzak"));
                        },
                        className: `w-full py-2 rounded-lg text-xs font-bold ${
                          gameState.flags.anzakDefeated
                            ? "bg-stone-800 text-stone-500"
                            : "bg-red-700 hover:bg-red-600 text-white"
                        }`
                      },
                      gameState.flags.anzakDefeated ? "Anzak Mağlup Edildi ✓" : "⚔️ Anzak ile 2D Düelloya Gir!"
                    )
                  )
                )
              ),
              h(
                "div",
                { className: "space-y-3 pt-3 border-t border-amber-500/20" },
                h(
                  "h3",
                  { className: "text-xs font-bold uppercase tracking-wider text-amber-400 royal-font" },
                  "⚒️ Kraliyet Demirhanesi ve Mühendislik Atölyesi (AP Harcamaz!)"
                ),
                h(
                  "div",
                  { className: "grid sm:grid-cols-3 gap-3" },
                  [
                    {
                      id: "forge_moonlight_sword",
                      itemId: "moonlight_sword",
                      title: "🗡️ Ayışığı Kraliyet Kılıcı",
                      cost: 65,
                      desc: "Kuzey mitrili ile dövülmüş parlak mavi kılıç. 2D Düellolarda +14 Efsanevi Hasar ve +8 Askeri Destek sağlar."
                    },
                    {
                      id: "forge_furry_cannons",
                      itemId: "furry_cannons",
                      title: "💣 Furry Barut Topçu Bataryası",
                      cost: 60,
                      desc: "3v2 Muharebelerde 'Topçu Bombardımanı' yeteneğini açar (Düşman -3 Tabur & Zar Sersemletme) + 1 Furry Okçusu."
                    },
                    {
                      id: "forge_doxe_aegis",
                      itemId: "doxe_aegis",
                      title: "🛡️ DOXE Kutsal Kalkanı",
                      cost: 55,
                      desc: "2D Düelloda +20 Maksimum Can, ekstra Stamina yenilenmesi ve saha orduna +1 DOXE Paladin Taburu kazandırır."
                    }
                  ].map((craft) => {
                    const owned = gameState.inventory.items.some((i) => i.id === craft.itemId);
                    return h(
                      "div",
                      {
                        key: craft.id,
                        className: "p-3.5 rpg-card rounded-xl flex flex-col justify-between"
                      },
                      h(
                        "div",
                        null,
                        h("div", { className: "font-bold text-xs text-amber-300 mb-1" }, craft.title),
                        h("p", { className: "text-[11px] text-amber-100/80 mb-3" }, craft.desc)
                      ),
                      h(
                        "button",
                        {
                          disabled: owned,
                          onClick: () => {
                            const res = window.PrinceTutu.executeCourtAction(gameState, craft.id);
                            setGameState(res.state);
                            setBannerMsg(res.message);
                          },
                          className: `w-full py-2 rounded-lg text-xs font-bold ${
                            owned
                              ? "bg-emerald-950 text-emerald-300 border border-emerald-500/40"
                              : "bg-amber-500 hover:bg-amber-400 text-black"
                          }`
                        },
                        owned ? "Envanterde Aktif ✓" : `⚒️ Üret (${craft.cost} Altın)`
                      )
                    );
                  })
                )
              )
            ),

          // TAB 4: İMPARATORLUK FERMANLARI (10 FERMAN)
          activeTab === "decrees" &&
            h(
              "div",
              { className: "rpg-panel rounded-2xl p-6 space-y-4" },
              h(
                "h2",
                { className: "text-xl font-bold royal-font text-amber-300" },
                "📜 İmparatorluk Fermanları ve Reform Divanı (10 Ferman)"
              ),
              h(
                "p",
                { className: "text-xs text-amber-200/75" },
                "İlan ettiğin fermanlar hem orduna yeni elit taburlar ekler hem de AP kapasiteni ve savunmanı güçlendirir."
              ),
              h(
                "div",
                { className: "space-y-3" },
                window.PrinceTutu.DECREES_DATA.map((dec) => {
                  const enacted = gameState.decrees[dec.id];
                  return h(
                    "div",
                    {
                      key: dec.id,
                      className:
                        "p-4 rpg-card rounded-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4"
                    },
                    h(
                      "div",
                      null,
                      h(
                        "div",
                        { className: "flex flex-wrap items-center gap-2" },
                        h("span", { className: "font-bold text-sm text-amber-200" }, dec.title),
                        dec.reqStat &&
                          h(
                            "span",
                            {
                              className:
                                "px-2 py-0.5 bg-indigo-950 border border-indigo-500/40 text-indigo-300 rounded text-[11px]"
                            },
                            "Gereksinim: ",
                            dec.reqStat.label
                          )
                      ),
                      h("p", { className: "text-xs text-amber-100/80 my-1" }, dec.description),
                      h("div", { className: "text-[11px] text-emerald-400 font-semibold" }, "✨ Etki: ", dec.effectLabel)
                    ),
                    h(
                      "button",
                      {
                        disabled: enacted,
                        onClick: () => handleEnactDecree(dec),
                        className: `px-4 py-2.5 rounded-xl text-xs font-bold shrink-0 ${
                          enacted
                            ? "bg-emerald-950/70 text-emerald-300 border border-emerald-500/40"
                            : "bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black"
                        }`
                      },
                      enacted
                        ? "Yürürlükte ✓"
                        : dec.costGold > 0
                        ? `Mühürle (${dec.costGold} Altın)`
                        : "Mühürle (Ücretsiz)"
                    )
                  );
                })
              )
            ),

          // TAB 5: BAŞARIMLAR, KAYIT DEFTERİ VE LORE CODEX
          activeTab === "codex" &&
            h(
              "div",
              { className: "rpg-panel rounded-2xl p-6 space-y-6" },
              h(
                "div",
                null,
                h(
                  "h2",
                  { className: "text-lg font-bold royal-font text-amber-300 mb-2" },
                  "💾 İmparatorluk Kayıt Defteri (3 Kayıt Yuvası • Hızlı Kayıt: Ctrl+S)"
                ),
                h(
                  "div",
                  { className: "grid sm:grid-cols-3 gap-3" },
                  saveSlots.map((s) =>
                    h(
                      "div",
                      {
                        key: s.slot,
                        className: "p-3.5 rpg-card rounded-xl flex flex-col justify-between"
                      },
                      h(
                        "div",
                        null,
                        h(
                          "div",
                          { className: "flex justify-between items-center text-xs font-bold text-amber-300 mb-1" },
                          h("span", null, "Kayıt Yuvası #", s.slot),
                          s.slot === 1 &&
                            h(
                              "span",
                              { className: "text-[10px] px-1.5 py-0.5 bg-amber-950 text-amber-300 rounded" },
                              "Oto-Kayıt"
                            )
                        ),
                        s.empty
                          ? h("p", { className: "text-xs text-stone-500 my-2" }, "Boş Kayıt Yuvası")
                          : h(
                              "div",
                              { className: "text-[11px] text-amber-100/80 space-y-0.5 my-1.5" },
                              h("div", { className: "font-semibold text-white truncate" }, s.sceneTitle),
                              h("div", null, "Tur ", s.turn, " • Bölüm ", s.chapter, "/5 • 💰 ", s.gold),
                              h("div", { className: "text-yellow-400" }, "🏆 Miras: ", s.score, " Puan")
                            )
                      ),
                      h(
                        "div",
                        { className: "flex gap-1.5 mt-2" },
                        h(
                          "button",
                          {
                            onClick: () => handleSaveGame(s.slot),
                            className:
                              "flex-1 py-1.5 bg-emerald-700 hover:bg-emerald-600 rounded text-[11px] font-bold text-white"
                          },
                          "💾 Kaydet"
                        ),
                        h(
                          "button",
                          {
                            disabled: s.empty,
                            onClick: () => handleLoadGame(s.slot),
                            className: `flex-1 py-1.5 rounded text-[11px] font-bold ${
                              s.empty
                                ? "bg-stone-800 text-stone-500"
                                : "bg-amber-600 hover:bg-amber-500 text-black"
                            }`
                          },
                          "📂 Yükle"
                        )
                      )
                    )
                  )
                )
              ),
              h(
                "div",
                { className: "pt-3 border-t border-amber-500/20" },
                h(
                  "div",
                  { className: "flex justify-between items-center mb-3" },
                  h(
                    "h2",
                    { className: "text-lg font-bold royal-font text-amber-300" },
                    "🏆 İmparatorluk Başarımları (",
                    (gameState.unlockedAchievements || []).length,
                    " / 12)"
                  ),
                  h("span", { className: "text-xs text-amber-300 font-bold" }, "+100 Miras Puanı / Başarım")
                ),
                h(
                  "div",
                  { className: "grid sm:grid-cols-2 gap-2.5" },
                  window.PrinceTutu.ACHIEVEMENTS_DATA.map((ach) => {
                    const isUnlocked = (gameState.unlockedAchievements || []).includes(ach.id);
                    return h(
                      "div",
                      {
                        key: ach.id,
                        className: `p-3 rounded-xl border transition-all ${
                          isUnlocked
                            ? "bg-amber-950/45 border-amber-400 text-white"
                            : "bg-stone-950/60 border-stone-800 text-stone-500"
                        }`
                      },
                      h(
                        "div",
                        { className: "flex justify-between items-center mb-0.5" },
                        h(
                          "span",
                          { className: `text-xs font-bold ${isUnlocked ? "text-amber-300" : "text-stone-400"}` },
                          ach.title
                        ),
                        h(
                          "span",
                          { className: "text-[10px] font-bold px-2 py-0.5 rounded bg-stone-950" },
                          isUnlocked ? "Kazanıldı ✓" : "Kilitli"
                        )
                      ),
                      h("p", { className: "text-[11px]" }, ach.desc)
                    );
                  })
                )
              ),
              h(
                "div",
                { className: "pt-3 border-t border-amber-500/20 space-y-3" },
                h(
                  "h2",
                  { className: "text-lg font-bold royal-font text-amber-300" },
                  "📚 İmparatorluk Arşivleri ve Taktik Rehberi"
                ),
                window.PrinceTutu.LORE_CODEX.map((entry, idx) =>
                  h(
                    "div",
                    { key: idx, className: "p-4 rpg-card rounded-xl" },
                    h(
                      "div",
                      { className: "flex justify-between items-center mb-1" },
                      h("span", { className: "font-bold text-amber-300 text-sm royal-font" }, entry.title),
                      h(
                        "span",
                        { className: "text-[11px] px-2 py-0.5 bg-stone-900 rounded text-amber-200" },
                        entry.category
                      )
                    ),
                    h("p", { className: "text-xs text-amber-100/80 leading-relaxed" }, entry.text)
                  )
                )
              )
            )
        ),

        // SAĞ SÜTUN: HANEDAN PORTRELERİ, DIŞ İLİŞKİLER VE İSTİHBARAT GÜNLÜĞÜ (Sinema Modunda Gizlenir)
        !vnCinemaMode &&
          h(
            "div",
            { className: "lg:col-span-1 space-y-5" },
            h(
              "div",
              { className: "rpg-panel rounded-2xl p-5" },
              h(
                "h3",
                {
                  className:
                    "text-xs font-bold uppercase tracking-wider text-pink-400 mb-3 flex items-center gap-2 royal-font"
                },
                h(Icon, { name: "heart", size: 15 }),
                " Hanedan & Dış İlişkiler"
              ),
              h(
                "div",
                { className: "space-y-2 text-xs mb-4" },
                Object.entries(gameState.relationships).map(([k, v]) => {
                  const labels = {
                    father: "İmparator Lalo",
                    adem: "Prens Adem (19)",
                    anzak: "Komutan Anzak (27)",
                    sister9: "Kız Kardeş (9)",
                    sister13: "Kız Kardeş (13)",
                    furries: "Furry Cumhuriyeti",
                    people: "İmparatorluk Halkı",
                    advisor: "Baş Danışman"
                  };
                  const charMap = {
                    father: "lalo",
                    adem: "adem",
                    anzak: "anzak",
                    sister9: "sisters",
                    sister13: "sisters",
                    furries: "furry",
                    people: "tutu",
                    advisor: "adem"
                  };
                  return h(
                    "div",
                    { key: k, className: "flex items-center justify-between py-1 border-b border-amber-500/10" },
                    h(
                      "div",
                      { className: "flex items-center gap-2 min-w-0" },
                      CharacterPortraitSVG &&
                        h(CharacterPortraitSVG, { charId: charMap[k] || "tutu", size: 28 }),
                      h("span", { className: "text-amber-100/90 truncate" }, labels[k])
                    ),
                    h(
                      "span",
                      {
                        className: `font-bold shrink-0 ${
                          v >= 70 ? "text-emerald-400" : v >= 45 ? "text-amber-300" : "text-red-400"
                        }`
                      },
                      v,
                      "/100"
                    )
                  );
                })
              ),
              h(
                "h4",
                {
                  className:
                    "text-xs font-bold uppercase text-amber-400 pt-2 border-t border-amber-500/20 mb-2 royal-font"
                },
                "Kıta Güçleri"
              ),
              h(
                "div",
                { className: "space-y-2 text-xs" },
                h(
                  "div",
                  { className: "flex items-center justify-between" },
                  h(
                    "div",
                    { className: "flex items-center gap-2" },
                    CharacterPortraitSVG && h(CharacterPortraitSVG, { charId: "doxe", size: 26 }),
                    h("span", null, "⚖️ DOXE Kutsal Krallığı")
                  ),
                  h("strong", { className: "text-indigo-300" }, gameState.worldRelations.doxe, "/100")
                ),
                h(
                  "div",
                  { className: "flex items-center justify-between" },
                  h(
                    "div",
                    { className: "flex items-center gap-2" },
                    CharacterPortraitSVG && h(CharacterPortraitSVG, { charId: "north", size: 26 }),
                    h("span", null, "⚒️ Kuzey Dağ Klanları")
                  ),
                  h("strong", { className: "text-amber-400" }, gameState.worldRelations.mountainTribes, "/100")
                ),
                h(
                  "div",
                  { className: "flex items-center justify-between" },
                  h(
                    "div",
                    { className: "flex items-center gap-2" },
                    CharacterPortraitSVG && h(CharacterPortraitSVG, { charId: "malakor", size: 26 }),
                    h("span", null, "🦇 Vampir-Kara Elf")
                  ),
                  h("strong", { className: "text-red-400" }, gameState.worldRelations.vampireElves, "/100")
                )
              )
            ),

            h(
              "div",
              { className: "rpg-panel rounded-2xl p-5" },
              h(
                "div",
                {
                  className: `text-center py-2 px-3 rounded-xl border font-bold text-xs mb-3 royal-font ${kingdomStatus.color}`
                },
                "Durum: ",
                kingdomStatus.label
              ),
              h(
                "div",
                {
                  className:
                    "p-3 bg-orange-950/45 border border-orange-500/35 rounded-xl text-xs text-orange-200 mb-3"
                },
                h("div", { className: "font-bold text-orange-400 mb-1" }, "🕵️ Son İstihbarat Raporu:"),
                gameState.rivalState.lastRivalMove
              ),
              h(
                "div",
                { className: "text-[11px] text-amber-200/75 space-y-1 mb-3" },
                h(
                  "div",
                  null,
                  "🏛️ Dünya Atlası Hakimiyeti: ",
                  h("strong", { className: "text-white" }, totalPlayerProvs, " / ", totalProvincesCount, " Eyalet")
                ),
                h("div", null, "💰 Ekonomi: ", h("strong", { className: "text-white" }, gameState.worldState.economicState)),
                h("div", null, "⚔️ Ordu: ", h("strong", { className: "text-white" }, gameState.worldState.militaryStrength)),
                h("div", null, "🔗 Kölelik: ", h("strong", { className: "text-white" }, gameState.worldState.slavery))
              ),
              h(
                "div",
                {
                  className:
                    "bg-stone-950/90 p-2.5 rounded-xl max-h-44 overflow-y-auto text-[11px] space-y-1 border border-amber-500/20"
                },
                gameState.historyLog.map((logItem, i) =>
                  h(
                    "div",
                    { key: i, className: "text-amber-100/80 border-b border-stone-900 pb-1" },
                    logItem
                  )
                )
              )
            )
          )
      )
    ),

    // ========================================================================
    // MODAL 1: ACİL SARAY & EYALET KRİZ OLAYI
    // ========================================================================
    activeCrisis &&
      !battleState &&
      !duelState &&
      h(
        "div",
        {
          className:
            "fixed inset-0 bg-black/85 backdrop-blur-sm flex items-center justify-center z-50 p-4"
        },
        h(
          "div",
          { className: "rpg-panel border-2 border-amber-500/70 rounded-2xl max-w-lg w-full p-6 shadow-2xl" },
          h(
            "div",
            { className: "text-xs font-bold uppercase tracking-wider text-amber-400 mb-1" },
            "⚡ Acil Saray & Eyalet Raporu (Tur ",
            gameState.turn,
            ")"
          ),
          h("h3", { className: "text-xl font-bold royal-font text-amber-300 mb-3" }, activeCrisis.title),
          h("p", { className: "story-prose text-base mb-5" }, activeCrisis.description),
          h(
            "div",
            { className: "space-y-2.5" },
            activeCrisis.choices.map((c, idx) =>
              h(
                "button",
                {
                  key: idx,
                  onClick: () => handleEventChoice(c),
                  className:
                    "w-full text-left p-3.5 rpg-card hover:bg-amber-950/50 hover:border-amber-400 rounded-xl transition-all"
                },
                h("div", { className: "text-xs font-bold text-white mb-0.5" }, c.text),
                h("div", { className: "text-[11px] text-emerald-400" }, c.effectText)
              )
            )
          )
        )
      ),

    // ========================================================================
    // MODAL 2: 2D TAKTİKSEL MUHAREBE MEYDANI & KOMUTA PUANI (CP) ZAR HİLELERİ
    // ========================================================================
    battleState &&
      h(
        "div",
        {
          className:
            "fixed inset-0 bg-black/85 backdrop-blur-sm flex items-center justify-center z-50 p-4 overflow-y-auto"
        },
        h(
          "div",
          {
            className:
              "rpg-panel border-2 border-red-500/60 rounded-2xl max-w-3xl w-full p-5 shadow-2xl my-auto"
          },
          h(
            "div",
            {
              className:
                "flex flex-wrap justify-between items-center gap-2 border-b border-amber-500/20 pb-3 mb-3"
            },
            h(
              "div",
              null,
              h(
                "h3",
                { className: "text-xl font-bold royal-font text-red-400" },
                "⚔️ ",
                battleState.targetProvinceName,
                " — 2D Taktiksel Muharebe Meydanı"
              ),
              h(
                "p",
                { className: "text-xs text-amber-200/75" },
                "Kısayollar: [1] Standart • [2] Hücum • [3] Kalkan • [A] Okçu • [S] Paladin • [D] Topçu • [F] Nara"
              )
            ),
            h(
              "div",
              { className: "flex items-center gap-2" },
              h(
                "span",
                {
                  className:
                    "px-3 py-1 bg-amber-950 border border-amber-400 text-amber-300 text-xs font-bold rounded-full"
                },
                "🎖️ Komuta Puanı: ",
                battleState.commandPoints,
                " / ",
                battleState.maxCommandPoints,
                " CP"
              ),
              h(
                "span",
                {
                  className:
                    "px-3 py-1 bg-emerald-950 border border-emerald-500/50 text-emerald-300 text-xs font-bold rounded-full"
                },
                "Zafer Şansı: %",
                battleState.winProbability
              )
            )
          ),

          // 2D Savaş Meydanı & Animasyonlu Zarlar (Battle2DArena)
          Battle2DArena && h(Battle2DArena, { battleState }),

          // Muharebe Günlüğü
          h(
            "div",
            {
              className:
                "bg-stone-950/95 border border-amber-500/25 rounded-xl p-2.5 mb-3 max-h-28 overflow-y-auto text-xs space-y-1"
            },
            battleState.battleLog.map((l, i) =>
              h("div", { key: i, className: "text-amber-100 border-b border-stone-900 pb-1" }, l)
            )
          ),

          battleState.status === "ongoing"
            ? h(
                "div",
                { className: "space-y-2.5" },
                // 1. Ana Taarruz Seçenekleri (1, 2, 3)
                h(
                  "div",
                  { className: "flex flex-wrap gap-2" },
                  h(
                    "button",
                    {
                      onClick: () =>
                        setBattleState(
                          window.PrinceTutu.CombatEngine.executeBattleRound(battleState, "standard")
                        ),
                      className:
                        "px-3.5 py-2 bg-blue-700 hover:bg-blue-600 border border-blue-400 font-bold rounded-xl text-xs"
                    },
                    "[1] 🎲 3v2 Standart Taarruz"
                  ),
                  h(
                    "button",
                    {
                      onClick: () =>
                        setBattleState(
                          window.PrinceTutu.CombatEngine.executeBattleRound(battleState, "all_out")
                        ),
                      className:
                        "px-3.5 py-2 bg-amber-600 hover:bg-amber-500 text-black font-bold rounded-xl text-xs"
                    },
                    "[2] 🔥 Topyekün Hücum (2. Zara +1)"
                  ),
                  h(
                    "button",
                    {
                      onClick: () =>
                        setBattleState(
                          window.PrinceTutu.CombatEngine.executeBattleRound(battleState, "shield_wall")
                        ),
                      className:
                        "px-3.5 py-2 bg-stone-800 hover:bg-stone-700 border border-stone-500 font-bold rounded-xl text-xs"
                    },
                    "[3] 🛡️ Kalkan Duvarı (Maks 1 Kayıp)"
                  ),
                  h(
                    "button",
                    {
                      onClick: closeBattleModal,
                      className: "ml-auto px-3 py-2 bg-stone-900 border border-stone-700 rounded-xl text-xs text-stone-400"
                    },
                    "Geri Çekil"
                  )
                ),

                // 2. SAVAŞ HİLELERİ (TACTICAL GAMBITS - KOMUTA PUANI / CP SİSTEMİ)
                h(
                  "div",
                  {
                    className:
                      "p-2.5 bg-amber-950/35 border border-amber-500/40 rounded-xl flex flex-wrap items-center gap-2"
                  },
                  h(
                    "span",
                    { className: "text-[11px] font-bold text-amber-300 royal-font mr-1" },
                    "🎖️ Savaş Hileleri (CP):"
                  ),
                  h(
                    "button",
                    {
                      disabled: battleState.commandPoints < 2,
                      onClick: () =>
                        setBattleState(window.PrinceTutu.CombatEngine.triggerGambitWolfTrap(battleState)),
                      className: `px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                        battleState.commandPoints >= 2
                          ? "bg-amber-600 hover:bg-amber-500 text-black border-yellow-200"
                          : "bg-stone-900 text-stone-500 border-stone-800 cursor-not-allowed"
                      }`
                    },
                    "🐺 Kurt Kapanı (2 CP • En Düşük Zarı 6 Yap!)"
                  ),
                  h(
                    "button",
                    {
                      disabled: battleState.commandPoints < 1,
                      onClick: () =>
                        setBattleState(window.PrinceTutu.CombatEngine.triggerGambitSmokeBomb(battleState)),
                      className: `px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                        battleState.commandPoints >= 1
                          ? "bg-slate-700 hover:bg-slate-600 text-white border-slate-400"
                          : "bg-stone-900 text-stone-500 border-stone-800 cursor-not-allowed"
                      }`
                    },
                    "💨 Sis Bombası (1 CP • Düşman Büyük Zarını Sil!)"
                  ),
                  h(
                    "button",
                    {
                      disabled: battleState.commandPoints < 2 || battleState.explodingDiceActive,
                      onClick: () =>
                        setBattleState(
                          window.PrinceTutu.CombatEngine.triggerGambitExplodingDice(battleState)
                        ),
                      className: `px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                        battleState.explodingDiceActive
                          ? "bg-emerald-950 text-emerald-300 border-emerald-500/40"
                          : battleState.commandPoints >= 2
                          ? "bg-red-700 hover:bg-red-600 text-white border-red-400"
                          : "bg-stone-900 text-stone-500 border-stone-800 cursor-not-allowed"
                      }`
                    },
                    battleState.explodingDiceActive
                      ? "💥 Patlayan Zarlar Aktif ✓"
                      : "💥 Patlayan Zarlar (2 CP • Her 6'da +1 Ek Zar!)"
                  )
                ),

                // 3. Birlik Özel Yetenekleri (A, S, D, F)
                h(
                  "div",
                  { className: "flex flex-wrap gap-2 pt-1 border-t border-amber-500/20" },
                  !battleState.archerVolleyUsed &&
                    battleState.units.furryArchers > 0 &&
                    h(
                      "button",
                      {
                        onClick: () =>
                          setBattleState(window.PrinceTutu.CombatEngine.triggerArcherVolley(battleState)),
                        className:
                          "px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 font-bold rounded-lg text-xs"
                      },
                      "[A] 🏹 Furry Yaylım Ateşi"
                    ),
                  !battleState.paladinPurgeUsed &&
                    battleState.units.doxePaladins > 0 &&
                    h(
                      "button",
                      {
                        onClick: () =>
                          setBattleState(window.PrinceTutu.CombatEngine.triggerPaladinPurge(battleState)),
                        className:
                          "px-3 py-1.5 bg-indigo-700 hover:bg-indigo-600 font-bold rounded-lg text-xs"
                      },
                      "[S] ⚖️ DOXE Kutsal Arındırma"
                    ),
                  !battleState.artilleryUsed &&
                    battleState.hasArtillery &&
                    h(
                      "button",
                      {
                        onClick: () =>
                          setBattleState(
                            window.PrinceTutu.CombatEngine.triggerArtilleryBarrage(battleState)
                          ),
                        className:
                          "px-3 py-1.5 bg-orange-700 hover:bg-orange-600 font-bold rounded-lg text-xs"
                      },
                      "[D] 💣 Topçu Bombardımanı"
                    ),
                  !battleState.warcryUsed &&
                    battleState.units.mountainAxemen > 0 &&
                    h(
                      "button",
                      {
                        onClick: () =>
                          setBattleState(
                            window.PrinceTutu.CombatEngine.triggerBerserkerWarcry(battleState)
                          ),
                        className:
                          "px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded-lg text-xs"
                      },
                      "[F] 🪓 Kuzey Savaş Narası"
                    )
                )
              )
            : h(
                "button",
                {
                  onClick: closeBattleModal,
                  className:
                    "w-full py-3 bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-bold rounded-xl shadow-lg"
                },
                battleState.status === "won"
                  ? "🏆 Zaferi Kutla, Eyaleti Devral ve Ganimeti Al! (Enter)"
                  : "Cepheden Ayrıl (Enter)"
              )
        )
      ),

    // ========================================================================
    // MODAL 3: 2D YAN PROFİL KILIÇ DÜELLOSU ARENASI & 3 DURUŞ (STANCE) SİSTEMİ
    // ========================================================================
    duelState &&
      h(
        "div",
        {
          className:
            "fixed inset-0 bg-black/85 backdrop-blur-sm flex items-center justify-center z-50 p-4 overflow-y-auto"
        },
        h(
          "div",
          {
            className:
              "rpg-panel border-2 border-amber-500/70 rounded-2xl max-w-2xl w-full p-5 shadow-2xl my-auto"
          },
          h(
            "div",
            { className: "flex flex-wrap justify-between items-center gap-2 mb-2" },
            h(
              "h3",
              { className: "text-xl font-bold royal-font text-amber-300" },
              "🗡️ 2D Yan Profil Kılıç Düellosu: Prens Tutu vs ",
              duelState.opponentName
            ),
            h(
              "span",
              { className: "text-[11px] text-amber-200/80" },
              "Kısayollar: [A] Sapla • [S] Siper • [D] Psikolojik • [F] Nefeslen • [Space] İnfaz"
            )
          ),

          // Rakibin Niyet Kartı
          h(
            "div",
            {
              className:
                "p-2.5 bg-amber-950/60 border border-amber-400/40 rounded-xl text-xs text-amber-200 mb-3"
            },
            "👁️ ",
            h("strong", null, "Rakibin Niyeti:"),
            " ",
            duelState.anzakIntent
          ),

          // 2D Yan Profil Düello Arenası (Duel2DArena)
          Duel2DArena && h(Duel2DArena, { duelState }),

          // DURUŞ (STANCE) SEÇİCİ ÇUBUĞU (Saldırgan / Demir Muhafız / Gölge Dansçısı)
          duelState.status === "ongoing" &&
            h(
              "div",
              { className: "grid grid-cols-3 gap-2 mb-3" },
              [
                {
                  id: "aggressive",
                  keyNum: "1",
                  title: "🔥 Saldırgan Duruş",
                  sub: "Hasar +%40, Stamina Az"
                },
                {
                  id: "iron_guard",
                  keyNum: "2",
                  title: "🛡️ Demir Muhafız",
                  sub: "-%50 Hasar & Siperde Sersemlet"
                },
                {
                  id: "shadow_dancer",
                  keyNum: "3",
                  title: "🌙 Gölge Dansçısı",
                  sub: "Doğru Tahminde +40🔥 Odak"
                }
              ].map((st) =>
                h(
                  "button",
                  {
                    key: st.id,
                    onClick: () =>
                      setDuelState(window.PrinceTutu.CombatEngine.setDuelStance(duelState, st.id)),
                    className: `p-2 rounded-xl border text-left transition-all ${
                      duelState.stance === st.id
                        ? "bg-amber-500/25 border-amber-400 text-amber-200 shadow"
                        : "bg-stone-900/90 border-stone-700 text-stone-400 hover:text-white"
                    }`
                  },
                  h("div", { className: "text-xs font-bold" }, `[${st.keyNum}] ${st.title}`),
                  h("div", { className: "text-[10px] opacity-85" }, st.sub)
                )
              )
            ),

          // Can, Stamina ve Odak Barları
          h(
            "div",
            { className: "grid grid-cols-2 gap-4 mb-3" },
            h(
              "div",
              { className: "p-2.5 rpg-card rounded-xl space-y-1.5" },
              h(
                "div",
                null,
                h(
                  "div",
                  { className: "flex justify-between text-xs mb-1" },
                  h("span", { className: "font-bold text-emerald-400" }, "Prens Tutu (Can)"),
                  h("span", null, duelState.playerHP, "/", duelState.maxPlayerHP, " HP")
                ),
                h(
                  "div",
                  { className: "w-full bg-stone-900 h-2 rounded-full overflow-hidden" },
                  h("div", {
                    className: "bg-emerald-500 h-full transition-all",
                    style: { width: `${(duelState.playerHP / duelState.maxPlayerHP) * 100}%` }
                  })
                )
              ),
              h(
                "div",
                null,
                h(
                  "div",
                  { className: "flex justify-between text-[11px] mb-0.5" },
                  h("span", { className: "font-semibold text-blue-300" }, "⚡ Dayanıklılık (Stamina)"),
                  h("span", null, duelState.stamina, "/", duelState.maxStamina)
                ),
                h(
                  "div",
                  { className: "w-full bg-stone-900 h-1.5 rounded-full overflow-hidden" },
                  h("div", {
                    className: "bg-blue-400 h-full transition-all",
                    style: { width: `${(duelState.stamina / duelState.maxStamina) * 100}%` }
                  })
                )
              ),
              h(
                "div",
                null,
                h(
                  "div",
                  { className: "flex justify-between text-[11px] mb-0.5" },
                  h("span", { className: "font-semibold text-yellow-300" }, "🔥 Kraliyet Odağı (%70'te İnfaz!)"),
                  h("span", null, duelState.focus, "%")
                ),
                h(
                  "div",
                  { className: "w-full bg-stone-900 h-1.5 rounded-full overflow-hidden" },
                  h("div", {
                    className: "bg-yellow-400 h-full transition-all",
                    style: { width: `${duelState.focus}%` }
                  })
                )
              )
            ),
            h(
              "div",
              { className: "p-2.5 rpg-card rounded-xl flex flex-col justify-center" },
              h(
                "div",
                { className: "flex justify-between text-xs mb-1" },
                h("span", { className: "font-bold text-red-400" }, duelState.opponentName),
                h("span", null, duelState.anzakHP, "/", duelState.maxAnzakHP, " HP")
              ),
              h(
                "div",
                { className: "w-full bg-stone-900 h-2.5 rounded-full overflow-hidden" },
                h("div", {
                  className: "bg-red-500 h-full transition-all",
                  style: { width: `${(duelState.anzakHP / duelState.maxAnzakHP) * 100}%` }
                })
              ),
              h(
                "p",
                { className: "text-[11px] text-amber-200/75 mt-1.5" },
                "Tur: ",
                duelState.round,
                " • Silah: ",
                duelState.hasMoonlightSword
                  ? "Ayışığı Kılıcı (+14)"
                  : duelState.hasSilverDagger
                  ? "Gümüş Hançer (+8)"
                  : "Standart"
              )
            )
          ),

          // Düello Günlüğü
          h(
            "div",
            {
              className:
                "bg-stone-950/95 border border-amber-500/20 rounded-xl p-2.5 mb-3 max-h-28 overflow-y-auto text-xs space-y-1"
            },
            duelState.duelLog.map((l, i) =>
              h("div", { key: i, className: "text-amber-100 border-b border-stone-900 pb-1" }, l)
            )
          ),

          duelState.status === "ongoing"
            ? h(
                "div",
                { className: "space-y-2" },
                duelState.focus >= 70 &&
                  h(
                    "button",
                    {
                      onClick: () =>
                        setDuelState(
                          window.PrinceTutu.CombatEngine.executeDuelRound(
                            duelState,
                            "royal_execution",
                            gameState
                          )
                        ),
                      className:
                        "w-full p-2.5 bg-gradient-to-r from-yellow-400 via-amber-500 to-orange-500 hover:from-yellow-300 hover:to-amber-400 text-black rounded-xl text-xs font-extrabold text-center shadow-lg"
                    },
                    "[Space] ⚡ İMPARATORLUK İNFAZ DARBESİ VUR! (0⚡ Stamina, -70🔥 Odak ➔ Altın Şimşek & Can Yenileme!)"
                  ),
                h(
                  "div",
                  { className: "grid grid-cols-2 gap-2" },
                  h(
                    "button",
                    {
                      onClick: () =>
                        setDuelState(
                          window.PrinceTutu.CombatEngine.executeDuelRound(
                            duelState,
                            "dagger_lunge",
                            gameState
                          )
                        ),
                      className:
                        "p-2.5 bg-red-950/85 hover:bg-red-900 border border-red-500/40 rounded-xl text-xs font-bold text-left"
                    },
                    h(
                      "div",
                      null,
                      "[A] 🗡️ ",
                      duelState.hasMoonlightSword ? "Ayışığı Saplaması" : "Gümüş Hançer Sapla"
                    ),
                    h("div", { className: "text-[10px] text-red-200 font-normal" }, "'Omuz / Pençe Darbesi'ni ezer!")
                  ),
                  h(
                    "button",
                    {
                      onClick: () =>
                        setDuelState(
                          window.PrinceTutu.CombatEngine.executeDuelRound(
                            duelState,
                            "parry_riposte",
                            gameState
                          )
                        ),
                      className:
                        "p-2.5 bg-blue-950/85 hover:bg-blue-900 border border-blue-500/40 rounded-xl text-xs font-bold text-left"
                    },
                    h("div", null, "[S] 🛡️ Siper & Kontra"),
                    h(
                      "div",
                      { className: "text-[10px] text-blue-200 font-normal" },
                      "'Ağır İndirme'yi ezer! (Demir Muhafızda Sersemletir)"
                    )
                  ),
                  h(
                    "button",
                    {
                      onClick: () =>
                        setDuelState(
                          window.PrinceTutu.CombatEngine.executeDuelRound(
                            duelState,
                            "royal_psyche",
                            gameState
                          )
                        ),
                      className:
                        "p-2.5 bg-purple-950/85 hover:bg-purple-900 border border-purple-500/40 rounded-xl text-xs font-bold text-left"
                    },
                    h("div", null, "[D] 🧠 Psikolojik Sarsıntı"),
                    h("div", { className: "text-[10px] text-purple-200 font-normal" }, "'Öfkeli Kesik / Büyü'yü ezer!")
                  ),
                  h(
                    "button",
                    {
                      onClick: () =>
                        setDuelState(
                          window.PrinceTutu.CombatEngine.executeDuelRound(
                            duelState,
                            "catch_breath",
                            gameState
                          )
                        ),
                      className:
                        "p-2.5 bg-emerald-950/85 hover:bg-emerald-900 border border-emerald-500/40 rounded-xl text-xs font-bold text-left"
                    },
                    h("div", null, "[F] 💨 Nefeslen & Odaklan (0⚡)"),
                    h("div", { className: "text-[10px] text-emerald-200 font-normal" }, "+Stamina, +Can & +Odak yeniler")
                  )
                )
              )
            : h(
                "button",
                {
                  onClick: closeDuelModal,
                  className: "w-full py-3 bg-amber-500 text-black font-bold rounded-xl"
                },
                "Düelloyu Tamamla ve Ödülleri Al (Enter)"
              )
        )
      )
  );
};

window.PrinceTutuApp = PrinceTutuApp;

function RootModeController() {
  var _mode = React.useState(window.BirGunApp ? "bir_gun" : "legacy");
  var mode = _mode[0];
  var setMode = _mode[1];

  if (mode === "bir_gun" && window.BirGunApp) {
    return React.createElement(window.BirGunApp, {
      onSwitchToLegacy: function () {
        setMode("legacy");
      }
    });
  }

  return React.createElement(
    "div",
    null,
    window.BirGunApp
      ? React.createElement(
          "div",
          {
            className:
              "bg-amber-950/95 border-b border-amber-500/50 px-4 py-2 flex items-center justify-between text-xs text-amber-200 sticky top-0 z-50"
          },
          React.createElement(
            "span",
            null,
            "🗺️ Şu anda Eski 18 Eyaletli Sandbox Sürümünü görüntülüyorsunuz."
          ),
          React.createElement(
            "button",
            {
              onClick: function () {
                setMode("bir_gun");
              },
              className:
                "px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold transition"
            },
            "👑 Yeni Temel Bölüme Dön (Prens Tutu: Bir Gün) →"
          )
        )
      : null,
    React.createElement(PrinceTutuApp, null)
  );
}

function mountPrinceTutuApp() {
  var rootEl = document.getElementById("root");
  if (!rootEl) return;
  try {
    var root = ReactDOM.createRoot(rootEl);
    root.render(React.createElement(RootModeController, null));
  } catch (err) {
    rootEl.innerHTML =
      '<div style="padding:2rem;color:#f87171;font-family:sans-serif;text-align:center;">' +
      "<h2>Uygulama Başlatma Hatası</h2>" +
      '<p style="color:#cbd5e1;font-size:0.9rem;">' +
      (err.message || err) +
      "</p></div>";
  }
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", mountPrinceTutuApp);
} else {
  mountPrinceTutuApp();
}