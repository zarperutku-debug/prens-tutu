// ============================================================================
// PRENS TUTU: GÖLGELERİN TACI - 2D GÖRSEL ROMAN (VISUAL NOVEL) & HARİTA MOTORU (v8.0)
// Yüksek Çözünürlüklü Boyalı Arka Planlar (./assets/bg_*.jpg), Karakter Portreleri
// (./assets/char_*.jpg), Katmanlı Parallax, Canvas 2D Atmosfer & 18 Eyaletli Dünya Atlası
// ============================================================================

window.PrinceTutu = window.PrinceTutu || {};

(function () {
  const { useState, useEffect, useRef, useMemo } = React;
  const h = React.createElement;

  // ---------------------------------------------------------------------------
  // 1. KARAKTER PORTRE VERİTABANI (BOYALI GÖRSEL ROMAN PORTRELERİ & TAROT KARTLARI)
  // ---------------------------------------------------------------------------
  const CHARACTER_META = {
    tutu: {
      id: "tutu",
      name: "Prens Tutu",
      title: "Altın Taht Veliahtı",
      faction: "Lalo İmparatorluğu",
      img: "./assets/char_tutu.jpg",
      accent: "#f59e0b",
      border: "#fbbf24",
      bgCrop: "./assets/bg_throne.jpg",
      quote: "Taht yalnızca altınla değil, demir ve iradeyle korunur."
    },
    anzak: {
      id: "anzak",
      name: "Komutan Anzak",
      title: "İmparatorluk Başkomutanı",
      faction: "Kraliyet Lejyonları",
      img: "./assets/char_anzak.jpg",
      accent: "#ef4444",
      border: "#f87171",
      bgCrop: "./assets/bg_eastern_pass.jpg",
      quote: "Merhamet savaş meydanında zırh delmez, kardeşim!"
    },
    adem: {
      id: "adem",
      name: "Prens Adem",
      title: "Divan & İstihbarat Şefi",
      faction: "Gölge Konseyi",
      img: "./assets/char_adem.jpg",
      accent: "#10b981",
      border: "#34d399",
      bgCrop: "./assets/bg_council.jpg",
      quote: "Bir ferman bazen yüz tabur kılıçtan daha derine işler."
    },
    lalo: {
      id: "lalo",
      name: "İmparator Lalo",
      title: "Altın Taht Hükümdarı",
      faction: "Lalo Hanedanı",
      img: null,
      accent: "#eab308",
      border: "#fde047",
      bgCrop: "./assets/bg_throne.jpg",
      bgPos: "center 35%",
      quote: "Gölgeler yaklaşırken tahtın ağırlığını omuzlarında hissedeceksin."
    },
    sisters: {
      id: "sisters",
      name: "Prenses Kardeşler",
      title: "Kraliyet Hanedanı (9 & 13 Yaş)",
      faction: "Lalo Hanedanı",
      img: null,
      accent: "#ec4899",
      border: "#f472b6",
      bgCrop: "./assets/bg_palace_terrace.jpg",
      bgPos: "25% 40%",
      quote: "Tutu abi, saray koridorlarında fısıldananları senin için dinledik..."
    },
    malakor: {
      id: "malakor",
      name: "Lord Malakor",
      title: "Kan Lejyonları & Gölge Kalesi Hükümdarı",
      faction: "Vampir - Kara Elf İttifakı",
      img: null,
      accent: "#dc2626",
      border: "#f87171",
      bgCrop: "./assets/bg_vampire_citadel.jpg",
      bgPos: "center 28%",
      quote: "Kızıl Ay yükseldiğinde ölümlü krallıkların külleri bize biat edecek."
    },
    furry: {
      id: "furry",
      name: "Amiral Volkov",
      title: "Furry Cumhuriyeti Yüksek Elçisi",
      faction: "Furry Cumhuriyeti",
      img: null,
      accent: "#10b981",
      border: "#34d399",
      bgCrop: "./assets/bg_furry_port.jpg",
      bgPos: "42% 45%",
      quote: "Gümüş Pençe donanmasının yelkenleri altın ve özgür ticaret rüzgarıyla dolar."
    },
    doxe: {
      id: "doxe",
      name: "Başrahip Solaris",
      title: "DOXE Kutsal Engizisyon Elçisi",
      faction: "DOXE Kutsal Krallığı",
      img: null,
      accent: "#f59e0b",
      border: "#fde047",
      bgCrop: "./assets/bg_doxe_cathedral.jpg",
      bgPos: "62% 35%",
      quote: "Güneş Katedrali'nin kutsal ışığı karanlıkta yürüyenleri yargılayacaktır."
    },
    north: {
      id: "north",
      name: "Ulu Şef Torvald",
      title: "Buzboynuz & Gümüş Zirveler Şefi",
      faction: "Kuzey Dağ Klanları",
      img: null,
      accent: "#38bdf8",
      border: "#7dd3fc",
      bgCrop: "./assets/bg_north_peaks.jpg",
      bgPos: "60% 40%",
      quote: "Kuzeyin mitril baltaları yalnızca sözünün eri savaşçılar için dövülür!"
    }
  };

  // Karakter Tarot / Chiaroscuro İllüstrasyon Katmanı (boyalı arka plan + detaylı karanlık fantezi portresi)
  function renderPaintedTarotOverlay(charId) {
    if (charId === "lalo") {
      return h("svg", { viewBox: "0 0 200 260", className: "w-full h-full" },
        h("defs", null,
          h("linearGradient", { id: "laloGold", x1: "0", y1: "0", x2: "0", y2: "1" },
            h("stop", { offset: "0%", stopColor: "#fef08a" }),
            h("stop", { offset: "50%", stopColor: "#eab308" }),
            h("stop", { offset: "100%", stopColor: "#78350f" })
          ),
          h("radialGradient", { id: "laloHalo", cx: "50%", cy: "32%", r: "45%" },
            h("stop", { offset: "0%", stopColor: "#fbbf24", stopOpacity: "0.55" }),
            h("stop", { offset: "100%", stopColor: "#000000", stopOpacity: "0" })
          )
        ),
        h("circle", { cx: 100, cy: 85, r: 78, fill: "url(#laloHalo)" }),
        h("circle", { cx: 100, cy: 85, r: 58, fill: "none", stroke: "url(#laloGold)", strokeWidth: 2, strokeDasharray: "6 3", opacity: 0.8 }),
        h("path", { d: "M22,260 C28,175 55,148 100,148 C145,148 172,175 178,260 Z", fill: "#450a0a", stroke: "url(#laloGold)", strokeWidth: 2.5 }),
        h("path", { d: "M48,260 L72,152 L128,152 L152,260 Z", fill: "#7f1d1d", opacity: 0.9 }),
        h("path", { d: "M42,162 Q100,192 158,162 Q145,142 100,144 Q55,142 42,162 Z", fill: "#e2e8f0", stroke: "#94a3b8", strokeWidth: 1.5 }),
        h("path", { d: "M72,82 C72,58 128,58 128,82 C128,118 118,142 100,152 C82,142 72,118 72,82 Z", fill: "#1e1b18", stroke: "url(#laloGold)", strokeWidth: 2 }),
        h("path", { d: "M74,104 Q100,118 126,104 Q122,148 100,164 Q78,148 74,104 Z", fill: "#cbd5e1", opacity: 0.85 }),
        h("ellipse", { cx: 88, cy: 90, rx: 4.5, ry: 2.2, fill: "#fde047" }),
        h("ellipse", { cx: 112, cy: 90, rx: 4.5, ry: 2.2, fill: "#fde047" }),
        h("polygon", { points: "64,68 70,32 86,54 100,22 114,54 130,32 136,68", fill: "url(#laloGold)", stroke: "#fef9c3", strokeWidth: 1.5 }),
        h("circle", { cx: 100, cy: 48, r: 5, fill: "#dc2626" }),
        h("circle", { cx: 80, cy: 54, r: 3.5, fill: "#38bdf8" }),
        h("circle", { cx: 120, cy: 54, r: 3.5, fill: "#38bdf8" }),
        h("line", { x1: 152, y1: 110, x2: 135, y2: 260, stroke: "url(#laloGold)", strokeWidth: 4.5 }),
        h("circle", { cx: 152, cy: 106, r: 10, fill: "url(#laloGold)" }),
        h("circle", { cx: 152, cy: 106, r: 5, fill: "#ef4444" })
      );
    }
    if (charId === "malakor") {
      return h("svg", { viewBox: "0 0 200 260", className: "w-full h-full" },
        h("defs", null,
          h("radialGradient", { id: "malAura", cx: "50%", cy: "35%", r: "50%" },
            h("stop", { offset: "0%", stopColor: "#ef4444", stopOpacity: "0.65" }),
            h("stop", { offset: "100%", stopColor: "#000000", stopOpacity: "0" })
          )
        ),
        h("circle", { cx: 100, cy: 88, r: 80, fill: "url(#malAura)" }),
        h("polygon", { points: "30,175 18,95 68,142 100,155 132,142 182,95 170,175", fill: "#2a0808", stroke: "#dc2626", strokeWidth: 2 }),
        h("path", { d: "M20,260 C30,172 60,150 100,150 C140,150 170,172 180,260 Z", fill: "#0f0714", stroke: "#ef4444", strokeWidth: 2.5 }),
        h("polygon", { points: "75,155 125,155 100,245", fill: "#7f1d1d", opacity: 0.85 }),
        h("path", { d: "M62,55 Q42,125 52,195 L75,165 L125,165 L148,195 Q158,125 138,55 Z", fill: "#e2e8f0", opacity: 0.9 }),
        h("path", { d: "M74,78 C74,52 126,52 126,78 C126,112 114,136 100,146 C86,136 74,112 74,78 Z", fill: "#1e1b24", stroke: "#f87171", strokeWidth: 1.8 }),
        h("polygon", { points: "80,88 94,92 84,96", fill: "#ef4444" }),
        h("polygon", { points: "120,88 106,92 116,96", fill: "#ef4444" }),
        h("circle", { cx: 87, cy: 91, r: 2, fill: "#ffffff" }),
        h("circle", { cx: 113, cy: 91, r: 2, fill: "#ffffff" }),
        h("polygon", { points: "70,60 78,28 92,50 100,18 108,50 122,28 130,60", fill: "#450a0a", stroke: "#ef4444", strokeWidth: 1.8 })
      );
    }
    if (charId === "sisters") {
      return h("svg", { viewBox: "0 0 200 260", className: "w-full h-full" },
        h("circle", { cx: 100, cy: 105, r: 72, fill: "rgba(244,114,182,0.22)" }),
        h("path", { d: "M24,260 C30,185 52,160 78,160 C102,160 118,185 124,260 Z", fill: "#500724", stroke: "#f472b6", strokeWidth: 2 }),
        h("circle", { cx: 76, cy: 110, r: 28, fill: "#1f1624", stroke: "#fbcfe8", strokeWidth: 1.8 }),
        h("polygon", { points: "58,86 68,68 76,80 84,68 94,86", fill: "#fbbf24" }),
        h("circle", { cx: 68, cy: 110, r: 2.5, fill: "#f9a8d4" }),
        h("circle", { cx: 84, cy: 110, r: 2.5, fill: "#f9a8d4" }),
        h("path", { d: "M88,260 C94,198 112,174 134,174 C156,174 172,198 178,260 Z", fill: "#4c1d95", stroke: "#c084fc", strokeWidth: 2 }),
        h("circle", { cx: 132, cy: 128, r: 24, fill: "#1f1624", stroke: "#e9d5ff", strokeWidth: 1.8 }),
        h("polygon", { points: "118,108 126,92 132,102 138,92 146,108", fill: "#fbbf24" }),
        h("circle", { cx: 125, cy: 128, r: 2.3, fill: "#e879f9" }),
        h("circle", { cx: 139, cy: 128, r: 2.3, fill: "#e879f9" })
      );
    }
    if (charId === "furry") {
      return h("svg", { viewBox: "0 0 200 260", className: "w-full h-full" },
        h("circle", { cx: 100, cy: 95, r: 70, fill: "rgba(16,185,129,0.25)" }),
        h("path", { d: "M24,260 C32,175 58,150 100,150 C142,150 168,175 176,260 Z", fill: "#064e3b", stroke: "#fbbf24", strokeWidth: 2.5 }),
        h("polygon", { points: "78,150 122,150 108,260 92,260", fill: "#047857" }),
        h("polygon", { points: "64,78 52,26 86,58", fill: "#334155", stroke: "#34d399", strokeWidth: 1.8 }),
        h("polygon", { points: "136,78 148,26 114,58", fill: "#334155", stroke: "#34d399", strokeWidth: 1.8 }),
        h("polygon", { points: "62,76 100,48 138,76 128,132 100,148 72,132", fill: "#1e293b", stroke: "#34d399", strokeWidth: 2 }),
        h("ellipse", { cx: 85, cy: 94, rx: 5, ry: 2.5, fill: "#fbbf24" }),
        h("ellipse", { cx: 115, cy: 94, rx: 5, ry: 2.5, fill: "#fbbf24" }),
        h("polygon", { points: "48,66 100,36 152,66 132,74 68,74", fill: "#022c22", stroke: "#fbbf24", strokeWidth: 2 })
      );
    }
    if (charId === "doxe") {
      return h("svg", { viewBox: "0 0 200 260", className: "w-full h-full" },
        h("circle", { cx: 100, cy: 88, r: 62, fill: "none", stroke: "#fde047", strokeWidth: 4, opacity: 0.85 }),
        h("circle", { cx: 100, cy: 88, r: 52, fill: "none", stroke: "#f59e0b", strokeWidth: 1.5, strokeDasharray: "8 4" }),
        h("path", { d: "M22,260 C30,175 58,148 100,148 C142,148 170,175 178,260 Z", fill: "#f8fafc", stroke: "#eab308", strokeWidth: 3 }),
        h("polygon", { points: "85,152 115,152 108,260 92,260", fill: "#eab308" }),
        h("path", { d: "M72,84 C72,54 128,54 128,84 C128,118 116,138 100,146 C84,138 72,118 72,84 Z", fill: "#1e1b18", stroke: "#fde047", strokeWidth: 2 }),
        h("polygon", { points: "68,66 100,18 132,66", fill: "#fef08a", stroke: "#ca8a04", strokeWidth: 2 }),
        h("ellipse", { cx: 88, cy: 92, rx: 4.5, ry: 2.2, fill: "#fef08a" }),
        h("ellipse", { cx: 112, cy: 92, rx: 4.5, ry: 2.2, fill: "#fef08a" })
      );
    }
    return h("svg", { viewBox: "0 0 200 260", className: "w-full h-full" },
      h("circle", { cx: 100, cy: 95, r: 70, fill: "rgba(56,189,248,0.22)" }),
      h("path", { d: "M16,260 C24,168 55,142 100,142 C145,142 176,168 184,260 Z", fill: "#1e293b", stroke: "#38bdf8", strokeWidth: 2.5 }),
      h("path", { d: "M32,168 Q100,200 168,168 Q152,138 100,140 Q48,138 32,168 Z", fill: "#cbd5e1", opacity: 0.9 }),
      h("path", { d: "M66,64 Q24,25 38,14 Q56,42 78,56", fill: "#e2e8f0", stroke: "#94a3b8", strokeWidth: 2 }),
      h("path", { d: "M134,64 Q176,25 162,14 Q144,42 122,56", fill: "#e2e8f0", stroke: "#94a3b8", strokeWidth: 2 }),
      h("circle", { cx: 100, cy: 86, r: 30, fill: "#0f172a", stroke: "#7dd3fc", strokeWidth: 2 }),
      h("path", { d: "M70,98 Q100,115 130,98 L116,172 L100,185 L84,172 Z", fill: "#9a3412", stroke: "#fdba74", strokeWidth: 1 }),
      h("ellipse", { cx: 88, cy: 86, rx: 4.5, ry: 2.2, fill: "#38bdf8" }),
      h("ellipse", { cx: 112, cy: 86, rx: 4.5, ry: 2.2, fill: "#38bdf8" })
    );
  }

  // ---------------------------------------------------------------------------
  // KARAKTER PORTRE KARTI BİLEŞENİ (`CharacterPortraitSVG`)
  // ---------------------------------------------------------------------------
  function CharacterPortraitSVG({ charId, size = 76, active = false, speaking = false, variant = "avatar", onClick }) {
    const meta = CHARACTER_META[charId] || CHARACTER_META.tutu;

    if (variant === "vn-stage") {
      return h("div", {
        onClick,
        className: `relative select-none transition-all duration-500 rounded-2xl overflow-hidden ${
          onClick ? "cursor-pointer" : ""
        } ${
          speaking
            ? "scale-105 z-20 shadow-[0_15px_50px_rgba(0,0,0,0.95)]"
            : "scale-95 opacity-80 hover:opacity-100 z-10"
        }`,
        style: {
          width: size,
          height: Math.round(size * 1.34),
          border: speaking ? `2.5px solid ${meta.border}` : "1.5px solid rgba(212,175,55,0.35)",
          boxShadow: speaking
            ? `0 0 28px ${meta.accent}66, 0 18px 40px rgba(0,0,0,0.95)`
            : "0 10px 25px rgba(0,0,0,0.85)",
          filter: speaking ? "brightness(1.06) contrast(1.05)" : "brightness(0.72) saturate(0.88)"
        }
      },
        meta.img
          ? h("img", {
              src: meta.img,
              alt: meta.name,
              className: "w-full h-full object-cover object-top transition-transform duration-700",
              style: { transform: speaking ? "scale(1.05)" : "scale(1.0)" }
            })
          : h("div", { className: "relative w-full h-full bg-black overflow-hidden" },
              h("img", {
                src: meta.bgCrop,
                alt: meta.name,
                className: "absolute inset-0 w-full h-full object-cover opacity-55 blur-[1px] scale-125",
                style: { objectPosition: meta.bgPos || "center" }
              }),
              h("div", {
                className: "absolute inset-0",
                style: {
                  background: `radial-gradient(circle at 50% 35%, ${meta.accent}33 0%, rgba(8,7,12,0.88) 80%)`
                }
              }),
              h("div", { className: "relative z-10 w-full h-full flex items-center justify-center p-1" },
                renderPaintedTarotOverlay(meta.id)
              )
            ),

        h("div", {
          className: "absolute inset-x-0 bottom-0 pt-8 pb-2 px-2 text-center",
          style: {
            background: "linear-gradient(to top, rgba(6,5,10,0.98) 0%, rgba(6,5,10,0.82) 55%, transparent 100%)"
          }
        },
          speaking && h("div", {
            className: "inline-block text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full mb-0.5 animate-pulse",
            style: { backgroundColor: `${meta.accent}33`, color: meta.border, border: `1px solid ${meta.border}88` }
          }, "💬 Konuşuyor"),
          h("div", {
            className: "royal-font font-black text-xs md:text-sm tracking-wide truncate drop-shadow",
            style: { color: speaking ? "#fef08a" : "#f1f5f9" }
          }, meta.name),
          h("div", {
            className: "text-[10px] font-medium truncate opacity-85",
            style: { color: meta.border }
          }, meta.title)
        ),

        h("div", {
          className: "absolute top-1.5 left-1.5 w-3 h-3 border-t-2 border-l-2 pointer-events-none",
          style: { borderColor: meta.border }
        }),
        h("div", {
          className: "absolute top-1.5 right-1.5 w-3 h-3 border-t-2 border-r-2 pointer-events-none",
          style: { borderColor: meta.border }
        })
      );
    }

    return h("div", {
      onClick,
      className: `relative rounded-xl overflow-hidden select-none transition-all duration-300 shrink-0 ${
        onClick ? "cursor-pointer" : ""
      } ${
        active ? "ring-2 ring-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.45)]" : "ring-1 ring-amber-500/35"
      }`,
      style: {
        width: size,
        height: size,
        background: "#0b0a0e",
        boxShadow: "0 8px 20px rgba(0,0,0,0.8)"
      }
    },
      meta.img
        ? h("img", {
            src: meta.img,
            alt: meta.name,
            className: "w-full h-full object-cover object-top"
          })
        : h("div", { className: "relative w-full h-full" },
            h("img", {
              src: meta.bgCrop,
              alt: meta.name,
              className: "absolute inset-0 w-full h-full object-cover opacity-50 scale-125"
            }),
            h("div", {
              className: "absolute inset-0",
              style: { background: "radial-gradient(circle, transparent 10%, rgba(8,7,12,0.85) 90%)" }
            }),
            h("div", { className: "relative z-10 w-full h-full" },
              renderPaintedTarotOverlay(meta.id)
            )
          )
    );
  }

  // ---------------------------------------------------------------------------
  // 2. 29 SAHNE İÇİN YÜKSEK ÇÖZÜNÜRLÜKLÜ BOYALI ARKA PLAN EŞLEŞTİRMESİ
  // ---------------------------------------------------------------------------
  const SCENE_VISUAL_CONFIG = {
    throne_room_morning: {
      bg: "./assets/bg_throne.jpg",
      particle: "gold_dust",
      tint: "radial-gradient(circle at 50% 35%, rgba(251,191,36,0.12) 0%, rgba(5,5,9,0.52) 100%)",
      filter: "contrast(1.06) saturate(1.08)",
      subtitle: "Altın Taht Salonu • Başkent Lalo"
    },
    imperial_bedchamber: {
      bg: "./assets/bg_council.jpg",
      particle: "gold_dust",
      tint: "radial-gradient(circle at 55% 40%, rgba(245,158,11,0.16) 0%, rgba(5,5,9,0.58) 100%)",
      filter: "contrast(1.08) sepia(0.1) saturate(1.12)",
      subtitle: "Hünkar Kasrı & Özel Hazine Dairesi"
    },
    brothers_courtyard: {
      bg: "./assets/bg_duel_arena.jpg",
      particle: "embers",
      tint: "radial-gradient(circle at 50% 45%, rgba(251,146,60,0.14) 0%, rgba(5,5,9,0.52) 100%)",
      filter: "contrast(1.08) saturate(1.1)",
      subtitle: "İç Kale Silah Avlusu • Başkent Lalo"
    },
    council_discussion: {
      bg: "./assets/bg_council.jpg",
      particle: "embers",
      tint: "radial-gradient(circle at 50% 45%, rgba(239,68,68,0.12) 0%, rgba(5,5,9,0.52) 100%)",
      filter: "contrast(1.08) saturate(1.08)",
      subtitle: "Kraliyet Savaş Konseyi • Strateji Masası"
    },
    private_chambers: {
      bg: "./assets/bg_palace_terrace.jpg",
      particle: "gold_dust",
      tint: "radial-gradient(circle at 30% 35%, rgba(244,114,182,0.12) 0%, rgba(5,5,12,0.52) 100%)",
      filter: "contrast(1.06) saturate(1.08)",
      subtitle: "Saray Batı Kanadı • Prens Tutu'nun Dairesi"
    },
    sisters_secret_tower: {
      bg: "./assets/bg_palace_terrace.jpg",
      particle: "gold_dust",
      tint: "radial-gradient(circle at 75% 30%, rgba(168,85,247,0.18) 0%, rgba(5,4,14,0.55) 100%)",
      filter: "contrast(1.1) saturate(1.14)",
      subtitle: "Unutulmuş Gözlem Kulesi • Kadim Hanedan Arşivi"
    },
    palace_dungeon_interrogation: {
      bg: "./assets/bg_duel_arena.jpg",
      particle: "embers",
      tint: "radial-gradient(circle at 50% 50%, rgba(220,38,38,0.22) 0%, rgba(3,3,8,0.72) 100%)",
      filter: "contrast(1.18) brightness(0.85)",
      subtitle: "Başkent Lalo • Yeraltı Sorgu Hücresi"
    },
    assassination_attempt: {
      bg: "./assets/bg_palace_terrace.jpg",
      particle: "embers",
      tint: "radial-gradient(circle at 50% 40%, rgba(239,68,68,0.22) 0%, rgba(4,4,10,0.65) 100%)",
      filter: "contrast(1.14) brightness(0.9)",
      subtitle: "Saray Koridorları • Gece Yarısı Suikast Girişimi"
    },
    whisper_forest_infiltration: {
      bg: "./assets/bg_vampire_citadel.jpg",
      particle: "embers",
      tint: "radial-gradient(circle at 40% 50%, rgba(16,185,129,0.18) 0%, rgba(4,8,8,0.65) 100%)",
      filter: "contrast(1.1) hue-rotate(-35deg)",
      subtitle: "Fısıltı Ormanı Sınırı • Gölge Suikastçı İni"
    },
    diplomatic_crossroads: {
      bg: "./assets/bg_throne.jpg",
      particle: "gold_dust",
      tint: "radial-gradient(circle at 50% 35%, rgba(251,191,36,0.15) 0%, rgba(5,5,9,0.52) 100%)",
      filter: "contrast(1.08) saturate(1.1)",
      subtitle: "Başkent Lalo • Şafak Divanı"
    },
    marketplace_morning: {
      bg: "./assets/bg_furry_port.jpg",
      particle: "gold_dust",
      tint: "radial-gradient(circle at 50% 45%, rgba(245,158,11,0.16) 0%, rgba(8,6,5,0.52) 100%)",
      filter: "contrast(1.06) saturate(1.1)",
      subtitle: "Başkent Lalo • Büyük Ticaret Meydanı"
    },
    furry_port_embassy: {
      bg: "./assets/bg_furry_port.jpg",
      particle: "gold_dust",
      tint: "radial-gradient(circle at 45% 35%, rgba(16,185,129,0.14) 0%, rgba(4,10,12,0.48) 100%)",
      filter: "contrast(1.06) saturate(1.12)",
      subtitle: "Furry Cumhuriyeti • Gümüş Pençe Limanı & Senatosu"
    },
    doxe_monastery_trial: {
      bg: "./assets/bg_doxe_cathedral.jpg",
      particle: "gold_dust",
      tint: "radial-gradient(circle at 60% 30%, rgba(253,224,71,0.18) 0%, rgba(10,8,4,0.48) 100%)",
      filter: "contrast(1.06) brightness(1.04)",
      subtitle: "DOXE Yüksek Katedrali • Işık ve Zincir Mahkemesi"
    },
    northern_forge_clans: {
      bg: "./assets/bg_north_peaks.jpg",
      particle: "snow",
      tint: "radial-gradient(circle at 55% 40%, rgba(56,189,248,0.14) 0%, rgba(4,8,16,0.50) 100%)",
      filter: "contrast(1.08) saturate(1.08)",
      subtitle: "Kuzey Dağları • Gümüş Zirveler Ulu Demir Ocağı"
    },
    faction_envoy_summit: {
      bg: "./assets/bg_council.jpg",
      particle: "gold_dust",
      tint: "radial-gradient(circle at 50% 40%, rgba(251,191,36,0.16) 0%, rgba(5,5,9,0.52) 100%)",
      filter: "contrast(1.08) saturate(1.12)",
      subtitle: "Başkent Elçiler Zirvesi • Büyük Koalisyon Masası"
    },
    southern_barons_rebellion: {
      bg: "./assets/bg_eastern_pass.jpg",
      particle: "embers",
      tint: "radial-gradient(circle at 50% 40%, rgba(249,115,22,0.18) 0%, rgba(10,5,4,0.55) 100%)",
      filter: "contrast(1.1) saturate(1.12)",
      subtitle: "Güney Bereket Ovaları • Köle Baronlarının İsyanı"
    },
    eastern_front_crisis: {
      bg: "./assets/bg_eastern_pass.jpg",
      particle: "embers",
      tint: "radial-gradient(circle at 50% 35%, rgba(220,38,38,0.22) 0%, rgba(10,4,4,0.56) 100%)",
      filter: "contrast(1.12) saturate(1.15)",
      subtitle: "Doğu Kızıl Geçidi Kalesi • Kanlı Şafak"
    },
    vampire_citadel_siege: {
      bg: "./assets/bg_vampire_citadel.jpg",
      particle: "blood_rain",
      tint: "radial-gradient(circle at 50% 30%, rgba(220,38,38,0.24) 0%, rgba(8,2,8,0.56) 100%)",
      filter: "contrast(1.14) saturate(1.18)",
      subtitle: "Doğu Sınır Ötesi • Vampir Gölge Kalesi Kuşatması"
    },
    imperial_funeral_eve: {
      bg: "./assets/bg_doxe_cathedral.jpg",
      particle: "gold_dust",
      tint: "radial-gradient(circle at 60% 30%, rgba(148,163,184,0.2) 0%, rgba(6,6,12,0.65) 100%)",
      filter: "contrast(1.1) saturate(0.82)",
      subtitle: "Kraliyet Mozolesi • İmparator Lalo'nun Veda Gecesi"
    },
    shadow_summit: {
      bg: "./assets/bg_throne.jpg",
      particle: "embers",
      tint: "radial-gradient(circle at 50% 35%, rgba(239,68,68,0.2) 0%, rgba(6,4,8,0.58) 100%)",
      filter: "contrast(1.12) saturate(1.14)",
      subtitle: "Kader Gecesi • Altın Tahtın Son Sınavı"
    },
    ending_immortal_pax: {
      bg: "./assets/bg_throne.jpg",
      particle: "gold_dust",
      tint: "radial-gradient(circle at 50% 35%, rgba(253,224,71,0.25) 0%, rgba(8,6,4,0.42) 100%)",
      filter: "contrast(1.08) brightness(1.06) saturate(1.18)",
      subtitle: "FİNAL S+ • Yedi Diyarın Ebedi Hükümdarı"
    },
    ending_sister_regency: {
      bg: "./assets/bg_palace_terrace.jpg",
      particle: "gold_dust",
      tint: "radial-gradient(circle at 55% 30%, rgba(244,114,182,0.2) 0%, rgba(5,6,14,0.45) 100%)",
      filter: "contrast(1.06) saturate(1.15)",
      subtitle: "FİNAL • Hanedanın Işığı & Prensesler Çağı"
    },
    ending_golden_coalition: {
      bg: "./assets/bg_doxe_cathedral.jpg",
      particle: "gold_dust",
      tint: "radial-gradient(circle at 60% 30%, rgba(253,224,71,0.24) 0%, rgba(8,6,4,0.45) 100%)",
      filter: "contrast(1.08) brightness(1.05)",
      subtitle: "FİNAL • Şafağın ve Özgürlüğün İmparatoru"
    },
    ending_shadow_master: {
      bg: "./assets/bg_council.jpg",
      particle: "gold_dust",
      tint: "radial-gradient(circle at 50% 40%, rgba(16,185,129,0.2) 0%, rgba(4,6,10,0.55) 100%)",
      filter: "contrast(1.12) saturate(1.1)",
      subtitle: "FİNAL • Gölgelerin ve Aklın Hükümdarı"
    },
    ending_iron_conqueror: {
      bg: "./assets/bg_eastern_pass.jpg",
      particle: "embers",
      tint: "radial-gradient(circle at 50% 35%, rgba(245,158,11,0.22) 0%, rgba(8,4,4,0.52) 100%)",
      filter: "contrast(1.12) saturate(1.15)",
      subtitle: "FİNAL • Çelik ve Zafer İmparatoru"
    },
    ending_triumvirate: {
      bg: "./assets/bg_throne.jpg",
      particle: "gold_dust",
      tint: "radial-gradient(circle at 50% 35%, rgba(251,191,36,0.2) 0%, rgba(6,5,8,0.48) 100%)",
      filter: "contrast(1.08) saturate(1.12)",
      subtitle: "FİNAL • Üç Kardeşin Demir Paktı"
    },
    ending_merchant_republic: {
      bg: "./assets/bg_furry_port.jpg",
      particle: "gold_dust",
      tint: "radial-gradient(circle at 45% 35%, rgba(16,185,129,0.2) 0%, rgba(4,8,10,0.45) 100%)",
      filter: "contrast(1.06) saturate(1.15)",
      subtitle: "FİNAL • Altın Terazi ve Meşrutiyet Tacı"
    },
    ending_coup_defeat: {
      bg: "./assets/bg_duel_arena.jpg",
      particle: "embers",
      tint: "radial-gradient(circle at 50% 45%, rgba(220,38,38,0.28) 0%, rgba(4,4,8,0.72) 100%)",
      filter: "contrast(1.16) saturate(0.75)",
      subtitle: "YENİLGİ • Demir Zindan & Saray Darbesi"
    },
    ending_vampire_fall: {
      bg: "./assets/bg_vampire_citadel.jpg",
      particle: "blood_rain",
      tint: "radial-gradient(circle at 50% 30%, rgba(220,38,38,0.32) 0%, rgba(8,2,4,0.68) 100%)",
      filter: "contrast(1.16) saturate(1.22)",
      subtitle: "YENİLGİ • Kanlı Ay Tutulması & Başkentin Düşüşü"
    }
  };

  function getSceneVisual(sceneKey, sceneObj) {
    if (sceneKey && SCENE_VISUAL_CONFIG[sceneKey]) return SCENE_VISUAL_CONFIG[sceneKey];
    const loc = ((sceneObj && sceneObj.location) || "").toLowerCase();
    if (loc.includes("kuzey") || loc.includes("zirve") || loc.includes("demir ocağı")) return SCENE_VISUAL_CONFIG.northern_forge_clans;
    if (loc.includes("furry") || loc.includes("liman") || loc.includes("pazar")) return SCENE_VISUAL_CONFIG.furry_port_embassy;
    if (loc.includes("doxe") || loc.includes("katedral") || loc.includes("manastır")) return SCENE_VISUAL_CONFIG.doxe_monastery_trial;
    if (loc.includes("geçit") || loc.includes("cephe") || loc.includes("ovalar")) return SCENE_VISUAL_CONFIG.eastern_front_crisis;
    if (loc.includes("vampir") || loc.includes("gölge kalesi")) return SCENE_VISUAL_CONFIG.vampire_citadel_siege;
    if (loc.includes("kule") || loc.includes("daire") || loc.includes("koridor")) return SCENE_VISUAL_CONFIG.private_chambers;
    if (loc.includes("strateji") || loc.includes("konsey") || loc.includes("elçi")) return SCENE_VISUAL_CONFIG.council_discussion;
    if (loc.includes("avlu") || loc.includes("zindan")) return SCENE_VISUAL_CONFIG.brothers_courtyard;
    return SCENE_VISUAL_CONFIG.throne_room_morning;
  }

  // Sahnedeki Aktif Karakterleri Tespit Et
  function detectSceneCast(sceneObj, sceneKey) {
    if (!sceneObj) return ["tutu", "lalo", "anzak", "adem"];
    const body = ((sceneObj.title || "") + " " + (sceneObj.location || "") + " " + (sceneObj.description || sceneObj.text || "")).toLowerCase();
    const cast = ["tutu"];
    if (body.includes("imparator lalo") || body.includes("baban") || sceneKey === "throne_room_morning") cast.push("lalo");
    if (body.includes("anzak")) cast.push("anzak");
    if (body.includes("adem")) cast.push("adem");
    if (body.includes("kız kardeş") || body.includes("13 yaşındaki") || body.includes("9 yaşındaki") || body.includes("prenses")) cast.push("sisters");
    if (body.includes("malakor") || body.includes("vampir lordu")) cast.push("malakor");
    if (body.includes("furry") || body.includes("pençe")) cast.push("furry");
    if (body.includes("doxe") || body.includes("katedral") || body.includes("paladin")) cast.push("doxe");
    if (body.includes("kuzey") || body.includes("klan") || body.includes("gümüş zirveler")) cast.push("north");
    if (cast.length === 1) cast.push("anzak", "adem");
    return cast.slice(0, 5);
  }

  // Paragraftan Konuşan Karakteri Otomatik Algıla (Görsel Roman Diyalog Kutusu İçin)
  function detectParagraphSpeaker(paragraphText, sceneCast) {
    const p = (paragraphText || "").toLowerCase();
    if (p.includes("baban imparator") || p.includes("imparator lalo") || p.includes("baban ") || (p.includes("oğlum") && sceneCast.includes("lalo"))) {
      return CHARACTER_META.lalo;
    }
    if (p.includes("anzak") || p.includes("ağabeyin")) {
      return CHARACTER_META.anzak;
    }
    if (p.includes("adem")) {
      return CHARACTER_META.adem;
    }
    if (p.includes("kız kardeş") || p.includes("13 yaşındaki") || p.includes("9 yaşındaki") || p.includes("tutu abi")) {
      return CHARACTER_META.sisters;
    }
    if (p.includes("malakor") || p.includes("vampir lordu")) {
      return CHARACTER_META.malakor;
    }
    if (p.includes("furry") || p.includes("pençe") || p.includes("amiral")) {
      return CHARACTER_META.furry;
    }
    if (p.includes("doxe") || p.includes("başrahip") || p.includes("katedral")) {
      return CHARACTER_META.doxe;
    }
    if (p.includes("kuzey") || p.includes("dağ klan") || p.includes("şef")) {
      return CHARACTER_META.north;
    }
    return CHARACTER_META.tutu;
  }

  // Sahne Metnini Görsel Roman Diyalog Adımlarına (Beats) Böl
  function parseSceneIntoVNBeats(sceneObj, sceneKey) {
    const rawText = sceneObj ? (sceneObj.description || sceneObj.text || "") : "";
    if (!rawText) return [];
    const cast = detectSceneCast(sceneObj, sceneKey);
    const rawParagraphs = rawText
      .split(/\n\s*\n/)
      .map(s => s.trim())
      .filter(Boolean);

    return rawParagraphs.map((para, idx) => {
      const speaker = detectParagraphSpeaker(para, cast);
      return {
        index: idx,
        text: para,
        speakerId: speaker.id,
        speakerName: speaker.name,
        speakerTitle: speaker.title,
        speakerAccent: speaker.accent,
        speakerBorder: speaker.border,
        speakerQuote: speaker.quote
      };
    });
  }

  // ---------------------------------------------------------------------------
  // 3. GÖRSEL ROMAN SAHNESİ (`Story2DStage`)
  // Boyalı Arka Plan + Parallax + Canvas 2D Atmosfer Parçacıkları + Sahne Üstü Karakterler
  // + Entegre Görsel Roman Diyalog Kutusu (Daktilo / Adım Adım İlerleme)
  // ---------------------------------------------------------------------------
  function Story2DStage({ sceneKey, scene, gameState, activeSpeakerId, onSelectSpeaker, children }) {
    const resolvedKey = sceneKey || (gameState && gameState.scene) || (scene && scene.id) || "throne_room_morning";
    const resolvedScene = scene || (window.PrinceTutu && window.PrinceTutu.SCENES && window.PrinceTutu.SCENES[resolvedKey]) || null;

    const canvasRef = useRef(null);
    const [mouseOffset, setMouseOffset] = useState({ x: 0, y: 0 });
    const visual = useMemo(() => getSceneVisual(resolvedKey, resolvedScene), [resolvedKey]);
    const cast = useMemo(() => detectSceneCast(resolvedScene, resolvedKey), [resolvedKey]);
    const currentSpeaker = activeSpeakerId || cast[0] || "tutu";

    // Canvas 2D Atmosferik Parçacık Motoru
    useEffect(() => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext("2d");
      let animId;
      const w = (canvas.width = 960);
      const hCanvas = (canvas.height = 540);
      const pType = visual.particle || "gold_dust";
      const count = pType === "snow" ? 75 : pType === "embers" ? 60 : pType === "blood_rain" ? 65 : 45;

      const particles = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * hCanvas,
        r: Math.random() * 2.6 + 0.8,
        vx: (Math.random() - 0.5) * (pType === "snow" ? 1.3 : 0.6),
        vy: pType === "embers"
          ? -(Math.random() * 1.4 + 0.5)
          : pType === "blood_rain"
          ? Math.random() * 3.2 + 1.8
          : pType === "snow"
          ? Math.random() * 1.5 + 0.6
          : (Math.random() - 0.5) * 0.4,
        alpha: Math.random() * 0.65 + 0.2
      }));

      const render = () => {
        ctx.clearRect(0, 0, w, hCanvas);
        for (let i = 0; i < particles.length; i++) {
          const p = particles[i];
          p.x += p.vx;
          p.y += p.vy;
          if (p.x < 0) p.x = w;
          if (p.x > w) p.x = 0;
          if (p.y < 0) p.y = hCanvas;
          if (p.y > hCanvas) p.y = 0;

          ctx.save();
          ctx.globalAlpha = p.alpha;
          if (pType === "snow") {
            ctx.fillStyle = "#f1f5f9";
            ctx.shadowColor = "#38bdf8";
            ctx.shadowBlur = 6;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fill();
          } else if (pType === "embers") {
            ctx.fillStyle = i % 2 === 0 ? "#fb923c" : "#fde047";
            ctx.shadowColor = "#ef4444";
            ctx.shadowBlur = 10;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fill();
          } else if (pType === "blood_rain") {
            ctx.strokeStyle = "#ef4444";
            ctx.lineWidth = 1.4;
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p.x - 1.5, p.y + 11);
            ctx.stroke();
          } else {
            ctx.fillStyle = "#fde047";
            ctx.shadowColor = "#f59e0b";
            ctx.shadowBlur = 8;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r * 0.85, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.restore();
        }
        animId = requestAnimationFrame(render);
      };
      render();
      return () => cancelAnimationFrame(animId);
    }, [visual.particle]);

    const handleMouseMove = (e) => {
      const rect = e.currentTarget.getBoundingClientRect();
      const nx = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
      const ny = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
      setMouseOffset({ x: nx, y: ny });
    };

    return h("div", {
      onMouseMove: handleMouseMove,
      onMouseLeave: () => setMouseOffset({ x: 0, y: 0 }),
      className: "relative w-full rounded-2xl overflow-hidden select-none border-2 border-amber-500/45 shadow-[0_25px_70px_rgba(0,0,0,0.95)] flex flex-col justify-between mb-5",
      style: {
        minHeight: children ? "560px" : "390px",
        backgroundColor: "#06060a"
      }
    },
      // KATMAN 1: YÜKSEK ÇÖZÜNÜRLÜKLÜ BOYALI ARKA PLAN İLLÜSTRASYONU
      h("div", {
        className: "absolute inset-0 overflow-hidden pointer-events-none"
      },
        h("img", {
          key: visual.bg,
          src: visual.bg,
          alt: resolvedScene ? resolvedScene.title : "Sahne",
          className: "w-full h-full object-cover transition-transform duration-300 ease-out",
          style: {
            filter: visual.filter,
            transform: `scale(1.06) translate(${mouseOffset.x * -10}px, ${mouseOffset.y * -6}px)`
          }
        }),
        h("div", {
          className: "absolute inset-0",
          style: { background: visual.tint }
        }),
        h("div", {
          className: "absolute inset-0",
          style: {
            background: "linear-gradient(to bottom, rgba(5,5,9,0.75) 0%, rgba(5,5,9,0.06) 28%, rgba(5,5,9,0.25) 62%, rgba(5,5,9,0.95) 100%)"
          }
        })
      ),

      // KATMAN 2: HTML5 CANVAS ATMOSFERİK PARÇACIK KATMANI
      h("canvas", {
        ref: canvasRef,
        className: "absolute inset-0 w-full h-full pointer-events-none z-10"
      }),

      // ÜST SİNEMATİK SAHNE BAŞLIĞI & KONUM ROZETİ
      h("div", {
        className: "relative z-20 flex flex-wrap items-center justify-between gap-2 px-4 pt-3.5 pb-2"
      },
        h("div", { className: "flex items-center gap-2" },
          h("span", {
            className: "px-3 py-1 rounded-full text-[11px] royal-font font-bold uppercase tracking-widest bg-black/80 text-amber-300 border border-amber-500/45 backdrop-blur-md shadow-lg"
          }, `📍 ${resolvedScene ? resolvedScene.location : visual.subtitle}`),
          h("span", {
            className: "hidden sm:inline-block px-2.5 py-1 rounded-full text-[10px] font-semibold bg-black/65 text-amber-100/80 border border-white/15 backdrop-blur-md"
          }, visual.subtitle)
        ),
        h("div", {
          className: "px-3 py-1 rounded-full text-[10px] royal-font font-bold tracking-wider bg-black/80 text-amber-200 border border-amber-500/35 backdrop-blur-md"
        }, `🎭 Görsel Roman Sahnesi (${cast.length} Karakter)`)
      ),

      // KATMAN 3: GÖRSEL ROMAN SAHNE ÜSTÜ KARAKTER PORTRELERİ (STANDING BUST CARDS)
      h("div", {
        className: "relative z-20 flex items-end justify-center gap-2.5 sm:gap-5 px-3 pt-4 pb-3 my-auto transition-transform duration-300",
        style: {
          transform: `translate(${mouseOffset.x * 6}px, ${mouseOffset.y * 3}px)`
        }
      },
        cast.map((cId) =>
          h(CharacterPortraitSVG, {
            key: cId,
            charId: cId,
            size: cast.length <= 3 ? 132 : 112,
            speaking: currentSpeaker === cId,
            variant: "vn-stage",
            onClick: () => onSelectSpeaker && onSelectSpeaker(cId)
          })
        )
      ),

      // KATMAN 4: ALT GÖRSEL ROMAN DİYALOG KUTUSU (CHILDREN)
      children && h("div", { className: "relative z-30 w-full px-3 pb-3 md:px-5 md:pb-4" }, children)
    );
  }

  // ---------------------------------------------------------------------------
  // 4. 18 EYALETLİ BÜYÜK DÜNYA ATLASI (`GrandMap2D`)
  // Boyalı Kıta Haritası (./assets/bg_world_map.jpg) Üzerinde 18 Stratejik Bölge
  // ---------------------------------------------------------------------------
  const MAP_COORDS = {
    silver_peaks: { x: 385, y: 145, icon: "⚒️" },
    northern_high_peaks: { x: 525, y: 92, icon: "🏔️" },
    northern_mithril_depths: { x: 685, y: 138, icon: "💎" },

    furry_storm_isles: { x: 205, y: 215, icon: "⚓" },
    furry_senate_capital: { x: 225, y: 310, icon: "🏛️" },
    furry_coast: { x: 332, y: 300, icon: "🚢" },

    dark_forest: { x: 405, y: 215, icon: "🌲" },
    baron_ironkeep: { x: 495, y: 182, icon: "⛓️" },
    capital_lalo: { x: 530, y: 258, icon: "👑" },
    imperial_riverlands: { x: 455, y: 310, icon: "🌉" },
    eastern_pass: { x: 625, y: 255, icon: "🛡️" },
    golden_plains: { x: 575, y: 338, icon: "🌾" },

    doxe_border: { x: 445, y: 398, icon: "⚖️" },
    doxe_holy_city: { x: 565, y: 432, icon: "☀️" },
    doxe_vineyards: { x: 678, y: 418, icon: "🧪" },

    vampire_citadel: { x: 745, y: 248, icon: "🩸" },
    elf_shadow_spire: { x: 845, y: 205, icon: "🔮" },
    blood_necropolis: { x: 815, y: 338, icon: "💀" }
  };

  const OWNER_COLORS = {
    player: { fill: "#d97706", stroke: "#fde047", badge: "👑 Prens Tutu (Lalo)" },
    lalo: { fill: "#d97706", stroke: "#fde047", badge: "👑 Prens Tutu (Lalo)" },
    brothers: { fill: "#ea580c", stroke: "#fdba74", badge: "⛓️ Asi Baronlar (Anzak & Adem)" },
    rebel: { fill: "#ea580c", stroke: "#fdba74", badge: "⛓️ Asi Baronlar" },
    furry: { fill: "#059669", stroke: "#6ee7b7", badge: "🐺 Furry Cumhuriyeti" },
    doxe: { fill: "#4f46e5", stroke: "#c7d2fe", badge: "☀️ DOXE Kutsal Krallığı" },
    tribes: { fill: "#0284c7", stroke: "#7dd3fc", badge: "🏔️ Kuzey Dağ Klanları" },
    north: { fill: "#0284c7", stroke: "#7dd3fc", badge: "🏔️ Kuzey Dağ Klanları" },
    vampire: { fill: "#b91c1c", stroke: "#fca5a5", badge: "🩸 Vampir-Kara Elf İttifakı" }
  };

  function GrandMap2D({ provinces, selectedProvince, selectedProvinceId, onSelectProvince }) {
    const [atmosphere, setAtmosphere] = useState("day");

    // provinces nesne veya dizi olabilir, diziye çevir
    const provList = useMemo(() => {
      if (!provinces) return [];
      return Array.isArray(provinces) ? provinces : Object.values(provinces);
    }, [provinces]);

    const activeId = selectedProvince || selectedProvinceId || "capital_lalo";
    const selectedProv = provList.find(p => p.id === activeId) || provList[0];

    const edges = useMemo(() => {
      const list = [];
      const seen = new Set();
      provList.forEach(p => {
        const c1 = MAP_COORDS[p.id];
        if (!c1 || !Array.isArray(p.neighbors)) return;
        p.neighbors.forEach(nId => {
          const c2 = MAP_COORDS[nId];
          if (!c2) return;
          const key = [p.id, nId].sort().join("--");
          if (seen.has(key)) return;
          seen.add(key);
          const nProv = provList.find(x => x.id === nId);
          const bothPlayer = (p.owner === "player" || p.owner === "lalo") && nProv && (nProv.owner === "player" || nProv.owner === "lalo");
          const isBlockaded = Boolean(p.isBlockaded || p.isCutOff || (nProv && (nProv.isBlockaded || nProv.isCutOff)));
          list.push({ key, x1: c1.x, y1: c1.y, x2: c2.x, y2: c2.y, bothPlayer, isBlockaded });
        });
      });
      return list;
    }, [provList]);

    const atmoFilter =
      atmosphere === "night"
        ? "brightness(0.74) contrast(1.15) hue-rotate(195deg) saturate(0.85)"
        : atmosphere === "blood"
        ? "brightness(0.82) contrast(1.22) sepia(0.42) hue-rotate(-35deg) saturate(1.45)"
        : "brightness(0.98) contrast(1.08) saturate(1.08)";

    return h("div", {
      className: "relative w-full rounded-2xl overflow-hidden border-2 border-amber-500/45 shadow-[0_20px_60px_rgba(0,0,0,0.95)] bg-[#07090e] select-none"
    },
      // ÜST HARİTA KONTROL & ATMOSFER ÇUBUĞU
      h("div", {
        className: "flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 bg-black/85 border-b border-amber-500/30 backdrop-blur-md"
      },
        h("div", { className: "flex items-center gap-2" },
          h("span", { className: "royal-font font-black text-xs md:text-sm text-amber-300 tracking-wider" },
            "🗺️ BÜYÜK DÜNYA ATLASI (18 EYALETLİ BOYALI KITA HARİTASI)"
          )
        ),
        h("div", { className: "flex items-center gap-1.5" },
          [
            { id: "day", label: "☀️ Gündüz" },
            { id: "night", label: "🌙 Gece" },
            { id: "blood", label: "🩸 Kanlı Ay" }
          ].map(m =>
            h("button", {
              key: m.id,
              onClick: () => setAtmosphere(m.id),
              className: `px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                atmosphere === m.id
                  ? "bg-amber-500 text-black shadow-[0_0_12px_rgba(245,158,11,0.6)]"
                  : "bg-stone-900 text-stone-300 hover:bg-stone-800 border border-white/10"
              }`
            }, m.label)
          )
        )
      ),

      // HARİTA SAHNESİ (BOYALI KITA HARİTASI + INTERAKTİF SVG DÜĞÜMLERİ)
      h("div", { className: "relative w-full aspect-[16/9] overflow-hidden bg-[#06080e]" },
        h("img", {
          src: "./assets/bg_world_map.jpg",
          alt: "Büyük Kıta Atlası",
          className: "absolute inset-0 w-full h-full object-cover transition-all duration-700",
          style: { filter: atmoFilter }
        }),

        h("div", {
          className: "absolute inset-0 pointer-events-none transition-all duration-700",
          style: {
            background:
              atmosphere === "blood"
                ? "radial-gradient(circle at 75% 30%, rgba(220,38,38,0.28), rgba(10,2,4,0.45))"
                : atmosphere === "night"
                ? "radial-gradient(circle at 50% 30%, rgba(30,58,138,0.22), rgba(2,6,23,0.52))"
                : "radial-gradient(circle at 50% 40%, rgba(251,191,36,0.06), rgba(0,0,0,0.24))"
          }
        }),

        h("svg", {
          viewBox: "0 0 1000 560",
          className: "relative z-10 w-full h-full"
        },
          h("defs", null,
            h("filter", { id: "nodeGlow", x: "-40%", y: "-40%", width: "180%", height: "180%" },
              h("feGaussianBlur", { stdDeviation: "4", result: "blur" }),
              h("feMerge", null,
                h("feMergeNode", { in: "blur" }),
                h("feMergeNode", { in: "SourceGraphic" })
              )
            )
          ),

          // Krallık Bölge Başlık Etiketleri
          h("text", { x: 525, y: 52, textAnchor: "middle", fill: "#e0f2fe", fontSize: 13, fontWeight: "800", className: "royal-font", style: { textShadow: "0 2px 6px #000" } }, "🏔️ KUZEY DAĞ KLANLARI"),
          h("text", { x: 215, y: 178, textAnchor: "middle", fill: "#a7f3d0", fontSize: 12, fontWeight: "800", className: "royal-font", style: { textShadow: "0 2px 6px #000" } }, "🐺 FURRY CUMHURİYETİ"),
          h("text", { x: 530, y: 226, textAnchor: "middle", fill: "#fef08a", fontSize: 13, fontWeight: "800", className: "royal-font", style: { textShadow: "0 2px 6px #000" } }, "👑 LALO İMPARATORLUĞU"),
          h("text", { x: 565, y: 482, textAnchor: "middle", fill: "#fde047", fontSize: 13, fontWeight: "800", className: "royal-font", style: { textShadow: "0 2px 6px #000" } }, "☀️ DOXE KUTSAL KRALLIĞI"),
          h("text", { x: 805, y: 168, textAnchor: "middle", fill: "#fca5a5", fontSize: 12, fontWeight: "800", className: "royal-font", style: { textShadow: "0 2px 6px #000" } }, "🩸 VAMPİR & KARA ELF İTTİFAKI"),

          // İkmal Hatları ve Ticaret Yolları
          edges.map(e =>
            h("g", { key: e.key },
              h("line", {
                x1: e.x1,
                y1: e.y1,
                x2: e.x2,
                y2: e.y2,
                stroke: "rgba(0,0,0,0.75)",
                strokeWidth: 5
              }),
              h("line", {
                x1: e.x1,
                y1: e.y1,
                x2: e.x2,
                y2: e.y2,
                stroke: e.isBlockaded ? "#ef4444" : e.bothPlayer ? "#fbbf24" : "#cbd5e1",
                strokeWidth: e.bothPlayer ? 2.8 : 1.8,
                strokeDasharray: e.isBlockaded ? "4 6" : "8 5",
                className: "dash-flow",
                opacity: e.bothPlayer ? 0.95 : 0.65
              })
            )
          ),

          // Batı Denizinde Yüzen Animasyonlu 2D Furry Kalyonları
          h("g", { transform: "translate(270, 252)", className: "animate-pulse" },
            h("circle", { cx: 0, cy: 0, r: 12, fill: "rgba(6,78,59,0.8)", stroke: "#34d399", strokeWidth: 1.5 }),
            h("text", { x: 0, y: 4, textAnchor: "middle", fontSize: 12 }, "⛵")
          ),
          h("g", { transform: "translate(168, 275)" },
            h("circle", { cx: 0, cy: 0, r: 11, fill: "rgba(6,78,59,0.8)", stroke: "#34d399", strokeWidth: 1.5 }),
            h("text", { x: 0, y: 4, textAnchor: "middle", fontSize: 11 }, "⛵")
          ),

          // Karada İlerleyen Kraliyet Ticaret Kervanı
          h("g", { transform: "translate(492, 282)" },
            h("circle", { cx: 0, cy: 0, r: 10, fill: "rgba(120,53,15,0.88)", stroke: "#fbbf24", strokeWidth: 1.5 }),
            h("text", { x: 0, y: 4, textAnchor: "middle", fontSize: 10 }, "🐪")
          ),

          // 18 Eyalet Düğümleri (Nodes)
          provList.map(prov => {
            const coord = MAP_COORDS[prov.id] || { x: 500, y: 280, icon: "🏰" };
            const theme = OWNER_COLORS[prov.owner] || OWNER_COLORS.player;
            const isSelected = prov.id === activeId;
            const isCutOff = Boolean(prov.isBlockaded || prov.isCutOff);
            const radius = prov.isCapital ? 20 : 15;

            return h("g", {
              key: prov.id,
              transform: `translate(${coord.x}, ${coord.y})`,
              onClick: () => {
                if (window.PrinceTutu && window.PrinceTutu.Sound) window.PrinceTutu.Sound.play("click");
                if (onSelectProvince) onSelectProvince(prov.id);
              },
              className: "cursor-pointer group"
            },
              isSelected && h("circle", {
                cx: 0,
                cy: 0,
                r: radius + 9,
                fill: "none",
                stroke: "#fde047",
                strokeWidth: 3,
                strokeDasharray: "6 4",
                filter: "url(#nodeGlow)"
              }),

              isCutOff && h("circle", {
                cx: 0,
                cy: 0,
                r: radius + 6,
                fill: "none",
                stroke: "#ef4444",
                strokeWidth: 2.5,
                strokeDasharray: "3 3"
              }),

              h("circle", {
                cx: 0,
                cy: 0,
                r: radius,
                fill: theme.fill,
                stroke: isSelected ? "#ffffff" : theme.stroke,
                strokeWidth: prov.isCapital ? 3 : 2,
                filter: "url(#nodeGlow)"
              }),

              h("text", {
                x: 0,
                y: 5,
                textAnchor: "middle",
                fontSize: prov.isCapital ? 15 : 12
              }, coord.icon || (prov.isCapital ? "👑" : "🏰")),

              // Garnizon Rozeti (Sağ Üst)
              h("g", { transform: `translate(${radius - 2}, ${-radius + 2})` },
                h("circle", { cx: 0, cy: 0, r: 9.5, fill: "#090d16", stroke: theme.stroke, strokeWidth: 1.5 }),
                h("text", {
                  x: 0,
                  y: 3.5,
                  textAnchor: "middle",
                  fill: "#ffffff",
                  fontSize: 9.5,
                  fontWeight: "900"
                }, prov.garrison)
              ),

              // Sur Seviyesi Rozeti (Sol Üst)
              h("g", { transform: `translate(${-radius + 2}, ${-radius + 2})` },
                h("circle", { cx: 0, cy: 0, r: 8.5, fill: "#1e293b", stroke: "#94a3b8", strokeWidth: 1.2 }),
                h("text", {
                  x: 0,
                  y: 3,
                  textAnchor: "middle",
                  fill: "#e2e8f0",
                  fontSize: 8.5,
                  fontWeight: "800"
                }, `S${prov.fortLevel || 1}`)
              ),

              // Eyalet İsim Plakası (Alt)
              h("g", { transform: `translate(0, ${radius + 13})` },
                h("rect", {
                  x: -64,
                  y: -10,
                  width: 128,
                  height: 17,
                  rx: 5,
                  fill: isSelected ? "rgba(245,158,11,0.96)" : "rgba(7,9,14,0.88)",
                  stroke: isSelected ? "#fef08a" : "rgba(255,255,255,0.22)",
                  strokeWidth: 1
                }),
                h("text", {
                  x: 0,
                  y: 2,
                  textAnchor: "middle",
                  fill: isSelected ? "#000000" : "#f8fafc",
                  fontSize: 9.5,
                  fontWeight: "800"
                }, prov.name.length > 18 ? prov.name.slice(0, 17) + "…" : prov.name)
              )
            );
          })
        )
      ),

      // ALT HARİTA LEJANTI & SEÇİLİ EYALET ÖZETİ
      h("div", {
        className: "flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 bg-black/90 border-t border-amber-500/30 text-xs"
      },
        h("div", { className: "flex flex-wrap items-center gap-3" },
          ["player", "brothers", "furry", "doxe", "tribes", "vampire"].map((k) => {
            const v = OWNER_COLORS[k];
            return h("span", { key: k, className: "flex items-center gap-1.5 text-stone-300 font-semibold" },
              h("span", { className: "w-3 h-3 rounded-full inline-block", style: { backgroundColor: v.fill, border: `1px solid ${v.stroke}` } }),
              v.badge
            );
          })
        ),
        selectedProv && h("div", { className: "text-amber-300 font-bold" },
          `Seçili: ${selectedProv.name} • Garnizon: ${selectedProv.garrison} • Vergi: +${selectedProv.isBlockaded ? 0 : (selectedProv.taxIncome || selectedProv.tax || 0)} 💰`
        )
      )
    );
  }

  // ---------------------------------------------------------------------------
  // 5. 2D TAKTİKSEL MUHAREBE MEYDANI (`Battle2DArena`)
  // ---------------------------------------------------------------------------
  function Battle2DArena({ battleState }) {
    if (!battleState) return null;
    const fx = battleState.lastEffect || battleState.lastProjectileType;
    const isVampireBattle = Boolean(battleState.isVampireEnemy);
    const bgImg = isVampireBattle ? "./assets/bg_vampire_citadel.jpg" : "./assets/bg_eastern_pass.jpg";
    const pRolls = battleState.playerDice || battleState.lastPlayerRolls || [6, 5, 4];
    const eRolls = battleState.enemyDice || battleState.lastEnemyRolls || [5, 4];
    const maxP = Math.max(1, battleState.maxPlayerTroops || battleState.initialPlayerTroops || 20);
    const maxE = Math.max(1, battleState.maxEnemyTroops || battleState.initialEnemyTroops || 20);

    return h("div", {
      className: `relative w-full rounded-2xl overflow-hidden border-2 border-amber-500/45 shadow-2xl mb-4 select-none ${
        fx && fx !== "none" ? "screen-shake" : ""
      }`,
      style: { minHeight: "260px", backgroundColor: "#09070a" }
    },
      h("img", {
        src: bgImg,
        alt: "Muharebe Meydanı",
        className: "absolute inset-0 w-full h-full object-cover opacity-60"
      }),
      h("div", {
        className: "absolute inset-0",
        style: {
          background: "linear-gradient(90deg, rgba(6,15,28,0.88) 0%, rgba(12,8,10,0.48) 50%, rgba(35,6,10,0.88) 100%)"
        }
      }),

      // Mermi & Yetenek Görsel Efekt Katmanı
      (fx === "archer_volley" || fx === "arrows") && h("div", {
        className: "absolute inset-0 pointer-events-none flex items-center justify-center z-20"
      },
        h("div", { className: "px-5 py-2 rounded-full bg-emerald-950/90 border border-emerald-400 text-emerald-300 royal-font font-black text-sm animate-bounce shadow-[0_0_30px_rgba(16,185,129,0.8)]" },
          "🏹 FURRY NİŞANCILARI YAYLIM ATEŞİ!"
        )
      ),
      (fx === "artillery" || fx === "cannon") && h("div", {
        className: "absolute inset-0 pointer-events-none flex items-center justify-center z-20"
      },
        h("div", { className: "px-5 py-2 rounded-full bg-orange-950/90 border border-orange-400 text-orange-200 royal-font font-black text-sm animate-bounce shadow-[0_0_35px_rgba(249,115,22,0.9)]" },
          "💣 KRALİYET TOPÇU BOMBARDIMANI!"
        )
      ),
      (fx === "paladin_purge" || fx === "holy") && h("div", {
        className: "absolute inset-0 pointer-events-none flex items-center justify-center z-20"
      },
        h("div", { className: "px-5 py-2 rounded-full bg-amber-950/90 border border-yellow-300 text-yellow-200 royal-font font-black text-sm animate-pulse shadow-[0_0_40px_rgba(253,224,71,0.95)]" },
          "✨ DOXE KUTSAL IŞIK ARINDIRMASI!"
        )
      ),
      (fx === "warcry" || fx === "berserk") && h("div", {
        className: "absolute inset-0 pointer-events-none flex items-center justify-center z-20"
      },
        h("div", { className: "px-5 py-2 rounded-full bg-red-950/90 border border-red-400 text-red-200 royal-font font-black text-sm animate-bounce shadow-[0_0_35px_rgba(239,68,68,0.9)]" },
          "🪓 KUZEY KLANLARI SAVAŞ NARASI!"
        )
      ),

      h("div", { className: "relative z-10 grid grid-cols-1 md:grid-cols-3 gap-4 p-4 items-center" },
        // SOL CEPHE: PRENS TUTU KOALİSYONU
        h("div", { className: "flex items-center gap-3 bg-black/75 p-3.5 rounded-xl border border-amber-500/40 backdrop-blur-md" },
          h(CharacterPortraitSVG, { charId: "tutu", size: 80, active: true }),
          h("div", { className: "flex-1 min-w-0" },
            h("div", { className: "text-[10px] font-bold uppercase tracking-widest text-amber-400" }, "👑 İmparatorluk Koalisyonu"),
            h("div", { className: "royal-font font-black text-base text-white truncate" }, "Prens Tutu Ordusu"),
            h("div", { className: "mt-1.5 w-full h-3 bg-stone-900 rounded-full overflow-hidden border border-amber-500/30" },
              h("div", {
                className: "h-full bg-gradient-to-r from-amber-600 to-yellow-400 transition-all duration-500",
                style: { width: `${Math.min(100, Math.max(5, (battleState.playerTroops / maxP) * 100))}%` }
              })
            ),
            h("div", { className: "mt-1 flex items-center justify-between text-xs font-bold text-amber-200" },
              h("span", null, `⚔️ ${battleState.playerTroops} Tabur`),
              h("span", { className: "text-cyan-300" }, `🎖️ ${battleState.commandPoints || 0} CP`)
            )
          )
        ),

        // ORTA: 2D ANİMASYONLU ZARLAR & MONTE CARLO ZAFER YÜZDESİ
        h("div", { className: "flex flex-col items-center justify-center bg-black/80 p-3.5 rounded-xl border border-amber-500/30 backdrop-blur-md" },
          h("div", { className: "text-[11px] royal-font font-bold uppercase tracking-widest text-amber-300 mb-2" },
            `🎲 Tur ${battleState.round || 1} • Zafer Şansı: %${battleState.winProbability || 50}`
          ),
          h("div", { className: "flex items-center gap-3" },
            h("div", { className: "flex items-center gap-1.5" },
              pRolls.map((d, idx) =>
                h("div", {
                  key: `p-${idx}`,
                  className: `w-9 h-9 rounded-lg flex items-center justify-center royal-font font-black text-base border dice-tumble ${
                    d >= 6
                      ? "bg-amber-400 text-black border-yellow-200 shadow-[0_0_15px_rgba(251,191,36,0.9)]"
                      : "bg-stone-900 text-amber-200 border-amber-500/50"
                  }`
                }, d)
              )
            ),
            h("span", { className: "royal-font font-black text-xs text-red-400" }, "VS"),
            h("div", { className: "flex items-center gap-1.5" },
              eRolls.map((d, idx) =>
                h("div", {
                  key: `e-${idx}`,
                  className: "w-9 h-9 rounded-lg flex items-center justify-center royal-font font-black text-base bg-red-950 text-red-200 border border-red-500/60 dice-tumble"
                }, d)
              )
            )
          )
        ),

        // SAĞ CEPHE: DÜŞMAN ORDUSU
        h("div", { className: "flex items-center gap-3 bg-black/75 p-3.5 rounded-xl border border-red-500/40 backdrop-blur-md" },
          h("div", { className: "flex-1 min-w-0 text-right" },
            h("div", { className: "text-[10px] font-bold uppercase tracking-widest text-red-400" }, "💀 Düşman Cephesi"),
            h("div", { className: "royal-font font-black text-sm text-white truncate" }, battleState.enemyFactionName || battleState.enemyName || "Düşman Lejyonu"),
            h("div", { className: "mt-1.5 w-full h-3 bg-stone-900 rounded-full overflow-hidden border border-red-500/30" },
              h("div", {
                className: "h-full bg-gradient-to-r from-red-700 to-rose-500 transition-all duration-500 ml-auto",
                style: { width: `${Math.min(100, Math.max(5, (battleState.enemyTroops / maxE) * 100))}%` }
              })
            ),
            h("div", { className: "mt-1 flex items-center justify-between text-xs font-bold text-red-200" },
              h("span", null, `📍 ${battleState.targetProvinceName || "Cephe"}`),
              h("span", null, `🩸 ${battleState.enemyTroops} Tabur`)
            )
          ),
          h(CharacterPortraitSVG, { charId: isVampireBattle ? "malakor" : "anzak", size: 80, active: true })
        )
      )
    );
  }

  // ---------------------------------------------------------------------------
  // 6. 2D YAN PROFİL KILIÇ DÜELLOSU ARENASI (`Duel2DArena`)
  // ---------------------------------------------------------------------------
  function Duel2DArena({ duelState }) {
    if (!duelState) return null;
    const isMalakor = duelState.opponentId === "malakor" || (duelState.opponentName || "").toLowerCase().includes("malakor");
    const oppCharId = isMalakor ? "malakor" : "anzak";
    const fx = duelState.lastEffect || duelState.lastActionType;
    const isExec = fx === "royal_execution" || fx === "execution";

    const pHP = duelState.playerHP !== undefined ? duelState.playerHP : (duelState.playerHp || 100);
    const maxPHP = duelState.maxPlayerHP || duelState.maxPlayerHp || 100;
    const eHP = duelState.anzakHP !== undefined ? duelState.anzakHP : (duelState.enemyHp || 100);
    const maxEHP = duelState.maxAnzakHP || duelState.maxEnemyHp || 100;
    const pStam = duelState.stamina !== undefined ? duelState.stamina : (duelState.playerStamina || 100);
    const maxStam = duelState.maxStamina || 100;
    const pFocus = duelState.focus !== undefined ? duelState.focus : (duelState.playerFocus || 0);

    const stanceLabels = {
      aggressive: "🔥 Saldırgan Duruş",
      iron_guard: "🛡️ Demir Muhafız",
      shadow_dancer: "🌙 Gölge Dansçısı"
    };

    return h("div", {
      className: `relative w-full rounded-2xl overflow-hidden border-2 border-amber-500/45 shadow-2xl mb-4 select-none ${
        fx && fx !== "none" ? "screen-shake" : ""
      } ${isExec ? "execution-flash" : ""}`,
      style: { minHeight: "280px", backgroundColor: "#08060c" }
    },
      h("img", {
        src: "./assets/bg_duel_arena.jpg",
        alt: "Düello Arenası",
        className: "absolute inset-0 w-full h-full object-cover opacity-65"
      }),
      h("div", {
        className: "absolute inset-0",
        style: {
          background: "linear-gradient(90deg, rgba(6,10,20,0.88) 0%, rgba(10,6,12,0.35) 50%, rgba(30,6,10,0.88) 100%)"
        }
      }),

      isExec && h("div", {
        className: "absolute inset-0 pointer-events-none flex items-center justify-center z-20 bg-amber-500/20"
      },
        h("div", {
          className: "px-6 py-2.5 rounded-full bg-black/90 border-2 border-yellow-300 text-yellow-300 royal-font font-black text-base shadow-[0_0_50px_rgba(250,204,21,1)] animate-bounce"
        }, "⚡ İMPARATORLUK İNFAZ DARBESİ!")
      ),

      h("div", { className: "relative z-10 grid grid-cols-1 md:grid-cols-3 gap-4 p-4 items-center" },
        // SOL KÖŞE: PRENS TUTU
        h("div", { className: "flex items-center gap-3.5 bg-black/75 p-3 rounded-2xl border border-amber-500/45 backdrop-blur-md" },
          h(CharacterPortraitSVG, { charId: "tutu", size: 96, speaking: true, variant: "vn-stage" }),
          h("div", { className: "flex-1 min-w-0 space-y-1.5" },
            h("div", { className: "royal-font font-black text-sm text-amber-300" }, "👑 Prens Tutu"),
            h("div", null,
              h("div", { className: "flex justify-between text-[11px] font-bold text-emerald-200" },
                h("span", null, "❤️ Can"),
                h("span", null, `${pHP}/${maxPHP}`)
              ),
              h("div", { className: "w-full h-2.5 bg-stone-900 rounded-full overflow-hidden border border-emerald-500/30" },
                h("div", {
                  className: "h-full bg-gradient-to-r from-emerald-600 to-emerald-400 transition-all duration-300",
                  style: { width: `${Math.max(0, Math.min(100, (pHP / maxPHP) * 100))}%` }
                })
              )
            ),
            h("div", null,
              h("div", { className: "flex justify-between text-[11px] font-bold text-sky-200" },
                h("span", null, "⚡ Nefes"),
                h("span", null, `${pStam}/${maxStam}`)
              ),
              h("div", { className: "w-full h-2 bg-stone-900 rounded-full overflow-hidden border border-sky-500/30" },
                h("div", {
                  className: "h-full bg-gradient-to-r from-sky-600 to-cyan-400 transition-all duration-300",
                  style: { width: `${Math.max(0, Math.min(100, (pStam / maxStam) * 100))}%` }
                })
              )
            ),
            h("div", null,
              h("div", { className: "flex justify-between text-[11px] font-bold text-amber-200" },
                h("span", null, "🔥 Odak"),
                h("span", null, `${pFocus}%`)
              ),
              h("div", { className: "w-full h-2 bg-stone-900 rounded-full overflow-hidden border border-amber-500/30" },
                h("div", {
                  className: "h-full bg-gradient-to-r from-amber-500 to-yellow-300 transition-all duration-300",
                  style: { width: `${Math.max(0, Math.min(100, pFocus))}%` }
                })
              )
            )
          )
        ),

        // ORTA: KILIÇ ÇARPIŞMASI & DURUŞ / NİYET
        h("div", { className: "flex flex-col items-center justify-center text-center bg-black/80 p-3.5 rounded-2xl border border-amber-500/35 backdrop-blur-md" },
          h("div", { className: "text-3xl mb-1" }, "⚔️"),
          h("div", { className: "royal-font font-black text-xs uppercase tracking-widest text-amber-300 mb-1.5" },
            `RAUNT ${duelState.round || 1}`
          ),
          h("div", { className: "px-2.5 py-1 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-200 text-[11px] font-bold mb-2" },
            stanceLabels[duelState.stance] || "🔥 Saldırgan Duruş"
          ),
          duelState.enemyStunned && h("div", {
            className: "px-3 py-1 rounded-lg bg-yellow-500/25 border border-yellow-300 text-yellow-200 text-xs font-extrabold animate-pulse"
          }, "💫 RAKİP SERSEMLEDİ!")
        ),

        // SAĞ KÖŞE: RAKİP (ANZAK VEYA MALAKOR)
        h("div", { className: "flex items-center gap-3.5 bg-black/75 p-3 rounded-2xl border border-red-500/45 backdrop-blur-md" },
          h("div", { className: "flex-1 min-w-0 space-y-2 text-right" },
            h("div", { className: "royal-font font-black text-sm text-red-300" }, duelState.opponentName || "Komutan Anzak"),
            h("div", null,
              h("div", { className: "flex justify-between text-[11px] font-bold text-red-200" },
                h("span", null, `${eHP}/${maxEHP}`),
                h("span", null, "🩸 Rakip Canı")
              ),
              h("div", { className: "w-full h-2.5 bg-stone-900 rounded-full overflow-hidden border border-red-500/30" },
                h("div", {
                  className: "h-full bg-gradient-to-r from-red-700 to-rose-500 transition-all duration-300 ml-auto",
                  style: { width: `${Math.max(0, Math.min(100, (eHP / maxEHP) * 100))}%` }
                })
              )
            ),
            h("div", { className: "text-[11px] text-amber-200/80 font-medium" },
              duelState.hasMoonlightSword
                ? "🗡️ Ayışığı Kılıcı (+14)"
                : duelState.hasSilverDagger
                ? "🗡️ Gümüş Hançer (+8)"
                : "⚔️ Kraliyet Kılıcı"
            )
          ),
          h(CharacterPortraitSVG, { charId: oppCharId, size: 96, speaking: true, variant: "vn-stage" })
        )
      )
    );
  }

  // Hem window.PrinceTutu hem de window.Engine2D üzerine kaydet
  window.PrinceTutu.CHARACTER_META = CHARACTER_META;
  window.PrinceTutu.CharacterPortraitSVG = CharacterPortraitSVG;
  window.PrinceTutu.Story2DStage = Story2DStage;
  window.PrinceTutu.GrandMap2D = GrandMap2D;
  window.PrinceTutu.Battle2DArena = Battle2DArena;
  window.PrinceTutu.Duel2DArena = Duel2DArena;
  window.PrinceTutu.parseSceneIntoVNBeats = parseSceneIntoVNBeats;
  window.PrinceTutu.detectSceneCast = detectSceneCast;

  window.Engine2D = {
    CHARACTER_META,
    CharacterPortraitSVG,
    Story2DStage,
    GrandMap2D,
    Battle2DArena,
    Duel2DArena,
    parseSceneIntoVNBeats,
    detectSceneCast
  };
})();
