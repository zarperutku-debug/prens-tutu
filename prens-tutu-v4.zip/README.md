# 👑 Prens Tutu: Gölgelerin Tacı (v4.0 Modüler Strateji & RPG Motoru)

**Prens Tutu: Gölgelerin Tacı**, tarayıcı üzerinde hiçbir harici sunucu veya ses dosyası gerektirmeden çalışan; politik entrika, 8 bölgeli interaktif jeopolitik harita yönetimi, 3v2 Monte Carlo olasılıklı Risk muharebe motoru ve taktiksel kılıç düellosunu birleştiren Türkçe bir strateji/RPG oyunudur.

## 🚀 v4.0 Güncellemesi ile Gelen Yenilikler

1. **Gerçekten Dallanan Hikaye Ağacı (20 Sahne & 7 Farklı Final):**
   - İmparatorun Özel Dairesi, Silah Avlusu, Saray Zindanları Sorgusu, Fısıltı Ormanı Suikastçı Baskını, Batı Furry Ticaret Senatosu, Güney DOXE Işık Mahkemesi, Kuzey Dağ Klanları Demir Ocağı, Güney Baronları İsyanı ve Gölge Kalesi Kuşatması eklendi.
   - **5 Zafer Finali** (Büyük Koalisyon, Gölge İmparator, Fatih Tutu, Üçlü Triumvirlik, Altın Terazi Meşrutiyet) + **2 Trajik Yenilgi Finali** (Kardeşlerin Saray Darbesi ve Başkentin Vampir İstilasıyla Düşüşü).
2. **Harita ve 3v2 Muharebe Motoru Tam Entegrasyonu:**
   - Harita üzerinden yaptığınız **Casus Sabotajları (`-3 Garnizon`)** ve kendi sınır kalelerinize yaptığınız **Garnizon Takviyeleri** artık doğrudan 3v2 Savaş Simülatöründeki tabur sayılarını etkiler.
   - Harita üzerinden hem Vampir kalesine hem de Anzak ve Adem'in kontrolündeki **Güney Bereket Ovaları** ve **Fısıltı Ormanı** eyaletlerine askeri sefer düzenlenebilir.
3. **Stratejik Emir Hakkı (AP) ve 8 Kraliyet Fermanı:**
   - Her tur haritada **2 AP (Emir Hakkı)** bulunur (`İmparatorluk Strateji Akademisi` fermanıyla tur başına **3 AP**'ye çıkar).
   - Muharebe ekranına **🛡️ Kalkan Duvarı** taktiği ve **⚖️ DOXE Kutsal Arındırma** aktif yeteneği eklendi.
4. **Dengelenmiş Stamina & Niyet Okuma Düellosu:**
   - Anzak ile düelloda her hamle Stamina harcar; *Ağır İndirme* -> *Siper & Kontra*, *Omuz Darbesi (Guard Break)* -> *Gümüş Hançer Saplaması*, *Öfkeli Kesik* -> *Psikolojik Sarsıntı* ile ezilir.
5. **Tur Başı Rastgele Saray Krizleri & Kaydet/Yükle (`localStorage`):**
   - Tur geçişlerinde dinamik kriz olayları tetiklenir ve üst menüden oyun kaydedilip yüklenebilir.

## 📂 Dosya Yapısı

- `index.html` — Uygulama giriş noktası ve stil tanımları
- `engine-core.js` — Web Audio prosedürel ses sentezleyici, 8 eyalet verisi, AP, rastgele olaylar, AI ve Save/Load motoru
- `data-story.js` — 8 Kraliyet Fermanı, 8 Lore & Rehber maddesi, 20 sahne ve 7 final
- `engine-combat.js` — Monte Carlo 3v2 zar muharebe motoru ve Anzak düello sistemi
- `ui-app.js` — React 18 bileşenleri, SVG harita ve modal arayüzleri
