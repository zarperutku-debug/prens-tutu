// ============================================================================
// PRENS TUTU: GÖLGELERİN TACI - MODÜL 1: ENGINE CORE (engine-core.js) v4.0
// İçerik: Web Audio Ses Motoru, 8 Eyaletli Jeopolitik Sistem, AP (Emir Hakkı),
//         Rakip AI, Rastgele Kriz Olayları, Darbe/İstila Kontrolü, Save/Load
// ============================================================================

window.PrinceTutu = window.PrinceTutu || {};

// ----------------------------------------------------------------------------
// 1. PROSEDÜREL WEB AUDIO SES MOTORU (Harici ses dosyası gerektirmez)
// ----------------------------------------------------------------------------
class ProceduralSoundEngine {
  constructor() {
    this.ctx = null;
    this.muted = false;
  }

  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) this.ctx = new AudioCtx();
    }
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume();
    }
  }

  play(type) {
    if (this.muted) return;
    try {
      this.init();
      if (!this.ctx) return;
      const now = this.ctx.currentTime;

      if (type === "click") {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(520, now);
        osc.frequency.exponentialRampToValueAtTime(240, now + 0.06);
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.linearRampToValueAtTime(0.01, now + 0.06);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now);
        osc.stop(now + 0.06);
      } else if (type === "coin") {
        [987.77, 1318.51].forEach((freq, idx) => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = "triangle";
          osc.frequency.setValueAtTime(freq, now + idx * 0.07);
          gain.gain.setValueAtTime(0.18, now + idx * 0.07);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.07 + 0.25);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start(now + idx * 0.07);
          osc.stop(now + idx * 0.07 + 0.25);
        });
      } else if (type === "sword") {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(1400, now);
        osc.frequency.exponentialRampToValueAtTime(180, now + 0.18);
        gain.gain.setValueAtTime(0.24, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.18);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now);
        osc.stop(now + 0.18);
      } else if (type === "dice") {
        [0, 0.05, 0.11, 0.16].forEach((offset) => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = "square";
          osc.frequency.setValueAtTime(300 + Math.random() * 400, now + offset);
          gain.gain.setValueAtTime(0.1, now + offset);
          gain.gain.exponentialRampToValueAtTime(0.01, now + offset + 0.03);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start(now + offset);
          osc.stop(now + offset + 0.03);
        });
      } else if (type === "horn") {
        [220, 277.18, 329.63].forEach((freq) => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = "sawtooth";
          osc.frequency.setValueAtTime(freq, now);
          gain.gain.setValueAtTime(0.01, now);
          gain.gain.linearRampToValueAtTime(0.1, now + 0.15);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.85);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start(now);
          osc.stop(now + 0.85);
        });
      } else if (type === "victory") {
        [261.63, 329.63, 392.0, 523.25].forEach((freq, idx) => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = "triangle";
          osc.frequency.setValueAtTime(freq, now + idx * 0.09);
          gain.gain.setValueAtTime(0.16, now + idx * 0.09);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.09 + 0.45);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start(now + idx * 0.09);
          osc.stop(now + idx * 0.09 + 0.45);
        });
      } else if (type === "alert" || type === "defeat") {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(195, now);
        osc.frequency.linearRampToValueAtTime(115, now + 0.35);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.35);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now);
        osc.stop(now + 0.35);
      }
    } catch (e) {
      // Ses kartı meşgulse sessizce geç
    }
  }
}

window.PrinceTutu.Sound = new ProceduralSoundEngine();

// ----------------------------------------------------------------------------
// 2. İMPARATORLUK EYALETLERİ VE STRATEJİK HARİTA VERİSİ (8 BÖLGE)
// ----------------------------------------------------------------------------
window.PrinceTutu.INITIAL_PROVINCES = {
  capital_lalo: {
    id: "capital_lalo",
    name: "Başkent Lalo",
    owner: "player", // 'player' | 'brothers' | 'vampire' | 'furry' | 'doxe' | 'tribes'
    x: 430,
    y: 255,
    neighbors: ["silver_peaks", "golden_plains", "furry_coast", "eastern_pass", "dark_forest"],
    garrison: 8,
    taxIncome: 35,
    unrest: 15,
    defenseBonus: 3,
    perk: "Altın Taht Merkezi (+3 Savunma Bonusu)",
    description: "Altın Taht'ın bulunduğu imparatorluk merkezi. Saray entrikalarının ve loncaların kalbi."
  },
  eastern_pass: {
    id: "eastern_pass",
    name: "Doğu Kızıl Geçidi",
    owner: "player",
    x: 635,
    y: 235,
    neighbors: ["capital_lalo", "vampire_citadel", "dark_forest"],
    garrison: 7,
    taxIncome: 15,
    unrest: 25,
    defenseBonus: 3,
    perk: "Sınır Kalesi (Düşerse Başkent kuşatılır!)",
    description: "Vampir-Kara Elf İttifakı'nın istilasına karşı imparatorluğu koruyan stratejik kanyon."
  },
  vampire_citadel: {
    id: "vampire_citadel",
    name: "Gölge Kalesi (Vampir-Elf)",
    owner: "vampire",
    x: 795,
    y: 195,
    neighbors: ["eastern_pass", "dark_forest"],
    garrison: 13,
    taxIncome: 45,
    unrest: 10,
    defenseBonus: 4,
    perk: "Fetih Ödülü: Doğu Tehdidi Biter & +150 Altın",
    description: "Vampir Lordu Malakor ve Kara Elf büyücülerinin ordularını topladığı karanlık kale."
  },
  furry_coast: {
    id: "furry_coast",
    name: "Furry Ticaret Limanı",
    owner: "furry",
    x: 195,
    y: 265,
    neighbors: ["capital_lalo", "silver_peaks", "golden_plains"],
    garrison: 10,
    taxIncome: 50,
    unrest: 10,
    defenseBonus: 2,
    perk: "Müttefik Liman: Furry Keskin Nişancı Tedarikçisi",
    description: "Furry Cumhuriyeti'nin zengin baharat, barut ve keskin nişancı limanı."
  },
  golden_plains: {
    id: "golden_plains",
    name: "Güney Bereket Ovaları",
    owner: "brothers",
    x: 415,
    y: 410,
    neighbors: ["capital_lalo", "furry_coast", "doxe_border", "dark_forest"],
    garrison: 8,
    taxIncome: 35,
    unrest: 40,
    defenseBonus: 1,
    perk: "Fetih Ödülü: Anzak'ın Geliri Kesilir & +2 Piyade",
    description: "Anzak ve Adem'e bağlı köle baronlarının kontrolündeki geniş tarım arazileri."
  },
  doxe_border: {
    id: "doxe_border",
    name: "DOXE Kutsal Manastırı",
    owner: "doxe",
    x: 385,
    y: 530,
    neighbors: ["golden_plains"],
    garrison: 12,
    taxIncome: 35,
    unrest: 5,
    defenseBonus: 3,
    perk: "Müttefik Kalesi: DOXE Kutsal Paladin Merkezi",
    description: "Kölelik kaldırılmadığı için sınırlarını kapatan DOXE Kutsal Şövalyelerinin kalesi."
  },
  silver_peaks: {
    id: "silver_peaks",
    name: "Kuzey Dağ Kabileleri",
    owner: "tribes",
    x: 385,
    y: 95,
    neighbors: ["capital_lalo", "furry_coast"],
    garrison: 9,
    taxIncome: 25,
    unrest: 20,
    defenseBonus: 4,
    perk: "Müttefik Ocakları: Kuzey Çeliği ve Dağ Baltacıları",
    description: "Usta demircilerin ve vahşi baltacıların yaşadığı sarp dağlar."
  },
  dark_forest: {
    id: "dark_forest",
    name: "Fısıltı Ormanı",
    owner: "brothers",
    x: 590,
    y: 390,
    neighbors: ["capital_lalo", "eastern_pass", "vampire_citadel", "golden_plains"],
    garrison: 7,
    taxIncome: 25,
    unrest: 30,
    defenseBonus: 2,
    perk: "Fetih Ödülü: Adem'in Suikast Ağı Çöker (-25% Darbe)",
    description: "Adem'in paralı suikastçılarının ve kaçakçıların cirit attığı karanlık bölge."
  }
};

// ----------------------------------------------------------------------------
// 3. RASTGELE SARAY VE EYALET KRİZ OLAYLARI (RANDOM EVENTS)
// ----------------------------------------------------------------------------
window.PrinceTutu.RANDOM_EVENTS = [
  {
    id: "kitchen_poison",
    title: "🍷 Saray Mutfağında Zehir Şüphesi!",
    description: "9 yaşındaki küçük kız kardeşin nefes nefese yanına koştu: 'Tutu abi! Şarap mahzeninde Adem'in hizmetkarını babamızın akşam kupasına renksiz bir sıvı damlatırken gördüm!'",
    choices: [
      {
        text: "Hizmetkarı suçüstü yakalat ve kupayı Baş Danışman'a analiz ettir",
        effectText: "+8 İmparator, +6 Zeka, Kardeş Darbesi -12%",
        apply: (s) => {
          s.relationships.father = Math.min(100, s.relationships.father + 8);
          s.stats.intelligence = Math.min(100, s.stats.intelligence + 6);
          s.rivalState.brotherPlotProgress = Math.max(0, s.rivalState.brotherPlotProgress - 12);
          s.flags.knowsAboutCorruption = true;
        }
      },
      {
        text: "Şarabı Adem'in kendi ziyafet masasıyla gizlice değiştir!",
        effectText: "Adem kendi tuzağına düştü! Kardeş Darbesi -18%, -5 Ahlak",
        apply: (s) => {
          s.rivalState.brotherPlotProgress = Math.max(0, s.rivalState.brotherPlotProgress - 18);
          s.stats.moralStanding = Math.max(0, s.stats.moralStanding - 5);
          s.stats.politicalPower = Math.min(100, s.stats.politicalPower + 7);
        }
      }
    ]
  },
  {
    id: "caravan_raid",
    title: "🐾 Furry Barut Kervanına Pusu!",
    description: "Batı yolunda Furry Cumhuriyeti'nin başkente getirdiği erzak ve ok kervanı, Anzak'ın kışkırttığı paralı haydutlar tarafından kuşatıldı.",
    choices: [
      {
        text: "Kraliyet Muhafızlarını gönderip kervanı kurtar (25 Altın Sefer Masrafı)",
        costGold: 25,
        effectText: "-25 Altın, +12 Furry İlişkisi, +1 Furry Okçu Taburu",
        apply: (s) => {
          s.inventory.gold -= 25;
          s.relationships.furries = Math.min(100, s.relationships.furries + 12);
          s.armyComposition.furryArchers += 1;
        }
      },
      {
        text: "Haydutlara 1 tabur Piyade göndererek gözdağı ver",
        effectText: "+5 Askeri Destek, +5 Furry İlişkisi",
        apply: (s) => {
          s.stats.militarySupport = Math.min(100, s.stats.militarySupport + 5);
          s.relationships.furries = Math.min(100, s.relationships.furries + 5);
        }
      }
    ]
  },
  {
    id: "refugee_wave",
    title: "🦇 Doğu Sınırından Kaçan Göçmen Akını",
    description: "Vampir-Kara Elf öncü birliklerinin yaktığı sınır köylerinden yüzlerce köylü Başkent Lalo kapılarına dayandı. Soylular kapıların kapatılmasını istiyor.",
    choices: [
      {
        text: "Kapıları aç, Kraliyet ambarından 30 Altınlık erzak dağıt ve gençleri orduya al",
        costGold: 30,
        effectText: "-30 Altın, +12 Halk Desteği, +2 Kraliyet Piyade Taburu",
        apply: (s) => {
          s.inventory.gold -= 30;
          s.stats.publicSupport = Math.min(100, s.stats.publicSupport + 12);
          s.armyComposition.infantry += 2;
        }
      },
      {
        text: "Göçmenleri Doğu Kızıl Geçidi istihkam inşaatına yönlendir",
        effectText: "Doğu Kızıl Geçidi +2 Garnizon, -5 Halk Desteği",
        apply: (s) => {
          s.provinces.eastern_pass.garrison += 2;
          s.stats.publicSupport = Math.max(0, s.stats.publicSupport - 5);
        }
      }
    ]
  },
  {
    id: "doxe_preacher",
    title: "⚖️ DOXE Gezgin Rahibinin Vaazı",
    description: "Başkent meydanında bir DOXE rahibi köleliğe karşı ateşli bir vaaz veriyor. Anzak'ın muhafızları rahibi tutuklamak üzere.",
    choices: [
      {
        text: "Rahibi himayene al ve kölelik karşıtı reform sözünü yinele",
        effectText: "+12 DOXE, +8 Ahlak, -6 Anzak",
        apply: (s) => {
          s.worldRelations.doxe = Math.min(100, s.worldRelations.doxe + 12);
          s.stats.moralStanding = Math.min(100, s.stats.moralStanding + 8);
          s.relationships.anzak = Math.max(0, s.relationships.anzak - 6);
        }
      },
      {
        text: "Sessizce saraya davet edip DOXE Manastırı'na diplomatik mektup gönder",
        effectText: "+8 DOXE, +5 Politik Güç",
        apply: (s) => {
          s.worldRelations.doxe = Math.min(100, s.worldRelations.doxe + 8);
          s.stats.politicalPower = Math.min(100, s.stats.politicalPower + 5);
        }
      }
    ]
  },
  {
    id: "sister_cipher",
    title: "🔐 13 Yaşındaki Kız Kardeşinin Şifreli Defteri",
    description: "13 yaşındaki kız kardeşin saray kütüphanesinde Adem'in muhasebecisine ait şifreli bir rüşvet defteri buldu!",
    choices: [
      {
        text: "Defteri deşifre edip rüşvetçi baronların mallarına el koy!",
        effectText: "+55 Altın Hazineye, Kardeş Darbesi -10%",
        apply: (s) => {
          s.inventory.gold += 55;
          s.rivalState.brotherPlotProgress = Math.max(0, s.rivalState.brotherPlotProgress - 10);
          s.relationships.sister13 = Math.min(100, s.relationships.sister13 + 10);
          s.flags.knowsAboutCorruption = true;
        }
      },
      {
        text: "Baronlara şantaj yaparak onları kendi safına çek!",
        effectText: "+12 Politik Güç, Kardeş Darbesi -15%",
        apply: (s) => {
          s.stats.politicalPower = Math.min(100, s.stats.politicalPower + 12);
          s.rivalState.brotherPlotProgress = Math.max(0, s.rivalState.brotherPlotProgress - 15);
          s.flags.knowsAboutCorruption = true;
        }
      }
    ]
  }
];

// ----------------------------------------------------------------------------
// 4. BAŞLANGIÇ OYUN DURUMU (INITIAL GAME STATE)
// ----------------------------------------------------------------------------
window.PrinceTutu.getInitialState = function () {
  return {
    turn: 1,
    chapter: 1,
    scene: "throne_room_morning",
    actionPoints: 2,
    maxActionPoints: 2,
    pendingEvent: null,
    triggeredEvents: [],
    relationships: {
      father: 60,      // İmparator Lalo (68)
      adem: 30,        // Kardeş (19)
      anzak: 25,       // Kardeş (27)
      sister9: 80,     // Küçük kız kardeş (9)
      sister13: 75,    // Küçük kız kardeş (13)
      furries: 70,     // Furry Cumhuriyeti
      people: 50,      // Halk
      advisor: 65      // Baş Danışman
    },
    worldRelations: {
      doxe: 45,          // DOXE Kutsal Krallığı
      vampireElves: 10,  // Vampir-Kara Elf İttifakı
      mountainTribes: 50 // Kuzey Dağ Kabileleri
    },
    stats: {
      politicalPower: 42,
      moralStanding: 60,
      militarySupport: 40,
      publicSupport: 50,
      intelligence: 55,
      charisma: 65
    },
    armyComposition: {
      infantry: 6,       // Kraliyet Piyadesi (Standart)
      furryArchers: 2,   // Furry Keskin Nişancıları (İlk tur menzilli yaylım ateşi)
      mountainAxemen: 1, // Dağ Baltacıları (En yüksek zara +1 bonus)
      doxePaladins: 0    // DOXE Şövalyeleri (Kutsal Arındırma + 6 zarda 2x hasar)
    },
    rivalState: {
      anzakGold: 180,
      brotherPlotProgress: 20, // 100 olursa kardeşler saray darbesi yapar!
      vampireInvasionTimer: 5, // 0 olursa Vampir-Kara Elf ordusu saldırır!
      lastRivalMove: "Anzak ve Adem, Güney Ovalarındaki köle baronlarından altın topluyor."
    },
    worldState: {
      economicState: "Durgun",
      militaryStrength: "Hazırlıkta",
      slavery: "Yasal (Tartışmalı)",
      diplomaticStanding: "Gergin"
    },
    inventory: {
      gold: 160,
      items: [
        {
          id: "royal_seal",
          name: "Kraliyet Mührü",
          type: "politik",
          description: "Baban İmparator Lalo'nun verdiği resmi mühür (+5 Politik Etki)",
          power: 5
        },
        {
          id: "silver_dagger",
          name: "Gümüş Hançer",
          type: "silah",
          description: "Vampirlere ve suikastçılara karşı etkili hançer (Düelloda +8 Hasar)",
          power: 4
        },
        {
          id: "wisdom_book",
          name: "Bilgelik Kitabı",
          type: "kitap",
          description: "Eski kralların stratejilerini ve DOXE antlaşmalarını içeren kayıt",
          power: 3
        }
      ]
    },
    decrees: {
      abolishSlavery: false,
      furryTradePact: false,
      martialLaw: false,
      mountainSmithGuild: false,
      royalInquisition: false,
      imperialUniversity: false,
      freePeasantLand: false,
      easternFortifications: false
    },
    flags: {
      slaveryDiscussed: false,
      brothersConfronted: false,
      vampireThreatKnown: true,
      hasSpyNetwork: false,
      knowsAboutCorruption: false,
      easternVictory: false,
      vampireCitadelTaken: false,
      anzakDefeated: false,
      ademNetworkCrushed: false,
      sistersProtected: false,
      doxeAlliance: false,
      furrySenateTreaty: false,
      northernForgePact: false,
      fathersWillSecured: false
    },
    provinces: JSON.parse(JSON.stringify(window.PrinceTutu.INITIAL_PROVINCES)),
    historyLog: [
      "👑 Tur 1: İmparator Lalo seni sabah divanına çağırdı. Her tur 2 Stratejik Emir Hakkın (AP) var."
    ]
  };
};

// ----------------------------------------------------------------------------
// 5. KAYDET / YÜKLE SİSTEMİ (LOCALSTORAGE GÜVENLİ SARMALAYICI)
// ----------------------------------------------------------------------------
window.PrinceTutu.SAVE_KEY = "prens_tutu_v4_save_state";

window.PrinceTutu.saveGame = function (state) {
  try {
    localStorage.setItem(window.PrinceTutu.SAVE_KEY, JSON.stringify(state));
    return true;
  } catch (e) {
    return false;
  }
};

window.PrinceTutu.loadGame = function () {
  try {
    const raw = localStorage.getItem(window.PrinceTutu.SAVE_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (e) {
    return null;
  }
};

window.PrinceTutu.hasSavedGame = function () {
  try {
    return !!localStorage.getItem(window.PrinceTutu.SAVE_KEY);
  } catch (e) {
    return false;
  }
};

// ----------------------------------------------------------------------------
// 6. RAKİP YAPAY ZEKA, VERGİ, RASTGELE OLAY VE YENİLGİ MOTORU
// ----------------------------------------------------------------------------
window.PrinceTutu.processTurnSimulation = function (state) {
  const next = JSON.parse(JSON.stringify(state));
  next.turn += 1;
  next.maxActionPoints = next.decrees.imperialUniversity ? 3 : 2;
  next.actionPoints = next.maxActionPoints;

  // 1. Oyuncunun kontrolündeki eyaletlerden vergi geliri topla
  let turnTax = 0;
  Object.values(next.provinces).forEach((prov) => {
    if (prov.owner === "player") {
      const effectiveTax = Math.max(5, Math.floor(prov.taxIncome * (1 - prov.unrest / 160)));
      turnTax += effectiveTax;
    }
  });

  if (next.decrees.furryTradePact) turnTax += 25;
  if (next.flags.furrySenateTreaty) turnTax += 15;
  next.inventory.gold += turnTax;

  // 2. Anzak ve Adem'in Yapay Zeka Hamlesi (Eğer Anzak yenilmediyse)
  if (!next.flags.anzakDefeated) {
    const brothersProvs = Object.values(next.provinces).filter((p) => p.owner === "brothers").length;
    const brotherIncome = brothersProvs * 20;
    next.rivalState.anzakGold += brotherIncome;

    const roll = Math.random();
    if (roll < 0.36 && next.rivalState.anzakGold >= 50) {
      next.rivalState.anzakGold -= 50;
      const plotGain = next.flags.ademNetworkCrushed ? 7 : 13;
      next.rivalState.brotherPlotProgress = Math.min(100, next.rivalState.brotherPlotProgress + plotGain);
      next.stats.politicalPower = Math.max(0, next.stats.politicalPower - 2);
      next.rivalState.lastRivalMove = `⚠️ Anzak saray muhafızlarına rüşvet dağıttı! (Darbe Hazırlığı +${plotGain}%)`;
    } else if (roll < 0.72) {
      next.provinces.capital_lalo.unrest = Math.min(100, next.provinces.capital_lalo.unrest + 8);
      const plotGain = next.flags.ademNetworkCrushed ? 5 : 10;
      next.rivalState.brotherPlotProgress = Math.min(100, next.rivalState.brotherPlotProgress + plotGain);
      next.rivalState.lastRivalMove = `🕵️ Adem başkent loncalarında kışkırtma yaptı! (Darbe Hazırlığı +${plotGain}%)`;
    } else {
      if (next.provinces.golden_plains.owner === "brothers") {
        next.provinces.golden_plains.garrison += 2;
      }
      next.rivalState.brotherPlotProgress = Math.min(100, next.rivalState.brotherPlotProgress + 8);
      next.rivalState.lastRivalMove = "⚔️ Anzak, Güney Bereket Ovaları garnizonuna +2 paralı asker taburu yığdı.";
    }

    // Casus Ağı darbe hızını frenler
    if (next.flags.hasSpyNetwork) {
      next.rivalState.brotherPlotProgress = Math.max(0, next.rivalState.brotherPlotProgress - 6);
    }
  } else {
    next.rivalState.lastRivalMove = "🏳️ Anzak mağlup edildiği için kardeşlerin darbe konseyi dağıldı.";
  }

  // 3. Vampir - Kara Elf İttifakı Sınır Baskısı
  if (!next.flags.vampireCitadelTaken && next.provinces.vampire_citadel.owner === "vampire") {
    next.rivalState.vampireInvasionTimer = Math.max(0, next.rivalState.vampireInvasionTimer - 1);
    if (next.rivalState.vampireInvasionTimer === 0) {
      const east = next.provinces.eastern_pass;
      if (east.owner === "player") {
        const dmg = next.decrees.easternFortifications ? 2 : 3;
        east.garrison = Math.max(0, east.garrison - dmg);
        next.historyLog.unshift(`🦇 Vampir-Kara Elf ordusu Doğu Kızıl Geçidi'ne saldırdı! (-${dmg} Garnizon)`);
        if (east.garrison === 0) {
          east.owner = "vampire";
          east.garrison = 8;
          next.historyLog.unshift("🚨 FELAKET! Doğu Kızıl Geçidi düştü! Vampir ordusu Başkent Lalo kapılarına dayandı!");
        }
      } else {
        // Doğu geçidi zaten düşmüşse doğrudan Başkent düşer!
        next.scene = "ending_vampire_fall";
        next.chapter = 5;
        return next;
      }
      next.rivalState.vampireInvasionTimer = 3;
    }
  }

  // 4. KRİTİK KONTROL: Kardeşlerin Darbe Hazırlığı %100 olduysa Oyun Kaybedilir!
  if (next.rivalState.brotherPlotProgress >= 100 && !next.flags.anzakDefeated) {
    next.scene = "ending_coup_defeat";
    next.chapter = 5;
    next.historyLog.unshift("💀 SARAY DARBESİ! Anzak ve Adem'in komplosu %100'e ulaştı ve tahtı ele geçirdiler!");
    return next;
  }

  // 5. Rastgele Kriz Olayı Tetikleyici (%38 ihtimalle, daha önce çıkmamış bir olay)
  if (!next.pendingEvent && next.chapter < 5 && Math.random() < 0.38) {
    const available = window.PrinceTutu.RANDOM_EVENTS.filter(
      (ev) => !next.triggeredEvents.includes(ev.id)
    );
    if (available.length > 0) {
      const picked = available[Math.floor(Math.random() * available.length)];
      next.pendingEvent = picked.id;
      next.triggeredEvents.push(picked.id);
    }
  }

  next.historyLog.unshift(`💰 Tur ${next.turn}: Eyaletlerden +${turnTax} Altın vergi toplandı (${next.actionPoints} Emir Hakkı hazır).`);
  return next;
};

// ----------------------------------------------------------------------------
// 7. EYALET YÖNETİM AKSİYONLARI (Harita Üzerinden AP Harcayarak Etkileşim)
// ----------------------------------------------------------------------------
window.PrinceTutu.executeProvinceAction = function (state, provinceId, actionType) {
  const next = JSON.parse(JSON.stringify(state));
  const prov = next.provinces[provinceId];
  if (!prov) return { state: next, message: "Bölge bulunamadı." };

  if (next.actionPoints <= 0) {
    window.PrinceTutu.Sound.play("alert");
    return {
      state,
      message: "❌ Bu tur için Stratejik Emir Hakkın (AP) bitti! Yeni AP için hikayede ilerle."
    };
  }

  if (actionType === "recruit_garrison") {
    if (next.inventory.gold < 35) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: "❌ Garnizon ve tabur takviyesi için 35 Altın gerekli!" };
    }
    next.inventory.gold -= 35;
    next.actionPoints -= 1;
    prov.garrison += 3;
    next.armyComposition.infantry += 2;
    next.stats.militarySupport = Math.min(100, next.stats.militarySupport + 4);
    window.PrinceTutu.Sound.play("horn");
    next.historyLog.unshift(`🛡️ [1 AP] ${prov.name} garnizonuna +3 Tabur, saha orduna +2 Piyade eklendi.`);
    return {
      state: next,
      message: `🛡️ ${prov.name} güçlendirildi (+3 Garnizon, +2 Saha Piyadesi | Kalan AP: ${next.actionPoints})`
    };
  }

  if (actionType === "pacify_unrest") {
    if (next.inventory.gold < 25) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: "❌ Halka erzak dağıtmak için 25 Altın gerekli!" };
    }
    next.inventory.gold -= 25;
    next.actionPoints -= 1;
    prov.unrest = Math.max(0, prov.unrest - 25);
    prov.taxIncome += 6;
    next.stats.publicSupport = Math.min(100, next.stats.publicSupport + 5);
    window.PrinceTutu.Sound.play("coin");
    next.historyLog.unshift(`🌾 [1 AP] ${prov.name} halkına erzak dağıtıldı (-25% İsyan, +6 Vergi).`);
    return {
      state: next,
      message: `🌾 ${prov.name} huzura kavuştu (-25% İsyan, +6 Vergi/Tur | Kalan AP: ${next.actionPoints})`
    };
  }

  if (actionType === "spy_sabotage") {
    const cost = next.flags.hasSpyNetwork ? 15 : 40;
    if (next.inventory.gold < cost) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: `❌ Sabotaj operasyonu için ${cost} Altın gerekli!` };
    }
    next.inventory.gold -= cost;
    next.actionPoints -= 1;
    const oldGarrison = prov.garrison;
    prov.garrison = Math.max(2, prov.garrison - 3);
    const reduced = oldGarrison - prov.garrison;
    prov.unrest = Math.min(100, prov.unrest + 20);
    if (prov.owner === "brothers") {
      next.rivalState.brotherPlotProgress = Math.max(0, next.rivalState.brotherPlotProgress - 8);
    }
    window.PrinceTutu.Sound.play("sword");
    next.historyLog.unshift(
      `🕵️ [1 AP] Casusların ${prov.name} ikmal depolarını havaya uçurdu! (Düşman Garnizonu -${reduced} Tabur)`
    );
    return {
      state: next,
      message: `🕵️ ${prov.name} sabote edildi! Savaşta karşısına çıkacak düşman ordusu ${reduced} tabur azaldı!`
    };
  }

  if (actionType === "diplomatic_envoy") {
    if (next.inventory.gold < 30) {
      window.PrinceTutu.Sound.play("alert");
      return { state, message: "❌ Diplomatik hediye kervanı için 30 Altın gerekli!" };
    }
    next.inventory.gold -= 30;
    next.actionPoints -= 1;
    window.PrinceTutu.Sound.play("coin");

    if (prov.owner === "furry") {
      next.relationships.furries = Math.min(100, next.relationships.furries + 15);
      next.armyComposition.furryArchers += 1;
      next.historyLog.unshift("🐾 [1 AP] Furry Limanı'na elçi gönderildi (+15 İlişki, +1 Furry Okçu Taburu).");
      return { state: next, message: "🐾 Furry Senatosu memnun oldu! Orduna +1 Furry Okçu Taburu katıldı." };
    }
    if (prov.owner === "doxe") {
      next.worldRelations.doxe = Math.min(100, next.worldRelations.doxe + 15);
      if (next.worldRelations.doxe >= 60 || next.decrees.abolishSlavery) {
        next.armyComposition.doxePaladins += 1;
        next.historyLog.unshift("⚖️ [1 AP] DOXE Manastırı'ndan +1 Kutsal Paladin Taburu desteğe geldi!");
        return { state: next, message: "⚖️ DOXE Başrahibi orduna +1 Kutsal Paladin Taburu gönderdi!" };
      }
      return { state: next, message: "⚖️ DOXE ile ilişkiler +15 arttı (60+ ilişkide Paladin gönderirler)." };
    }
    if (prov.owner === "tribes") {
      next.worldRelations.mountainTribes = Math.min(100, next.worldRelations.mountainTribes + 15);
      next.armyComposition.mountainAxemen += 1;
      next.historyLog.unshift("⚒️ [1 AP] Kuzey Dağ Klanları orduna +1 Dağ Baltacısı Taburu gönderdi.");
      return { state: next, message: "⚒️ Dağ Klanları ile kan kardeşliği güçlendi (+1 Dağ Baltacısı Taburu)!" };
    }
  }

  return { state: next, message: "İşlem tamamlandı." };
};
