// ============================================================================
// PRENS TUTU: GÖLGELERİN TACI - MODÜL 2: DATA & STORY (data-story.js) v4.0
// İçerik: 8 Kraliyet Fermanı, 8 Lore Ansiklopedisi, 20 Dallanan Sahne & 7 Final
// ============================================================================

window.PrinceTutu = window.PrinceTutu || {};

// ----------------------------------------------------------------------------
// 1. İMPARATORLUK KARARNAMELERİ (8 DECREES VERİTABANI)
// ----------------------------------------------------------------------------
window.PrinceTutu.DECREES_DATA = [
  {
    id: "abolishSlavery",
    title: "⛓️ Köleliği İmparatorluk Genelinde Yasakla",
    costGold: 0,
    reqStat: { stat: "politicalPower", value: 45, label: "Politik Güç 45+" },
    description: "Köle pazarlarını kapatır. DOXE Kutsal Krallığı ordusundan +2 Kutsal Paladin Taburu kazandırır, Halk ve DOXE ilişkilerini zirveye taşır. Ancak Anzak'ın Güney Baronlarını öfkelendirir.",
    effectLabel: "+30 DOXE, +25 Halk, +2 DOXE Paladin Birimi, Kölelik: Yasaklandı"
  },
  {
    id: "furryTradePact",
    title: "🐾 Furry Cumhuriyeti İmtiyazlı Gümrük Paktı",
    costGold: 40,
    reqStat: null,
    description: "Batı limanlarını Furry ticaret loncalarına açar. Anında +120 Altın sıcak para, her tur +25 ekstra vergi ve orduna +2 Furry Keskin Nişancı Taburu kazandırır.",
    effectLabel: "+80 Net Altın, +25/Tur Vergi, +20 Furry İlişkisi, +2 Furry Okçu Birimi"
  },
  {
    id: "martialLaw",
    title: "⚔️ Sınır Boyu Olağanüstü Hal ve Sıkıyönetim",
    costGold: 25,
    reqStat: null,
    description: "Doğu Kızıl Geçidi ve Başkent'te askeri disiplin ilan eder. Orduna +3 Kraliyet Piyade Taburu ve +18 Askeri Destek sağlar, ancak halk arasında huzursuzluk yaratır.",
    effectLabel: "+18 Askeri Destek, +3 Piyade Birimi, -10 Halk Desteği"
  },
  {
    id: "mountainSmithGuild",
    title: "⚒️ Kuzey Dağ Klanları Çelik Ocakları Antlaşması",
    costGold: 50,
    reqStat: null,
    description: "Dağ Kabilelerinin usta demircilerine kraliyet imtiyazı verir. Orduna +3 Vahşi Dağ Baltacısı Taburu katar ve düellolarda Kuzey Çeliği Zırh (+25 Can) kazandırır.",
    effectLabel: "+25 Dağ Kabileleri, +3 Dağ Baltacısı Birimi, Envantere 'Kuzey Çeliği Zırh'"
  },
  {
    id: "royalInquisition",
    title: "🕵️ Gölge İstihbarat ve Anti-Yolsuzluk Divanı",
    costGold: 45,
    reqStat: { stat: "intelligence", value: 58, label: "Zeka 58+" },
    description: "Baş Danışman liderliğinde gizli bir iç istihbarat teşkilatı kurar. Anzak ve Adem'in darbe hazırlığını anında %35 düşürür ve harita sabotaj maliyetini 40'tan 15 Altına indirir.",
    effectLabel: "Casus Ağı Aktif, Kardeşlerin Darbe Planı -35%, +12 Politik Güç"
  },
  {
    id: "imperialUniversity",
    title: "🏛️ İmparatorluk Strateji ve Bilim Akademisi",
    costGold: 55,
    reqStat: { stat: "intelligence", value: 55, label: "Zeka 55+" },
    description: "Başkent Lalo'da kurmay subay ve devlet adamı yetiştiren akademiyi açar. Her tur sahip olduğun Stratejik Emir Hakkını (AP) kalıcı olarak 2'den 3'e çıkarır!",
    effectLabel: "Her Tur +1 Ekstra Stratejik Emir Hakkı (3 AP/Tur), +10 Zeka"
  },
  {
    id: "freePeasantLand",
    title: "🌾 Güney Toprak ve Köylü Özgürlük Reformu",
    costGold: 35,
    reqStat: { stat: "moralStanding", value: 60, label: "Ahlaki Duruş 60+" },
    description: "Güney Ovalarındaki köylülerin toprak borçlarını siler. Anzak'ın baronlarının garnizonunu 2 tabur zayıflatır ve orduna +2 gönüllü Piyade Taburu katar.",
    effectLabel: "+18 Halk Desteği, +2 Piyade Taburu, Güney Ovaları Düşman Garnizonu -2"
  },
  {
    id: "easternFortifications",
    title: "🏰 Kızıl Geçit Kaya Surları ve Ateş Kuleleri",
    costGold: 45,
    reqStat: null,
    description: "Doğu Kızıl Geçidi'ne dev mancınıklar ve ateş hendekleri inşa eder. Geçit garnizonuna +4 Tabur ekler ve Vampir İstilası Sayacını +3 Tur geciktirir.",
    effectLabel: "Doğu Kızıl Geçidi +4 Garnizon, Vampir Sayacı +3 Tur, +10 Askeri Destek"
  }
];

// ----------------------------------------------------------------------------
// 2. DÜNYA ANSİKLOPEDİSİ (8 LORE CODEX MADDELERİ)
// ----------------------------------------------------------------------------
window.PrinceTutu.LORE_CODEX = [
  {
    title: "İmparator Lalo ve Taht Krizi",
    category: "Hanedan",
    text: "68 yaşındaki İmparator Lalo, kırk yıllık saltanatının sonunda ağır bir hastalıkla pençeleşiyor. Üç oğlu arasında en zeki ve adil olanı Prens Tutu olsa da, 27 yaşındaki savaş yanlısı Anzak ve 19 yaşındaki entrikacı Adem tahtı zorla ele geçirmek için soylularla gizli ittifaklar kuruyor."
  },
  {
    title: "Vampir - Kara Elf İttifakı (Doğu Tehdidi)",
    category: "Dış Güçler",
    text: "Yüzyıllardır birbirleriyle savaşan Kan Lordu Malakor ve Gölge Ormanı'nın Kara Elfleri, ilk kez tek bir sancak altında birleşti. Doğu Kızıl Geçidi düşerse başkent Lalo tamamen savunmasız kalacak."
  },
  {
    title: "Furry Cumhuriyeti (Batı Müttefiki)",
    category: "Diplomasi",
    text: "Batı kıyılarındaki zengin ticaret limanlarını yöneten Furry Cumhuriyeti, imparatorluğun en büyük finansörü ve keskin nişancı tedarikçisidir. Ancak Anzak'ın ırkçı ve saldırgan politikaları bu kadim dostluğu tehdit ediyor."
  },
  {
    title: "DOXE Kutsal Krallığı ve Kölelik Krizi",
    category: "Diplomasi",
    text: "Güneydeki teokratik DOXE Krallığı, İmparatorluk topraklarında kölelik devam ettiği sürece Vampir-Kara Elf savaşına tek bir şövalye bile göndermeyeceğini ilan etti. Köleliği kaldırmak DOXE'nin efsanevi Paladinlerini yanına çeker."
  },
  {
    title: "Küçük Kız Kardeşler (9 ve 13 Yaşında)",
    category: "Aile",
    text: "Saraydaki acımasız taht kavgasında seni karşılıksız seven iki kişi: 9 ve 13 yaşlarındaki küçük kız kardeşlerin. Sarayın gizli koridorlarında duydukları fısıltılar hayat kurtarabilir, ancak kardeşlerin onları sana karşı rehin olarak kullanmak isteyebilir."
  },
  {
    title: "Kuzey Dağ Klanları ve Demir Ocakları",
    category: "Dış Güçler",
    text: "Gümüş Zirveler'de yaşayan Kuzey Dağ Klanları, imparatorluğun en sağlam çeliğini döver. Onların Baltacıları muharebede en yüksek zara +1 taktiksel üstünlük kazandırır."
  },
  {
    title: "Taktiksel Muharebe ve Birim Sinerjisi",
    category: "Rehber",
    text: "Muharebelerde 3v2 Risk zarı atılır. Furry Okçuları zar atılmadan önce yaylım ateşiyle düşman taburlarını eritir; DOXE Paladinleri ise Kutsal Arındırma yeteneğiyle Vampir ordularına ağır hasar verir ve zar 6 geldiğinde çift tabur yok eder."
  },
  {
    title: "Taht Düellosu: Niyet Okuma ve Stamina",
    category: "Rehber",
    text: "Anzak ile birebir düelloda her hamle Stamina harcar. Anzak'ın 'Ağır Yukarıdan İndirme' hamlesini Siper & Kontra ezer; 'Omuz Darbesi (Guard Break)' ise siperi kırar ve Gümüş Hançer Saplaması ile cezalandırılır."
  }
];

// ----------------------------------------------------------------------------
// 3. ANA HİKAYE VE DALLANAN SAHNE AĞACI (20 SAHNE + 7 FİNAL)
// ----------------------------------------------------------------------------
window.PrinceTutu.SCENES = {
  // ================= BÖLÜM 1: SARAYDA SABAH VE İLK DALLANMA =================
  throne_room_morning: {
    chapter: 1,
    title: "Taht Odası - Çöken İmparatorluğun Sabahı",
    location: "Başkent Lalo — Altın Taht Salonu",
    description: "Sabah güneşi yüksek vitray pencerelerden süzülerek mermer zemine kan kırmızısı ve altın rengi gölgeler düşürüyor. Baban İmparator Lalo, altın tahtında çökmüş oturuyor; altmış sekiz yaşından çok daha yaşlı görünüyor.\n\nAğabeyin Anzak (27) eli kılıcının kabzasında, kardeşin Adem (19) ise sinsi bir tebessümle tahtın yanında durmuş fısıldaşıyor. Sen içeri girince aniden susuyorlar.\n\n'Ah, Tutu,' diyor baban yorgun ve çatallı bir sesle. 'Yaklaş oğlum. Doğu sınırımız yanıyor, hazine eriyor ve Savaş Konseyi toplanmadan önce seninle konuşmam gerek.'",
    choices: [
      {
        text: "👑 [İmparatorun Özel Odası] Babanın koluna girerek onu dinlenmesi için özel dairesine götür ve baş başa konuş",
        consequence: "Babanın gizli endişelerini ve vasiyetini öğren (+10 İmparator, +5 Ahlak ➔ Özel Daire Sahnesi)",
        statChange: { relationships: { father: 10 }, stats: { moralStanding: 5, charisma: 4 } },
        nextScene: "imperial_bedchamber"
      },
      {
        text: "⚔️ [Avluda Yüzleşme] Konsey öncesi Anzak ve Adem'in peşinden silah avlusuna inip niyetlerini yokla",
        consequence: "Kardeşlerinle doğrudan yüzleş (+6 Politik Güç, Darbe Hızı -6% ➔ Silah Avlusu Sahnesi)",
        statChange: { relationships: { adem: 4, anzak: 4 }, stats: { politicalPower: 6 }, rivalDelta: { brotherPlotProgress: -6 } },
        nextScene: "brothers_courtyard"
      },
      {
        text: "📜 [Kraliyet Mührü] Mührü Baş Danışman'a göstererek doğrudan Savaş Konseyi harita masasına geç",
        consequence: "Bürokratik üstünlüğü kur (+10 Danışman, +6 Zeka, +5 Politik Güç ➔ Savaş Konseyi)",
        requiresItem: "Kraliyet Mührü",
        statChange: { relationships: { advisor: 10 }, stats: { intelligence: 6, politicalPower: 5 } },
        nextScene: "council_discussion"
      }
    ]
  },

  imperial_bedchamber: {
    chapter: 1,
    title: "İmparatorun Özel Dairesi - Gizli Vasiyet",
    location: "Başkent Lalo — Hünkar Kasrı",
    description: "Baban İmparator Lalo, işlemeli yatağına çökerken öksürük krizine tutuluyor. İpek mendilindeki kan lekelerini senden saklamaya çalışarak elini sıkıca tutuyor:\n\n'Tutu... Hekimler bana en fazla birkaç haftam kaldığını söyledi. Anzak tahta geçerse Furry Cumhuriyeti ve DOXE ile savaş çıkarıp imparatorluğu ateşe atacak. Adem ise tacı Güneyin Köle Baronlarına peşkeş çekecek. Kız kardeşlerini (9 ve 13) sadece sen koruyabilirsin oğlum. Yastığımın altındaki gizli hazine anahtarını al.'",
    choices: [
      {
        text: "Babanın elini öpüp kız kardeşlerini ve imparatorluğu kanının son damlasına kadar koruyacağına yemin et",
        consequence: "Babanın gizli fonunu (+65 Altın) ve meşru vasiyet desteğini al (+10 Politik Güç)",
        statChange: {
          inventory: { gold: 65 },
          relationships: { father: 12, sister9: 8, sister13: 8 },
          stats: { politicalPower: 10, moralStanding: 6 },
          flags: { fathersWillSecured: true }
        },
        nextScene: "council_discussion"
      },
      {
        text: "Babandan saray muhafızlarının komutasını geçici olarak Baş Danışman ve sana devreden bir emirname iste",
        consequence: "Saray güvenliğini sıkılaştır (+10 Askeri Destek, Kardeş Darbesi -10%)",
        statChange: {
          stats: { militarySupport: 10, politicalPower: 6 },
          relationships: { advisor: 8 },
          rivalDelta: { brotherPlotProgress: -10 },
          flags: { fathersWillSecured: true }
        },
        nextScene: "council_discussion"
      }
    ]
  },

  brothers_courtyard: {
    chapter: 1,
    title: "Silah Avlusu - İki Kardeş, İki Tehdit",
    location: "Başkent Lalo — İç Kale Avlusu",
    description: "Avluda Anzak, ağır çift elli kılıcıyla talim mankenlerini parçalıyor. Adem ise kemerindeki altın kesesini şıngırdatarak Güneyli iki soyluyla konuşuyor. Seni görünce Anzak terli alnını silip sırıtıyor:\n\n'Bakın kim gelmiş! Kitap kurdu kardeşimiz Tutu! Söyle bakalım kardeşim, babamız gözlerini yumduğunda benim kılıcımın gölgesinde mi duracaksın, yoksa yoluma mı çıkacaksın?'",
    choices: [
      {
        text: "'Şu an düşmanımız birbirimiz değil Anzak; Doğu Kızıl Geçidi'ndeki Vampir ordusu!' diyerek ortak düşmanı hatırlat",
        consequence: "Komutanların önünde olgun liderlik sergile (+8 Karizma, +6 Askeri Destek, Darbe -8%)",
        statChange: {
          stats: { charisma: 8, militarySupport: 6 },
          relationships: { anzak: 6 },
          rivalDelta: { brotherPlotProgress: -8 }
        },
        nextScene: "council_discussion"
      },
      {
        text: "Adem'in yanındaki Güneyli Köle Baronlarına sert bir bakış atıp saraydan derhal çıkmalarını emret!",
        consequence: "Adem'in rüşvet ağını boz (+8 Politik Güç, +6 Ahlak, -8 Adem, Darbe -10%)",
        statChange: {
          stats: { politicalPower: 8, moralStanding: 6 },
          relationships: { adem: -8 },
          rivalDelta: { brotherPlotProgress: -10 },
          flags: { knowsAboutCorruption: true }
        },
        nextScene: "council_discussion"
      }
    ]
  },

  council_discussion: {
    chapter: 1,
    title: "Kraliyet Savaş Konseyi",
    location: "Başkent Lalo — Strateji Odası",
    description: "Büyük meşe masanın üzerindeki imparatorluk haritası kırmızı iğnelerle dolu. Lord Komutan Vex doğu sınırını işaret ediyor:\n\n'Casuslarımızın raporları korkunç Hünkarım. Vampir Lordu Malakor ve Kara Elf büyücüleri Doğu Kızıl Geçidi'nin hemen ötesinde büyük bir ordu topladı. Üstelik Güneydeki DOXE Kutsal Krallığı, topraklarımızda kölelik devam ettiği için yardım antlaşmasını askıya aldı!'\n\nİmparator Lalo sana dönüyor: 'Sen ne diyorsun Tutu? İlk stratejik hamlemiz ne olmalı?'",
    choices: [
      {
        text: "🎲 [Öncü Sınır Muharebesi] 'Sınır komutasını ben alıyorum Baba! Doğu Kızıl Geçidi'nde öncü Vampir akınını bizzat ezeceğim!'",
        consequence: "Taktiksel Savaş Simülatörünü başlatır! Kazanırsan ordunun saygısını ve ganimet kazanırsın.",
        specialAction: "startBattle",
        battleTarget: "eastern_pass",
        statChange: { stats: { militarySupport: 8 }, relationships: { father: 6 } },
        nextScene: "private_chambers"
      },
      {
        text: "DOXE Krallığı'nın desteğini geri kazanmak için kölelik reformunu masaya yatır",
        consequence: "Diplomatik ve ahlaki liderlik göster (+8 Politik Güç, +6 Zeka, +15 DOXE)",
        statChange: {
          stats: { politicalPower: 8, intelligence: 6, moralStanding: 8 },
          worldRelations: { doxe: 15 },
          flags: { slaveryDiscussed: true }
        },
        nextScene: "private_chambers"
      },
      {
        text: "Adem'in Furry tüccarlarına ek vergi teklifini reddet: 'Furry Cumhuriyeti en sadık müttefikimizdir!'",
        consequence: "Furry Elçisinin takdirini kazan (+15 Furry, +45 Ticaret Altını, +1 Furry Okçu Taburu)",
        statChange: {
          relationships: { furries: 15, adem: -5 },
          inventory: { gold: 45 },
          armyDelta: { furryArchers: 1 },
          stats: { charisma: 5, politicalPower: 4 }
        },
        nextScene: "private_chambers"
      },
      {
        text: "Hazine'den 45 Altın ayırarak hem sınırda hem sarayda Gölge Casus Ağı kur",
        consequence: "Gizli istihbarat teşkilatını başlat (+9 Zeka, Casus Ağı Aktif, Darbe -12%)",
        goldCost: 45,
        statChange: {
          stats: { intelligence: 9, politicalPower: 5 },
          flags: { hasSpyNetwork: true },
          rivalDelta: { brotherPlotProgress: -12 }
        },
        nextScene: "private_chambers"
      }
    ]
  },

  // ================= BÖLÜM 2: GECE FISILTILARI VE KOMPLO AĞI =================
  private_chambers: {
    chapter: 2,
    title: "Özel Odalar - Gece Yarısı Fısıltıları",
    location: "Saray Batı Kanadı — Prens Tutu'nun Dairesi",
    description: "Konsey toplantısından sonra odana çekildin. Gece yarısı kapında ürkek bir tıkırtı duyuluyor. Kapıyı açtığında 13 ve 9 yaşlarındaki iki küçük kız kardeşinin el ele tutuşmuş, titreyerek koridorda beklediğini görüyorsun.\n\n13 yaşındaki kardeşin içeri girip kapıyı sürgülüyor: 'Tutu abi, çok korkuyoruz! Bir saat önce Adem'in dairesinin önünden geçerken içeride Güneyin Köle Baronlarını ve Fısıltı Ormanı'ndan kiralanmış suikastçıları gördük. Bu gece odana baskın yapmaktan bahsediyorlardı!'\n\n9 yaşındaki en küçük kardeşin cübbene sarılıyor: 'Abi, bizi Anzak'ın adamlarına bırakma...'",
    choices: [
      {
        text: "Kardeşlerini gizli muhafız bölüğünün koruduğu iç odaya yerleştir ve kendi odanda suikastçılara pusu kur!",
        consequence: "Kardeşlerini güvenceye al ve gece baskınına hazırlan (+15 Kız Kardeşler, Darbe -10%)",
        statChange: {
          relationships: { sister13: 15, sister9: 15 },
          stats: { intelligence: 7, moralStanding: 8 },
          flags: { knowsAboutCorruption: true, sistersProtected: true },
          rivalDelta: { brotherPlotProgress: -10 }
        },
        nextScene: "assassination_attempt"
      },
      {
        text: "13 yaşındaki kardeşinin tarif ettiği nöbetçi subayı hemen tutuklatıp Saray Zindanı'nda sorguya çek!",
        consequence: "Baskın başlamadan komployu kaynağında yakala (+8 Zeka ➔ Zindan Sorgusu Sahnesi)",
        statChange: {
          relationships: { sister13: 12, sister9: 12 },
          stats: { intelligence: 8, politicalPower: 6 },
          flags: { knowsAboutCorruption: true, sistersProtected: true }
        },
        nextScene: "palace_dungeon_interrogation"
      },
      {
        text: "⚔️ [Anında Misilleme] Gümüş Hançer'ini kuşanıp doğrudan Anzak'ın gece avlusunu bas!",
        consequence: "Anzak ile Birebir Kılıç Düellosu başlatır!",
        specialAction: "startDuel",
        statChange: {
          relationships: { sister13: 10, sister9: 10 },
          flags: { sistersProtected: true, brothersConfronted: true }
        },
        nextScene: "assassination_attempt"
      }
    ]
  },

  palace_dungeon_interrogation: {
    chapter: 2,
    title: "Saray Zindanları - İhanetin İtirafı",
    location: "Başkent Lalo — Yeraltı Sorgu Hücresi",
    description: "Baş Danışman ile birlikte meşalelerin aydınlattığı nemli zindana indin. Kız kardeşlerinin ihbar ettiği rüşvetçi muhafız yüzbaşısı zincire vurulmuş halde titriyor.\n\n'Merhamet edin Prensim!' diye yalvarıyor yüzbaşı. 'Bana altını Adem verdi! Fısıltı Ormanı'ndaki Kara Lonca'dan iki suikastçıyı birazdan batı balkonundan odanıza sokacaklardı. Üstelik Adem'in tüm suikast sandığı Fısıltı Ormanı'ndaki gizli kampta tutuluyor!'",
    choices: [
      {
        text: "Yüzbaşıya imzalı itirafname yazdır ve balkona giren suikastçıları muhafızlarla kıskıvrak yakala!",
        consequence: "Kusursuz karşı-istihbarat! (+12 Politik Güç, +10 Danışman, Kardeş Darbesi -20%)",
        statChange: {
          stats: { politicalPower: 12, intelligence: 6 },
          relationships: { advisor: 10 },
          flags: { hasSpyNetwork: true, knowsAboutCorruption: true },
          rivalDelta: { brotherPlotProgress: -20 }
        },
        nextScene: "whisper_forest_infiltration"
      },
      {
        text: "Yüzbaşının üzerindeki 50 Altın rüşvet parasına el koy ve suikastçılarla odanda bizzat yüzleş!",
        consequence: "+50 Altın Hazineye, +8 Askeri Destek ➔ Gece Suikastı Sahnesi",
        statChange: {
          inventory: { gold: 50 },
          stats: { militarySupport: 8 },
          flags: { knowsAboutCorruption: true }
        },
        nextScene: "assassination_attempt"
      }
    ]
  },

  assassination_attempt: {
    chapter: 2,
    title: "Karanlıkta Çelik Parıltısı - Suikast Girişimi!",
    location: "Saray Koridorları — Gece 03:00",
    description: "Gece saat üçte balkon perdeleri rüzgarla savruluyor! Fısıltı Ormanı'ndan kiralanmış iki maskeli suikastçı, zehirli hançerleriyle odana dalıyor!\n\n'Prens Anzak ve Lord Adem'in selamı var!' diye tıslıyor içlerinden biri. Muhafızlar yetişene kadar ilk hamleyi sen yapmak zorundasın!",
    choices: [
      {
        text: "🗡️ [Gümüş Hançer] Hançerini çekip şamdandaki mumları devir ve karanlıkta karşı saldırıya geç!",
        consequence: "Suikastçılardan birini avla, diğerini Fısıltı Ormanı'ndaki inlerini ötmesi için sağ yakala (+8 Askeri, +6 Karizma)",
        requiresItem: "Gümüş Hançer",
        statChange: {
          stats: { militarySupport: 8, charisma: 6, politicalPower: 5 },
          flags: { knowsAboutCorruption: true },
          rivalDelta: { brotherPlotProgress: -15 }
        },
        nextScene: "whisper_forest_infiltration"
      },
      {
        text: "🧠 [Zeka >= 60] Odadaki gizli geçidi kullanıp suikastçıları muhafızların pusu kurduğu koridora çek!",
        consequence: "Taktiksel deha! İki suikastçıyı da konuşmaları için Baş Danışman'a teslim et",
        requiresStat: { stat: "intelligence", value: 60, label: "Zeka" },
        statChange: {
          stats: { intelligence: 8, politicalPower: 10 },
          relationships: { advisor: 12 },
          flags: { knowsAboutCorruption: true, hasSpyNetwork: true },
          rivalDelta: { brotherPlotProgress: -20 }
        },
        nextScene: "whisper_forest_infiltration"
      },
      {
        text: "Suikastçılara 50 Altın fırlat: 'Adem'in size ödediğinin iki katını veriyorum, şimdi onu satın!'",
        consequence: "Suikastçıları çift taraflı ajana dönüştür (-50 Altın, +10 Politik Güç, Casus Ağı)",
        goldCost: 50,
        statChange: {
          stats: { politicalPower: 10, intelligence: 6 },
          flags: { hasSpyNetwork: true, knowsAboutCorruption: true },
          rivalDelta: { brotherPlotProgress: -22 }
        },
        nextScene: "diplomatic_crossroads"
      },
      {
        text: "Ağır meşe masayı siper alıp nöbetçiler gelene kadar savunmada kal",
        consequence: "Yaralanmadan kurtul (+4 Askeri Destek ➔ Sabah Diplomasi Kavşağı)",
        statChange: { stats: { militarySupport: 4 } },
        nextScene: "diplomatic_crossroads"
      }
    ]
  },

  whisper_forest_infiltration: {
    chapter: 2,
    title: "Fısıltı Ormanı - Adem'in Gölge İni",
    location: "Fısıltı Ormanı Sınırı — Şafak Öncesi",
    description: "Yakalanan suikastçının verdiği haritayla Fısıltı Ormanı'ndaki gizli kampa ulaştın. Adem'in paralı suikastçıları ve kaçakçıları burada hem darbe planlarını hem de kaçak altın sandıklarını saklıyor.",
    choices: [
      {
        text: "🎲 [Askeri Baskın] Fısıltı Ormanı kampına tam kapsamlı muharebe düzenleyip bölgeyi kardeşlerin elinden al!",
        consequence: "Fısıltı Ormanı için 3v2 Muharebe başlatır! Kazanırsan eyalet senin olur ve Adem'in ağı çöker.",
        specialAction: "startBattle",
        battleTarget: "dark_forest",
        statChange: {
          stats: { militarySupport: 10 },
          flags: { ademNetworkCrushed: true },
          rivalDelta: { brotherPlotProgress: -20 }
        },
        nextScene: "diplomatic_crossroads"
      },
      {
        text: "Sessizce altın çadırını yağmala (+70 Altın) ve kamptaki ihanet mektuplarını ele geçirip başkente dön",
        consequence: "+70 Altın, +8 Zeka, Kardeş Darbesi -15%",
        statChange: {
          inventory: { gold: 70 },
          stats: { intelligence: 8, politicalPower: 6 },
          flags: { knowsAboutCorruption: true, ademNetworkCrushed: true },
          rivalDelta: { brotherPlotProgress: -15 }
        },
        nextScene: "diplomatic_crossroads"
      }
    ]
  },

  // ================= BÖLÜM 3: BÜYÜK DİPLOMASİ VE BÖLGESEL SEFERLER =================
  diplomatic_crossroads: {
    chapter: 3,
    title: "Üçlü Yol Ayrımı - Başkent ve Sınır Krizleri",
    location: "Başkent Lalo — Şafak Vakti",
    description: "Geceki tehlikeleri atlattın. Sabah olduğunda Baş Danışman elinde acil raporlarla odana giriyor:\n\n'Prensim, Büyük Pazar Meydanı'nda Anzak'ın vergi tahsildarları halka ve Furry tüccarlarına zulmediyor; başkent isyanın eşiğinde! Öte yandan Batı Furry Limanı, Güney DOXE Manastırı ve Kuzey Dağ Klanları sizinle bizzat görüşmek için elçi bekliyor.'",
    choices: [
      {
        text: "Önce Büyük Pazar Meydanı'na inip başkent halkını ve tüccarları Anzak'ın zorbalarından kurtar",
        consequence: "Başkentteki yangını söndür (+5 Halk Desteği ➔ Büyük Pazar Meydanı)",
        statChange: { stats: { publicSupport: 5 } },
        nextScene: "marketplace_morning"
      },
      {
        text: "Doğrudan Batı Furry Limanı'na at sürerek Ticaret Senatosu ile stratejik antlaşma masasına otur",
        consequence: "Furry Cumhuriyeti seferine çık (+10 Furry İlişkisi ➔ Batı Furry Limanı)",
        statChange: { relationships: { furries: 10 } },
        nextScene: "furry_port_embassy"
      }
    ]
  },

  marketplace_morning: {
    chapter: 3,
    title: "Büyük Pazar Meydanı - Zincirler ve Kıvılcım",
    location: "Başkent Lalo — Ticaret Meydanı",
    description: "Pazar meydanı öfkeli kalabalıkla kaynıyor! Anzak'ın armasını taşıyan zırhlı tahsildarlar, vergi borcunu ödeyemeyen yaşlı bir demirciyi ve ailesini demir zincirlere vurmuş, Güneydeki köle tüccarlarına teslim etmeye çalışıyor.\n\nFurry Cumhuriyeti'nin Baş Elçisi pençelerini sıkmış öfkeyle izliyor: 'Prens Tutu! Kardeşin Anzak bizim kervanlarımızdan da haraç kesiyor. Şimdi hangi sınır müttefikine yöneleceksiniz?'",
    choices: [
      {
        text: "⚖️ Zincirleri kırıp köleliği lanetle ve doğrudan Güney DOXE Manastırı'na git!",
        consequence: "+18 Halk, +15 DOXE, +10 Ahlak ➔ Güney DOXE Işık Mahkemesi Sahnesi",
        requiresItem: "Kraliyet Mührü",
        statChange: {
          relationships: { people: 18, anzak: -10 },
          worldRelations: { doxe: 15 },
          stats: { publicSupport: 15, moralStanding: 10, politicalPower: 6 },
          worldState: { slavery: "Kısıtlandı" }
        },
        nextScene: "doxe_monastery_trial"
      },
      {
        text: "🐾 Ailenin borcunu öde (30 Altın) ve Furry Elçisiyle birlikte Batı Furry Limanı'na yelken aç!",
        consequence: "-30 Altın, +15 Furry, +10 Halk ➔ Batı Furry Ticaret Senatosu Sahnesi",
        goldCost: 30,
        statChange: {
          relationships: { people: 10, furries: 15 },
          stats: { charisma: 8, publicSupport: 10 }
        },
        nextScene: "furry_port_embassy"
      },
      {
        text: "⚒️ Tahsildarları kovup kurtardığın usta demirciyle birlikte Kuzey Dağ Klanları Ocakları'na çık!",
        consequence: "+12 Dağ Kabileleri, +10 Askeri Destek ➔ Kuzey Dağları Demir Ocağı Sahnesi",
        statChange: {
          worldRelations: { mountainTribes: 12 },
          stats: { militarySupport: 10, politicalPower: 8 },
          rivalDelta: { brotherPlotProgress: -8 }
        },
        nextScene: "northern_forge_clans"
      }
    ]
  },

  furry_port_embassy: {
    chapter: 3,
    title: "Batı Furry Limanı - Altın Borsa ve Nişancılar",
    location: "Furry Cumhuriyeti — Gümüş Pençe Senatosu",
    description: "Yüzlerce yelkenlinin demirlediği devasa Batı Furry Limanı'ndasın. Cumhuriyet Senatosu Başkanı Baş Amiral Fenris seni kürsüde karşılıyor:\n\n'Prens Tutu, İmparatorluk ile ticaret yapmak istiyoruz ama kardeşlerin Anzak ve Adem limanlarımıza sabotaj düzenliyor. Bize ne vaat ediyorsun?'",
    choices: [
      {
        text: "Serbest Liman ve Ortak Savunma Paktı imzala: 'Gümrükleri birleştirelim, Furry Nişancıları Doğu Sınırını korusun!'",
        consequence: "+90 Altın Ticaret Geliri, +3 Furry Okçu Taburu, +20 Furry İlişkisi",
        statChange: {
          inventory: { gold: 90 },
          armyDelta: { furryArchers: 3 },
          relationships: { furries: 20 },
          stats: { politicalPower: 10 },
          flags: { furrySenateTreaty: true },
          worldState: { economicState: "Canlanıyor" }
        },
        nextScene: "faction_envoy_summit"
      },
      {
        text: "Furry İstihbarat Loncası ile anlaşarak kardeşlerinin saraydaki finansörlerini çökert!",
        consequence: "+50 Altın, Casus Ağı Aktif, Kardeşlerin Darbe Hazırlığı -25%",
        statChange: {
          inventory: { gold: 50 },
          armyDelta: { furryArchers: 2 },
          flags: { hasSpyNetwork: true, furrySenateTreaty: true },
          rivalDelta: { brotherPlotProgress: -25 }
        },
        nextScene: "faction_envoy_summit"
      }
    ]
  },

  doxe_monastery_trial: {
    chapter: 3,
    title: "DOXE Kutsal Manastırı - Işık ve Zincir Mahkemesi",
    location: "Güney Sınırı — DOXE Yüksek Katedrali",
    description: "Beyaz mermer sütunlu DOXE Manastırı'nda Baş Engizisyoncu Solaris, altın zırhlı Paladin taburlarının önünde duruyor:\n\n'Lalo Hanedanı yıllarca Güney Bereket Ovaları'ndaki köle kamplarına göz yumdu Prens Tutu! Vampir Lordu Malakor'un karanlık ordusuna karşı Kutsal Paladinlerimizi istiyorsan, önce ışığın önünde köleliği ebediyen sildiğini kanıtla!'",
    choices: [
      {
        text: "Bilgelik Kitabı ve Kraliyet Mührü üzerine yemin ederek Köleliği İmparatorlukta Ebediyen Yasakla!",
        consequence: "Orduna +3 DOXE Kutsal Paladin Taburu katılır! (+30 DOXE, +15 Ahlak, Kölelik: Kaldırıldı)",
        statChange: {
          worldRelations: { doxe: 30 },
          relationships: { people: 18 },
          armyDelta: { doxePaladins: 3 },
          stats: { moralStanding: 15, publicSupport: 14 },
          decrees: { abolishSlavery: true },
          flags: { doxeAlliance: true },
          worldState: { slavery: "Tamamen Kaldırıldı", diplomaticStanding: "Kutsal İttifak" }
        },
        nextScene: "faction_envoy_summit"
      },
      {
        text: "DOXE Paladinleriyle birlikte hemen sınırın yanındaki Anzak'ın Güney Köle Kamplarına ortak operasyon düzenle!",
        consequence: "+2 DOXE Paladin, +2 Özgürleşen Piyade, Kardeş Darbesi -18%",
        statChange: {
          worldRelations: { doxe: 25 },
          armyDelta: { doxePaladins: 2, infantry: 2 },
          stats: { militarySupport: 10, moralStanding: 12 },
          flags: { doxeAlliance: true },
          rivalDelta: { brotherPlotProgress: -18 }
        },
        nextScene: "faction_envoy_summit"
      }
    ]
  },

  northern_forge_clans: {
    chapter: 3,
    title: "Gümüş Zirveler - Kuzey Dağ Klanları Ocakları",
    location: "Kuzey Dağları — Ulu Demir Ocağı",
    description: "Kar fırtınasının ortasında kor gibi yanan Ulu Demir Ocağı'na ulaştın. Klanlar Şefi Torvald, dev çift taraflı baltasını örse vurarak seni süzüyor:\n\n'Güneyin ipek cübbeli prensleri buraya pek çıkmaz Tutu! Bizim baltalarımızı ve Kuzey Çeliği zırhlarımızı istiyorsan ya ocağımıza altın dökersin ya da bileğinin ve cesaretinin gücünü gösterirsin!'",
    choices: [
      {
        text: "Ocağa 35 Altın demir fonu ver ve Kuzey Çeliği Zırhı ile Dağ Baltacılarını orduna kat!",
        consequence: "-35 Altın, +3 Dağ Baltacısı Taburu, Düelloda +25 Can veren Kuzey Çeliği Zırh!",
        goldCost: 35,
        statChange: {
          worldRelations: { mountainTribes: 30 },
          armyDelta: { mountainAxemen: 3 },
          stats: { militarySupport: 12 },
          flags: { northernForgePact: true }
        },
        nextScene: "faction_envoy_summit"
      },
      {
        text: "Cübbeni çıkarıp kızgın örsün başına geç ve Şef Torvald ile birlikte çelik döverek klanların saygısını kazan!",
        consequence: "Bedava +3 Dağ Baltacısı Taburu, +10 Karizma, +25 Dağ Klanları İlişkisi!",
        statChange: {
          worldRelations: { mountainTribes: 25 },
          armyDelta: { mountainAxemen: 3 },
          stats: { charisma: 10, militarySupport: 10 },
          flags: { northernForgePact: true }
        },
        nextScene: "faction_envoy_summit"
      }
    ]
  },

  faction_envoy_summit: {
    chapter: 3,
    title: "Başkent Elçiler Zirvesi - Büyük Koalisyon Masası",
    location: "Başkent Lalo — Elçilik Sarayı",
    description: "Bölgesel seferinden başkente döndüğünde üç dış gücün (Furry Cumhuriyeti, DOXE Krallığı ve Kuzey Dağ Klanları) temsilcileri son hazırlıklar için Elçilik Sarayı'nda toplandı.\n\nDoğu sınırından dumanlar yükselirken ve Güney Bereket Ovaları'nda Anzak'ın baronları isyan bayrağı açarken koalisyonu mühürleme vakti!",
    choices: [
      {
        text: "🧠 [Karizma >= 68] Üç elçiyi de ortak 'Gölge Karşıtı Büyük Koalisyon' çatısında birleştir!",
        consequence: "Efsanevi diplomatik zafer! Her üç ordudan (+2 Okçu, +2 Paladin, +2 Baltacı) takviye al!",
        requiresStat: { stat: "charisma", value: 68, label: "Karizma" },
        statChange: {
          relationships: { furries: 15 },
          worldRelations: { doxe: 20, mountainTribes: 20 },
          armyDelta: { furryArchers: 2, doxePaladins: 2, mountainAxemen: 2 },
          stats: { politicalPower: 15, charisma: 8 },
          worldState: { diplomaticStanding: "Büyük Koalisyon" }
        },
        nextScene: "southern_barons_rebellion"
      },
      {
        text: "⚖️ DOXE ve Halk temsilcileriyle 'Özgür İmparatorluk' paktını imzala (+2 DOXE Paladin, +2 Piyade)",
        consequence: "+2 DOXE Paladin, +2 Kraliyet Piyadesi, +15 Halk Desteği",
        statChange: {
          worldRelations: { doxe: 20 },
          armyDelta: { doxePaladins: 2, infantry: 2 },
          stats: { publicSupport: 15, moralStanding: 10 },
          flags: { doxeAlliance: true }
        },
        nextScene: "southern_barons_rebellion"
      },
      {
        text: "🐾 Furry ve Kuzey Klanlarıyla 'Barut ve Çelik' askeri tedarik anlaşması imzala (+2 Okçu, +2 Baltacı, +45 Altın)",
        consequence: "+2 Furry Okçusu, +2 Dağ Baltacısı, +45 Altın",
        statChange: {
          inventory: { gold: 45 },
          armyDelta: { furryArchers: 2, mountainAxemen: 2 },
          stats: { militarySupport: 12 }
        },
        nextScene: "southern_barons_rebellion"
      }
    ]
  },

  // ================= BÖLÜM 4: İÇ SAVAŞ, DOĞU CEPHESİ VE İMPARATORUN VEFATI =================
  southern_barons_rebellion: {
    chapter: 4,
    title: "Güney Bereket Ovaları - Köle Baronlarının İsyanı",
    location: "Güney Sınırı — Bereket Ovaları",
    description: "Doğu cephesine yürümeden hemen önce, Anzak ve Adem'in kışkırttığı Güney Köle Baronları başkentin tahıl yolunu kesti! Güney Bereket Ovaları'ndaki 8 taburluk paralı asker ordusu arkandan hançerlemeye hazırlanıyor.",
    choices: [
      {
        text: "🎲 [Güney Seferi] Ordunla Güney Bereket Ovaları'na girip Anzak'ın baronlarını savaş meydanında ez!",
        consequence: "Güney Bereket Ovaları için 3v2 Muharebe başlatır! Kazanırsan eyalet senin olur ve darbe planı çöker.",
        specialAction: "startBattle",
        battleTarget: "golden_plains",
        statChange: {
          stats: { militarySupport: 10, politicalPower: 10 },
          rivalDelta: { brotherPlotProgress: -25 }
        },
        nextScene: "eastern_front_crisis"
      },
      {
        text: "🕵️ Casusların ve özgürleşen köylülerle baronların şatolarında gece ayaklanması çıkar!",
        consequence: "Savaşmadan Güney Ovaları garnizonunu erit (+12 Halk, Kardeş Darbesi -18%)",
        statChange: {
          stats: { publicSupport: 12, intelligence: 6 },
          rivalDelta: { brotherPlotProgress: -18 }
        },
        nextScene: "eastern_front_crisis"
      }
    ]
  },

  eastern_front_crisis: {
    chapter: 4,
    title: "Doğu Kızıl Geçidi - Kanlı Şafak",
    location: "Doğu Sınırı — Kızıl Geçit Kalesi",
    description: "Doğu ufku kızıl şimşeklerle aydınlanıyor! Vampir Lordu Malakor ve Kara Elf Başbüyücüsü, Gölge Kalesi'nden çıkarak Doğu Kızıl Geçidi'ne tam kapsamlı bir istila başlattı!\n\nLord Komutan Vex kılıcını çekip yanına geliyor: 'Prensim! Geçidi savunup ardından doğrudan Gölge Kalesi'ni kuşatabiliriz ya da savunmayı bana bırakıp başkente dönebilirsiniz!'",
    choices: [
      {
        text: "🎲 [Büyük Meydan Muharebesi] Ordunun başında Doğu Kızıl Geçidi'nde Vampir-Kara Elf ordusunu ez!",
        consequence: "Doğu Kızıl Geçidi Muharebesini başlatır! Zafer kazanırsan Gölge Kalesi'nin yolu açılır.",
        specialAction: "startBattle",
        battleTarget: "eastern_pass",
        statChange: { stats: { militarySupport: 12, politicalPower: 10 } },
        nextScene: "vampire_citadel_siege"
      },
      {
        text: "Geçit savunmasını Komutan Vex'e bırak ve komaya giren baban İmparator Lalo'nun başucuna, Başkent'e koş!",
        consequence: "İç politikaya ve taht geçişine odaklan (+10 Politik Güç, Kardeş Darbesi -20%)",
        statChange: {
          stats: { politicalPower: 10, intelligence: 6 },
          rivalDelta: { brotherPlotProgress: -20 }
        },
        nextScene: "imperial_funeral_eve"
      }
    ]
  },

  vampire_citadel_siege: {
    chapter: 4,
    title: "Gölge Kalesi Kuşatması - Karanlığın Kalbi",
    location: "Doğu Sınır Ötesi — Vampir Gölge Kalesi",
    description: "Kızıl Geçit'te düşman öncülerini dağıttın! Şimdi karşında Vampir-Kara Elf İttifakı'nın ana karargahı olan devasa Gölge Kalesi duruyor. Kaleyi şimdi fethedersen doğu tehdidi sonsuza dek bitecek!",
    choices: [
      {
        text: "🎲 [Gölge Kalesi Kuşatması] Koalisyon ordunla Gölge Kalesi'ne nihai taarruzu başlat!",
        consequence: "Gölge Kalesi (Vampir-Elf) Muharebesini başlatır! Fethedersen +150 Altın ve mutlak askeri zafer!",
        specialAction: "startBattle",
        battleTarget: "vampire_citadel",
        statChange: {
          stats: { militarySupport: 15, charisma: 10 },
          flags: { easternVictory: true, vampireCitadelTaken: true }
        },
        nextScene: "imperial_funeral_eve"
      },
      {
        text: "Vampir Lordu Malakor'u haraca bağlayıp (+80 Altın) vakit kaybetmeden Başkent'teki taht krizine dön!",
        consequence: "+80 Altın Savaş Tazminatı, Doğu Cephesi Güvende ➔ Başkent'e Dönüş",
        statChange: {
          inventory: { gold: 80 },
          stats: { politicalPower: 10 },
          flags: { easternVictory: true }
        },
        nextScene: "imperial_funeral_eve"
      }
    ]
  },

  imperial_funeral_eve: {
    chapter: 4,
    title: "Son Nefes - İmparator Lalo'nun Veda Gecesi",
    location: "Başkent Lalo — Kraliyet Mozolesi",
    description: "Başkent Lalo'da çanlar ağır ve hüzünlü çalıyor. 68 yaşındaki baban İmparator Lalo, bu akşam son nefesini verdi. Küçük kız kardeşlerin (9 ve 13) siyah matem pelerinleriyle sana sarılıp ağlıyor.\n\nBaş Danışman yanına yaklaşıp fısıldıyor: 'Hünkarımız vefat etti Prensim. Anzak ve Adem tüm soyluları ve garnizon komutanlarını Taht Odası'na çağırdı. Bu gece tahtın sahibi belirlenecek!'",
    choices: [
      {
        text: "Babana son saygını sun, İmparatorluk Mührü'nü kuşan ve Taht Odası'nın kapılarını açtır!",
        consequence: "Kader Gecesi başlıyor (+8 Politik Güç, +5 Karizma ➔ Büyük Final Divanı)",
        statChange: { stats: { politicalPower: 8, charisma: 5 } },
        nextScene: "shadow_summit"
      }
    ]
  },

  // ================= BÖLÜM 5: KADER GECESİ VE 7 FARKLI FİNAL =================
  shadow_summit: {
    chapter: 5,
    title: "Kader Gecesi - Altın Tahtın Sınavı",
    location: "Başkent Lalo — Taht Odası",
    description: "Fırtınalı bir gece yarısı... Meşalelerin aydınlattığı Taht Odası'nda tüm soylular, komutanlar ve elçiler toplanmış durumda. Anzak ve Adem kılıçlarını çekmiş altın tahtın basamaklarında duruyor.\n\nAnzak gürlüyor: 'Babamız artık yok! En büyük oğul olarak tacı ben alıyorum!'\nAdem ise elindeki sahte fermanı sallıyor: 'Tutu saray geleneklerini çiğnedi, onu tutuklayın!'\n\nSalonun dev kapıları ardına kadar açılıyor ve sen içeri giriyorsun. Şimdiye kadar biriktirdiğin tüm güç, ittifak, istihbarat ve askeri zaferlerin konuşma vakti!",
    choices: [
      {
        text: "🌟 [Büyük Koalisyon & Özgürlük Tacı] Furry, DOXE, Dağ Klanları ve özgürleştirdiğin Halkla birlikte Taht Odası'na yürü!",
        consequence: "Final 1: Şafağın ve Özgürlüğün İmparatoru (Gereksinim: Halk Desteği >= 60 veya Kölelik Kaldırıldı)",
        requiresCustom: (s) => s.stats.publicSupport >= 60 || s.decrees.abolishSlavery || s.flags.doxeAlliance,
        customReason: "Halk Desteği 60+ veya Kölelik Reformu/DOXE İttifakı gerekli",
        nextScene: "ending_golden_coalition"
      },
      {
        text: "🕵️ [Gölge İmparatoru] Suikastçı itiraflarını, babanın gizli vasiyetini ve Adem'in ihanet belgelerini Konsey'in önüne fırlat!",
        consequence: "Final 2: Gölgelerin ve Aklın Hükümdarı (Gereksinim: Casus Ağı veya Yolsuzluk Kanıtı)",
        requiresCustom: (s) => s.flags.hasSpyNetwork || s.flags.knowsAboutCorruption,
        customReason: "Casus Ağı veya Yolsuzluk Kanıtı gerekli",
        nextScene: "ending_shadow_master"
      },
      {
        text: "⚔️ [Muzaffer Mareşal] Doğu Zaferi'nin kanlı sancağını yere sapla ve ordunun mutlak biatıyla tahta otur!",
        consequence: "Final 3: Çelik ve Zafer İmparatoru (Gereksinim: Doğu Zaferi, Anzak Yenilgisi veya Askeri Destek >= 55)",
        requiresCustom: (s) => s.flags.easternVictory || s.flags.anzakDefeated || s.stats.militarySupport >= 55,
        customReason: "Doğu Zaferi, Anzak Düello Zaferi veya Askeri Destek 55+ gerekli",
        nextScene: "ending_iron_conqueror"
      },
      {
        text: "👑 [Hanedan Uzlaşısı] Kardeşlerine kan dökmek yerine İmparatorluğu Üçlü Konsey olarak yönetmeyi teklif et",
        consequence: "Final 4: Üç Kardeşin Demir Paktı (Gereksinim: 100 Altın veya Karizma >= 70)",
        requiresCustom: (s) => s.inventory.gold >= 100 || s.stats.charisma >= 70,
        customReason: "100 Altın veya Karizma 70+ gerekli",
        nextScene: "ending_triumvirate"
      },
      {
        text: "🐾 [Altın Terazi & Meşrutiyet] Furry Ticaret Senatosu ve Halk Loncalarıyla 'Anayasal İmparatorluk Meclisi'ni ilan et!",
        consequence: "Final 5: Altın Terazi ve Refah Tacı (Gereksinim: Furry İlişkisi >= 80 ve Politik Güç >= 55)",
        requiresCustom: (s) => s.relationships.furries >= 80 && s.stats.politicalPower >= 55,
        customReason: "Furry İlişkisi 80+ ve Politik Güç 55+ gerekli",
        nextScene: "ending_merchant_republic"
      },
      {
        text: "🗡️ [Son Kan Düellosu] 'Tahtı isteyen kılıcımı geçsin!' diyerek Anzak'ı herkesin önünde ölümüne düelloya çağır!",
        consequence: "Her şeyi birebir kılıç düellosunun sonucuna bağla!",
        specialAction: "startDuel",
        nextScene: "ending_iron_conqueror"
      }
    ]
  },

  // ================= 7 FARKLI FİNAL BÖLÜMÜ (5 ZAFER + 2 YENİLGİ) =================
  ending_golden_coalition: {
    chapter: 5,
    title: "FİNAL 1: Şafağın ve Özgürlüğün İmparatoru",
    location: "Yeni Lalo İmparatorluğu — Altın Çağ",
    isEnding: true,
    isVictory: true,
    endingBadge: "🌟 En İyi Son: Büyük Koalisyon & Özgürlük",
    description: "Taht Odası'nın kapılarından içeri yalnızca sen girmedin; arkanda Furry Cumhuriyeti'nin elçileri, DOXE Krallığı'nın parlayan zırhlı Paladinleri, Kuzey Dağları'nın şefleri ve zincirlerini kırdığın binlerce başkent vatandaşı vardı!\n\nAnzak ve Adem'in paralı askerleri bu muazzam birlik karşısında kılıçlarını yere bıraktı. Baş Danışman İmparatorluk Tacı'nı senin başına koyarken tüm salon önünde diz çöktü.\n\nBirleşik koalisyon ordusuyla Doğu sınırındaki Vampir-Kara Elf İttifakı'nı tarihten sildin. Kölelik ebediyen kaldırıldı, Furry ticaret yollarıyla hazine dolup taştı ve küçük kız kardeşlerin (9 ve 13) barış dolu bir sarayda büyüdü. Tarih seni 'Büyük İmparator Tutu' olarak altın harflerle yazdı!",
    choices: []
  },

  ending_shadow_master: {
    chapter: 5,
    title: "FİNAL 2: Gölgelerin ve Aklın Hükümdarı",
    location: "Başkent Lalo — Yüksek İstihbarat Divanı",
    isEnding: true,
    isVictory: true,
    endingBadge: "🕵️ Stratejik Zafer: Gölge İmparator",
    description: "Anzak kılıcını kaldırmaya fırsat bile bulamadan Baş Danışman ve kurduğun Gölge Casus Ağı harekete geçti. Gece odana gönderilen suikastçıların itirafları, babanın vasiyeti ve kardeşlerinin Güney Baronlarıyla yaptığı ihanet mektupları tüm Konsey üyelerine dağıtıldı.\n\nTek bir damla kardeş kanı dökülmeden, kendi komutanları Anzak ve Adem'i tutuklayıp sürgüne gönderdi. Vampir-Kara Elf ordusu ise casuslarının doğu vadisindeki ikmal depolarını havaya uçurmasıyla kış ortasında dağılıp yok oldu.\n\nKılıcını kınından bile çıkarmadan, yalnızca keskin zekan ve istihbarat ağınla tüm düşmanlarını dize getirdin!",
    choices: []
  },

  ending_iron_conqueror: {
    chapter: 5,
    title: "FİNAL 3: Çelik ve Zafer İmparatoru",
    location: "Doğu Sınırı & Altın Taht",
    isEnding: true,
    isVictory: true,
    endingBadge: "⚔️ Askeri Mutlakiyet: Fatih Tutu",
    description: "Üzerinde savaş meydanının tozu, elinde Gümüş Hançer'in ve arkanda Doğu Kızıl Geçidi'nin muzaffer lejyonlarıyla Taht Odası'na girdin. Anzak'ın kılıcı senin iraden karşısında kırıldı.\n\nOrdunun ve Lord Komutan Vex'in tam desteğiyle tahta çıktın. Vampir-Kara Elf İttifakı'nın Gölge Kalesi'ni dahi fethederek imparatorluk sınırlarını iki katına çıkardın. Demir yumruğun ve askeri dehan sayesinde hiçbir iç veya dış düşman bir daha Lalo Hanedanı'na yan gözle bakamadı!",
    choices: []
  },

  ending_triumvirate: {
    chapter: 5,
    title: "FİNAL 4: Üç Kardeşin Demir Paktı (Triumvirlik)",
    location: "Başkent Lalo — Hanedan Konseyi",
    isEnding: true,
    isVictory: true,
    endingBadge: "👑 Diplomatik Deha: Birleşik Hanedan",
    description: "Herkes kardeş kanı dökülmesini beklerken sen üstün karizman ve siyasi gücünle Anzak ve Adem'i dize getirdin ama onları yok etmedin. 'Babamızın mirasını birbirimizi boğazlayarak değil, dünyayı fethederek büyüteceğiz!' dedin.\n\nSen Yüce İmparator olarak tahta geçtin; Anzak'ı Doğu Orduları Başkomutanı olarak Vampir cephesine, Adem'i ise Ticaret ve Hazine Nazırı olarak görevlendirdin. Üç kardeşin birleşen gücü karşısında Vampir-Kara Elf İttifakı darmadağın oldu!",
    choices: []
  },

  ending_merchant_republic: {
    chapter: 5,
    title: "FİNAL 5: Altın Terazi ve Meşrutiyet Tacı",
    location: "Başkent Lalo — İmparatorluk Senatosu",
    isEnding: true,
    isVictory: true,
    endingBadge: "🐾 Ekonomik & Demokratik Rönesans",
    description: "Furry Cumhuriyeti'nin finansal gücü ve başkent loncalarının tam desteğiyle mutlak monarşiyi Anayasal İmparatorluk Senatosu'na dönüştürdün!\n\nAltınlarınla Anzak'ın paralı askerlerini satın alıp terhis ettin, Adem'in ticaret tekellerini halka açtın. İmparatorluk tarihinde ilk kez Hazine 1000 Altın sınırını aşarken bilimde, ticarette ve sanatta benzersiz bir Rönesans başladı!",
    choices: []
  },

  ending_coup_defeat: {
    chapter: 5,
    title: "YENİLGİ 1: Demir Zindan - Kardeşlerin Saray Darbesi",
    location: "Başkent Lalo — Soğuk Zindanlar",
    isEnding: true,
    isVictory: false,
    endingBadge: "💀 Trajik Son: Saray Darbesi (%100 Komplo)",
    description: "Anzak ve Adem'in saray içindeki komplo hazırlığı %100'e ulaştı! Gece yarısı rüşvetle satın alınmış muhafızlar dairenin kapılarını kırarak seni uykunda zincire vurdu.\n\nAnzak kanlı bir darbeyle kendisini İmparator ilan ederken, Adem hazineyi Güney Baronlarına peşkeş çekti. İpucu: Yeni oyunda Gölge İstihbarat Divanı fermanını ilan ederek veya Fısıltı Ormanı ile Güney Ovalarını sabote ederek kardeşlerinin darbe yüzdesini düşürebilirsin!",
    choices: []
  },

  ending_vampire_fall: {
    chapter: 5,
    title: "YENİLGİ 2: Kanlı Ay Tutulması - Başkentin Düşüşü",
    location: "Yanan Başkent Lalo",
    isEnding: true,
    isVictory: false,
    endingBadge: "🩸 Trajik Son: Vampir-Kara Elf İstilası",
    description: "Doğu Kızıl Geçidi takviye edilmediği için Vampir Lordu Malakor'un ordularına dayanamadı ve yıkıldı. Karanlık lejyonlar Başkent Lalo'yu kuşatırken kardeşlerin Anzak ve Adem hazineyi alıp gemilerle kaçtı.\n\nSen son ana kadar saray merdivenlerinde çarpışsan da başkent karanlığa gömüldü. İpucu: Yeni oyunda Doğu Kızıl Geçidi garnizonunu haritadan güçlendir veya Fermanlardan 'Kızıl Geçit Kaya Surları'nı inşa et!",
    choices: []
  }
};
