// ============================================================================
// PRENS TUTU: GÖLGELERİN TACI - MODÜL 3: COMBAT & DUEL ENGINE (engine-combat.js) v4.0
// İçerik: Harita Garnizonuna Bağlı 3v2 Zar Motoru, Monte Carlo Zafer Olasılığı,
//         Okçu Yaylım Ateşi, Paladin Kutsal Arındırma, Taktiksel Stamina Düellosu
// ============================================================================

window.PrinceTutu = window.PrinceTutu || {};

window.PrinceTutu.CombatEngine = {
  // 1. Muharebe Başlatıcı (Haritadaki gerçek garnizonları ve birim bonuslarını okur!)
  createBattleState(gameState, targetProvinceId = "eastern_pass") {
    const comp = gameState.armyComposition;
    const targetProv = gameState.provinces[targetProvinceId] || gameState.provinces.eastern_pass;

    const baseUnits =
      comp.infantry + comp.furryArchers + comp.mountainAxemen + comp.doxePaladins;
    const leadershipBonus = Math.floor(gameState.stats.militarySupport / 15);

    // Haritadaki Doğu Kızıl Geçidi ve Başkent garnizonları saha ordusuna lojistik destek verir
    const garrisonSupport = Math.floor(
      ((gameState.provinces.eastern_pass?.owner === "player" ? gameState.provinces.eastern_pass.garrison : 0) +
        (gameState.provinces.capital_lalo?.garrison || 0)) / 5
    );

    const totalTroops = baseUnits + leadershipBonus + garrisonSupport;

    // Düşman tabur sayısı doğrudan haritadaki hedef eyaletin güncel garnizonuna bağlıdır!
    // (Haritada yapılan casus sabotajları düşman ordusunu gerçekten azaltır!)
    let enemyTroops = 12;
    let enemyFactionName = "Vampir-Kara Elf İttifakı";
    let isVampireEnemy = true;

    if (targetProvinceId === "eastern_pass" && targetProv.owner === "player") {
      // Doğu Kızıl Geçidi savunması: Gölge Kalesi'ndeki Vampir ordusu saldırır
      const vampProv = gameState.provinces.vampire_citadel;
      enemyTroops = Math.max(6, vampProv.garrison + 1);
      enemyFactionName = "Vampir Lordu Malakor'un İstila Ordusu";
      isVampireEnemy = true;
    } else {
      enemyTroops = Math.max(4, targetProv.garrison + targetProv.defenseBonus);
      if (targetProv.owner === "brothers") {
        enemyFactionName = `${targetProv.name} (Anzak & Adem Garnizonu)`;
        isVampireEnemy = false;
      } else {
        enemyFactionName = `${targetProv.name} (Vampir-Kara Elf Garnizonu)`;
        isVampireEnemy = true;
      }
    }

    const winProb = this.estimateWinProbability(
      totalTroops,
      enemyTroops,
      comp.mountainAxemen > 0 || gameState.stats.intelligence >= 60,
      comp.doxePaladins > 0 && isVampireEnemy
    );

    return {
      targetProvinceId,
      targetProvinceName: targetProv.name,
      enemyFactionName,
      isVampireEnemy,
      playerTroops: totalTroops,
      maxPlayerTroops: totalTroops,
      enemyTroops: enemyTroops,
      maxEnemyTroops: enemyTroops,
      round: 0,
      archerVolleyUsed: false,
      paladinPurgeUsed: false,
      playerDice: [],
      enemyDice: [],
      winProbability: winProb,
      units: { ...comp },
      hasTacticalEdge: gameState.stats.intelligence >= 60,
      status: "ongoing", // 'ongoing' | 'won' | 'lost'
      battleLog: [
        `⚔️ ${targetProv.name} Cephesi Kuruldu! Toplam ${totalTroops} Tabur (${baseUnits} Saha Birimi + ${leadershipBonus} Komuta + ${garrisonSupport} Harita Garnizon Desteği).`,
        `🎯 Karşıda ${enemyTroops} Taburluk ${enemyFactionName} var (Harita sabotajları düşman sayısına yansıdı). Tahmini Zafer Şansı: %${winProb}`
      ]
    };
  },

  // 2. Monte Carlo Simülasyonu ile Gerçek Zamanlı Kazanma Olasılığı (% Win Rate)
  estimateWinProbability(pTroops, eTroops, hasDiceBonus, hasPaladinBonus) {
    if (pTroops <= 0) return 0;
    if (eTroops <= 0) return 100;
    const trials = 250;
    let wins = 0;

    for (let t = 0; t < trials; t++) {
      let p = pTroops;
      let e = eTroops;
      while (p > 0 && e > 0) {
        const pCount = Math.min(3, p);
        const eCount = Math.min(2, e);
        const pRolls = Array.from({ length: pCount }, () => Math.floor(Math.random() * 6) + 1).sort((a, b) => b - a);
        const eRolls = Array.from({ length: eCount }, () => Math.floor(Math.random() * 6) + 1).sort((a, b) => b - a);

        if (hasDiceBonus && pRolls.length > 0) pRolls[0] = Math.min(6, pRolls[0] + 1);

        const comps = Math.min(pRolls.length, eRolls.length);
        for (let i = 0; i < comps; i++) {
          if (pRolls[i] > eRolls[i]) {
            e -= hasPaladinBonus && i === 0 && pRolls[0] === 6 ? 2 : 1;
          } else {
            p -= 1;
          }
        }
      }
      if (p > 0) wins++;
    }
    return Math.round((wins / trials) * 100);
  },

  // 3. Furry Okçuları İlk Tur Menzilli Yaylım Ateşi
  triggerArcherVolley(battleState) {
    if (battleState.archerVolleyUsed || battleState.units.furryArchers <= 0 || battleState.status !== "ongoing") {
      return battleState;
    }
    window.PrinceTutu.Sound.play("sword");
    const archers = battleState.units.furryArchers;
    const kills = Math.max(1, Math.min(4, Math.ceil(archers * 0.8)));
    const nextEnemy = Math.max(0, battleState.enemyTroops - kills);
    const nextStatus = nextEnemy === 0 ? "won" : "ongoing";
    const winProb = this.estimateWinProbability(
      battleState.playerTroops,
      nextEnemy,
      battleState.hasTacticalEdge || battleState.units.mountainAxemen > 0,
      battleState.units.doxePaladins > 0 && battleState.isVampireEnemy
    );

    return {
      ...battleState,
      enemyTroops: nextEnemy,
      archerVolleyUsed: true,
      winProbability: winProb,
      status: nextStatus,
      battleLog: [
        `🏹 FURRY OKÇU YAYLIM ATEŞİ! ${archers} Furry Nişancı Taburu gökyüzünü barut ve oklarla kararttı: Düşman -${kills} Tabur kaybetti!`,
        ...battleState.battleLog
      ]
    };
  },

  // 4. YENİ: DOXE Kutsal Paladinleri "Işık Arındırması" Aktif Yeteneği
  triggerPaladinPurge(battleState) {
    if (battleState.paladinPurgeUsed || battleState.units.doxePaladins <= 0 || battleState.status !== "ongoing") {
      return battleState;
    }
    window.PrinceTutu.Sound.play("horn");
    const paladins = battleState.units.doxePaladins;
    const kills = battleState.isVampireEnemy
      ? Math.min(5, paladins + 1)
      : Math.min(3, paladins);
    const heal = 1;
    const nextEnemy = Math.max(0, battleState.enemyTroops - kills);
    const nextPlayer = Math.min(battleState.maxPlayerTroops + 2, battleState.playerTroops + heal);
    const nextStatus = nextEnemy === 0 ? "won" : "ongoing";
    const winProb = this.estimateWinProbability(
      nextPlayer,
      nextEnemy,
      battleState.hasTacticalEdge || battleState.units.mountainAxemen > 0,
      true
    );

    return {
      ...battleState,
      playerTroops: nextPlayer,
      enemyTroops: nextEnemy,
      paladinPurgeUsed: true,
      winProbability: winProb,
      status: nextStatus,
      battleLog: [
        `⚖️ DOXE KUTSAL IŞIK ARINDIRMASI! ${paladins} Paladin Taburu karanlık safları yardı: Düşman -${kills} Tabur, Ordun +${heal} Moral/Tabur kazandı!`,
        ...battleState.battleLog
      ]
    };
  },

  // 5. Risk Tarzı 3v2 Zar Muharebe Turu (Standart, Topyekün Hücum ve Kalkan Duvarı)
  executeBattleRound(battleState, tactic = "standard") {
    if (battleState.status !== "ongoing") return battleState;
    window.PrinceTutu.Sound.play("dice");

    const nextRound = battleState.round + 1;
    const maxPlayerDice = tactic === "shield_wall" ? 2 : 3;
    const pDiceCount = Math.min(maxPlayerDice, battleState.playerTroops);
    const eDiceCount = Math.min(2, battleState.enemyTroops);

    let pRolls = Array.from({ length: pDiceCount }, () => Math.floor(Math.random() * 6) + 1).sort((a, b) => b - a);
    let eRolls = Array.from({ length: eDiceCount }, () => Math.floor(Math.random() * 6) + 1).sort((a, b) => b - a);

    const bonusNotes = [];

    if ((battleState.hasTacticalEdge || battleState.units.mountainAxemen > 0) && pRolls.length > 0) {
      pRolls[0] = Math.min(6, pRolls[0] + 1);
      bonusNotes.push("Taktik/Baltacı +1");
    }

    if (tactic === "all_out" && pRolls.length > 1) {
      pRolls[1] = Math.min(6, pRolls[1] + 1);
      bonusNotes.push("Topyekün Hücum +1");
    } else if (tactic === "shield_wall" && pRolls.length > 0) {
      pRolls[0] = Math.min(6, pRolls[0] + 1);
      bonusNotes.push("🛡️ Kalkan Duvarı Savunması");
    }

    let pLoss = 0;
    let eLoss = 0;
    const comparisons = Math.min(pRolls.length, eRolls.length);

    for (let i = 0; i < comparisons; i++) {
      if (pRolls[i] > eRolls[i]) {
        eLoss++;
        if (i === 0 && pRolls[0] === 6 && battleState.units.doxePaladins > 0) {
          eLoss++;
          bonusNotes.push("⚖️ Paladin Kritik (+1)");
        }
      } else {
        pLoss++;
      }
    }

    if (tactic === "all_out" && pLoss > 0) {
      pLoss++;
      bonusNotes.push("Açık Cephe Kaybı (-1)");
    } else if (tactic === "shield_wall" && pLoss > 1) {
      pLoss = 1; // Kalkan duvarı tur başına maksimum kaybı 1 ile sınırlar
      bonusNotes.push("Kalkan Koruması (Maks 1 Kayıp)");
    }

    const nextPlayer = Math.max(0, battleState.playerTroops - pLoss);
    const nextEnemy = Math.max(0, battleState.enemyTroops - eLoss);

    let nextStatus = "ongoing";
    let msg = `🎲 Tur ${nextRound}: Sen [${pRolls.join(", ")}] vs Düşman [${eRolls.join(", ")}] ${
      bonusNotes.length ? `(${bonusNotes.join(", ")})` : ""
    } ➔ Düşman -${eLoss}, Sen -${pLoss} Tabur.`;

    if (nextEnemy === 0) {
      nextStatus = "won";
      window.PrinceTutu.Sound.play("victory");
      msg = `🏆 KESİN ZAFER! ${battleState.enemyFactionName} tamamen bozguna uğratıldı!`;
    } else if (nextPlayer === 0) {
      nextStatus = "lost";
      window.PrinceTutu.Sound.play("defeat");
      msg = `💀 BOZGUN! Birliklerin ağır kayıplarla geri çekilmek zorunda kaldı.`;
    }

    const winProb = this.estimateWinProbability(
      nextPlayer,
      nextEnemy,
      battleState.hasTacticalEdge || battleState.units.mountainAxemen > 0,
      battleState.units.doxePaladins > 0 && battleState.isVampireEnemy
    );

    return {
      ...battleState,
      round: nextRound,
      playerTroops: nextPlayer,
      enemyTroops: nextEnemy,
      playerDice: pRolls,
      enemyDice: eRolls,
      winProbability: winProb,
      status: nextStatus,
      battleLog: [msg, ...battleState.battleLog]
    };
  },

  // 6. Anzak ile Birebir Taht Düellosu Motoru (Taş-Kağıt-Makas Niyet + Gerçek Stamina Sistemi)
  createDuelState(gameState) {
    const hasSilverDagger = gameState.inventory.items.some((i) => i.name.includes("Gümüş Hançer"));
    const hasNorthernArmor = gameState.decrees.mountainSmithGuild || gameState.flags.northernForgePact;

    return {
      playerHP: hasNorthernArmor ? 130 : 105,
      maxPlayerHP: hasNorthernArmor ? 130 : 105,
      anzakHP: 140,
      maxAnzakHP: 140,
      stamina: 100,
      maxStamina: 100,
      round: 0,
      hasSilverDagger,
      hasNorthernArmor,
      anzakIntent: "Ağır Yukarıdan İndirme (Heavy Slash) — [Siper & Kontra ile Ezilir!]",
      status: "ongoing",
      duelLog: [
        "⚔️ Taht Odası'nda çember kuruldu! Ağabeyin Anzak (27) çift elli kraliyet kılıcını çekti.",
        "💡 İPUCU: Anzak'ın niyetini oku! 'Ağır İndirme'ye karşı Siper & Kontra, 'Omuz Darbesi'ne karşı Gümüş Hançer, 'Öfkeli Kesik'e karşı Psikolojik Sarsıntı vur!",
        hasSilverDagger ? "🗡️ Gümüş Hançer elinde (+8 Keskinlik Hasarı)." : "⚠️ Gümüş Hançer yok!",
        hasNorthernArmor ? "🛡️ Kuzey Çeliği Zırhın kuşanıldı (+25 Ekstra Can)." : ""
      ].filter(Boolean)
    };
  },

  executeDuelRound(duelState, moveType, gameState) {
    if (duelState.status !== "ongoing") return duelState;

    const costs = {
      dagger_lunge: 25,
      parry_riposte: 15,
      royal_psyche: 20,
      catch_breath: 0
    };

    const requiredStamina = costs[moveType] || 0;
    if (duelState.stamina < requiredStamina) {
      window.PrinceTutu.Sound.play("alert");
      return {
        ...duelState,
        duelLog: [
          `⚠️ Yetersiz Dayanıklılık (Stamina)! Bu hamle için ${requiredStamina} Stamina gerekiyor. 'Nefeslen & Odaklan' seç!`,
          ...duelState.duelLog
        ]
      };
    }

    window.PrinceTutu.Sound.play("sword");
    const daggerBonus = duelState.hasSilverDagger ? 8 : 2;
    const intent = duelState.anzakIntent;
    let pDmg = 0;
    let aDmg = 0;
    let stamDelta = -requiredStamina;
    let pHeal = 0;
    let moveDesc = "";

    if (moveType === "dagger_lunge") {
      if (intent.includes("Omuz Darbesi")) {
        // Mükemmel Karşılık!
        aDmg = 32 + daggerBonus;
        pDmg = 5;
        moveDesc = `🗡️ KRİTİK AÇIK YAKALANDI! Anzak omuz vurmak için gardını açtığında Gümüş Hançer'i sapladın: ${aDmg} Hasar!`;
      } else if (intent.includes("Ağır Yukarıdan")) {
        aDmg = 18 + daggerBonus;
        pDmg = 22;
        moveDesc = `🗡️ Hızlı saplama ile ${aDmg} vurdun ama Anzak'ın ağır kılıcından kaçamadın (-${pDmg} HP).`;
      } else {
        aDmg = 20 + daggerBonus;
        pDmg = 12;
        moveDesc = `🗡️ Şimşek Hızında Saplama! Anzak'a ${aDmg} hasar verdin (Aldığın hasar: ${pDmg}).`;
      }
    } else if (moveType === "parry_riposte") {
      if (intent.includes("Ağır Yukarıdan")) {
        // Mükemmel Karşılık!
        aDmg = 35 + daggerBonus;
        pDmg = 3;
        stamDelta += 10; // Başarılı savuşturma yorgunluğu azaltır
        moveDesc = `🛡️ KUSURSUZ SAVUŞTURMA! Anzak'ın ağır darbesini boşa çıkarıp göğsüne ${aDmg} kritik kontra indirdin!`;
      } else if (intent.includes("Omuz Darbesi")) {
        // Gard Kırıldı! (Eski sınırsız parry açığını kapatan ceza)
        aDmg = 6;
        pDmg = 26;
        moveDesc = `💥 GARDIN KIRILDI! Anzak kalkanına omuz vurup savunmanı parçaladı ve ${pDmg} ağır hasar verdi!`;
      } else {
        aDmg = 15;
        pDmg = 12;
        moveDesc = `🛡️ Savunma gardıyla ${aDmg} karşı hasar verdin (Aldığın hasar: ${pDmg}).`;
      }
    } else if (moveType === "royal_psyche") {
      const statPower = Math.floor((gameState.stats.intelligence + gameState.stats.charisma) / 4.2);
      if (intent.includes("Öfkeli Kesik")) {
        aDmg = statPower + 14;
        pDmg = 4;
        moveDesc = `🧠 ZİHİNSEL ÜSTÜNLÜK! Öfkeyle saldıran Anzak'ı komutanların önünde küçük düşürüp dengesini bozdun: ${aDmg} Hasar!`;
      } else {
        aDmg = statPower;
        pDmg = 14;
        moveDesc = `🧠 Kraliyet Otoritesi! Anzak'ın meşruiyetini sarsarak ${aDmg} darbe vurdun (-${pDmg} HP).`;
      }
    } else if (moveType === "catch_breath") {
      stamDelta = +40;
      pHeal = 10;
      pDmg = intent.includes("Ağır Yukarıdan") ? 14 : 9;
      aDmg = 5;
      moveDesc = `💨 Geri çekilip nefeslendin (+40 Stamina, +${pHeal} Can yenilendi, kaçarken ${pDmg} sıyrık aldın).`;
    }

    const nextAnzakHP = Math.max(0, duelState.anzakHP - aDmg);
    const nextPlayerHP = Math.max(0, Math.min(duelState.maxPlayerHP, duelState.playerHP + pHeal - pDmg));
    const nextStamina = Math.max(0, Math.min(duelState.maxStamina, duelState.stamina + stamDelta));

    const intents = [
      "Ağır Yukarıdan İndirme (Heavy Slash) — [Siper & Kontra ile Ezilir!]",
      "Kalkan Kırma ve Omuz Darbesi (Guard Break) — [Gümüş Hançer ile Ezilir, Siperi Kırar!]",
      "Öfkeli Kesik ve Savaş Narası (Berserk Cleave) — [Psikolojik Sarsıntı ile Ezilir!]"
    ];
    // Bir sonraki hamleyi yarı-rastgele ama çeşitli seç
    const nextIntent = intents[(duelState.round + 1 + Math.floor(Math.random() * 2)) % intents.length];

    let nextStatus = "ongoing";
    if (nextAnzakHP === 0) {
      nextStatus = "won";
      window.PrinceTutu.Sound.play("victory");
      moveDesc = "👑 ZAFER! Anzak kılıcını düşürüp diz çöktü! Tüm Taht Odası 'Yaşasın Prens Tutu!' diye inliyor!";
    } else if (nextPlayerHP === 0) {
      nextStatus = "lost";
      window.PrinceTutu.Sound.play("defeat");
      moveDesc = "🩸 Ağır yaralandın! Baş Danışman ve muhafızlar sis bombasıyla seni düello alanından kaçırdı.";
    }

    return {
      ...duelState,
      round: duelState.round + 1,
      playerHP: nextPlayerHP,
      anzakHP: nextAnzakHP,
      stamina: nextStamina,
      anzakIntent: nextIntent,
      status: nextStatus,
      duelLog: [moveDesc, ...duelState.duelLog]
    };
  }
};
